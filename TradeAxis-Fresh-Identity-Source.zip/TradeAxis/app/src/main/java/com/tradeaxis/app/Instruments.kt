package com.tradeaxis.app

/** Market groups shown in Settings → Markets to watch. */
enum class Cat(val label: String) {
    METALS("Metals"), ENERGY("Energy"), CRYPTO("Crypto"), FOREX("Forex")
}

/** One tradable market. [contract] = units per 1.0 lot; [quote] = currency the price is quoted in. */
data class Instrument(
    val id: String,          // OANDA code, also the key used everywhere in the app (e.g. XAU_USD)
    val name: String,
    val cat: Cat,
    val base: String,        // e.g. XAU, GBP
    val quote: String,       // currency the price is quoted in, e.g. USD, JPY
    val contract: Double,
    val twelve: String,      // Twelve Data symbol
    val tv: String           // TradingView symbol
) {
    val pair: String get() = "$base/$quote"
    val code: String get() = id
    val label: String get() = pair
}

object Instruments {
    val all = listOf(
        Instrument("XAU_USD", "Gold", Cat.METALS, "XAU", "USD", 100.0, "XAU/USD", "OANDA:XAUUSD"),
        Instrument("XAG_USD", "Silver", Cat.METALS, "XAG", "USD", 5000.0, "XAG/USD", "OANDA:XAGUSD"),
        Instrument("WTICO_USD", "US Oil (WTI)", Cat.ENERGY, "WTI", "USD", 1000.0, "WTI/USD", "OANDA:WTICOUSD"),
        Instrument("BTC_USD", "Bitcoin", Cat.CRYPTO, "BTC", "USD", 1.0, "BTC/USD", "BITSTAMP:BTCUSD"),
        Instrument("GBP_USD", "Pound / Dollar", Cat.FOREX, "GBP", "USD", 100_000.0, "GBP/USD", "OANDA:GBPUSD"),
        Instrument("GBP_JPY", "Pound / Yen", Cat.FOREX, "GBP", "JPY", 100_000.0, "GBP/JPY", "OANDA:GBPJPY"),
        Instrument("EUR_USD", "Euro / Dollar", Cat.FOREX, "EUR", "USD", 100_000.0, "EUR/USD", "OANDA:EURUSD"),
        Instrument("USD_JPY", "Dollar / Yen", Cat.FOREX, "USD", "JPY", 100_000.0, "USD/JPY", "OANDA:USDJPY"),
        Instrument("EUR_JPY", "Euro / Yen", Cat.FOREX, "EUR", "JPY", 100_000.0, "EUR/JPY", "OANDA:EURJPY"),
        Instrument("AUD_USD", "Aussie / Dollar", Cat.FOREX, "AUD", "USD", 100_000.0, "AUD/USD", "OANDA:AUDUSD"),
        Instrument("USD_CAD", "Dollar / Loonie", Cat.FOREX, "USD", "CAD", 100_000.0, "USD/CAD", "OANDA:USDCAD")
    )

    fun of(code: String): Instrument? {
        val c = normalize(code)
        return all.firstOrNull { it.id == c }
    }

    /** Never null: unknown codes get a generic forex-style entry so screens do not crash. */
    fun get(code: String): Instrument = of(code) ?: generic(code)

    private fun generic(code: String): Instrument {
        val c = normalize(code)
        val parts = c.split("_")
        val base = parts.getOrElse(0) { c }
        val quote = parts.getOrElse(1) { "USD" }
        return Instrument(c, c.replace("_", "/"), Cat.FOREX, base, quote, 100_000.0, c.replace("_", "/"), "OANDA:" + c.replace("_", ""))
    }

    /** XAUUSD, xau/usd and XAU_USD all become XAU_USD. */
    fun normalize(s: String): String {
        val u = s.trim().uppercase().replace("/", "_")
        return if (!u.contains("_") && u.length == 6) u.take(3) + "_" + u.drop(3) else u
    }

    fun label(code: String) = of(code)?.label ?: code.replace("_", "/")
}

/** Last known USD/JPY and USD/CAD, so lot size and risk in USD stay right on cross pairs. */
object Rates {
    @Volatile var usdJpy = 150.0
    @Volatile var usdCad = 1.36

    fun observe(code: String, price: Double) {
        if (price <= 0.0) return
        if (code == "USD_JPY") usdJpy = price
        if (code == "USD_CAD") usdCad = price
    }

    /** USD gained or lost per 1.0 price unit move on one standard lot. */
    fun usdPerUnitPerLot(inst: Instrument?): Double {
        val i = inst ?: return 1.0
        return when (i.quote) {
            "JPY" -> i.contract / usdJpy
            "CAD" -> i.contract / usdCad
            else -> i.contract
        }
    }
}
