package com.tradeaxis.app

import android.content.Context
import java.util.Locale

/** Evaluates the trader's own alert rules and the volatility watcher for one market. */
object AlertEngine {

    fun dayChangePct(candles: List<Candle>, price: Double, now: Long): Double {
        val ds = RiskGuard.dayStart(now)
        val first = candles.firstOrNull { it.time >= ds } ?: candles.firstOrNull() ?: return 0.0
        if (first.open <= 0.0) return 0.0
        return (price - first.open) / first.open * 100.0
    }

    private fun fire(ctx: Context, p: Prefs, r: AlertRule, title: String, body: String) {
        Notifier.send(ctx, AlertKind.PRICE, r.symbol, "", title, body, push = p.notifyPrice)
    }

    fun check(ctx: Context, p: Prefs, symbol: String, candles: List<Candle>, price: Double, scan: ScanResult?, now: Long) {
        if (candles.size < 3) return
        val day = now / 86_400_000L
        val label = Instruments.label(symbol)
        val dayPct = dayChangePct(candles, price, now)
        val recent = candles.takeLast(3)

        for (r in AlertRules.items.value.filter { it.symbol == symbol && it.enabled }) {
            when (r.type) {
                RuleType.PRICE_ABOVE -> {
                    val hi = maxOf(price, recent.maxOf { it.high })
                    if (r.refPrice < r.level && hi >= r.level) {
                        fire(ctx, p, r, "$label reached ${num(r.level)}", "Price rose to ${num(price)}.")
                        AlertRules.update(ctx, r.copy(refPrice = if (r.repeat) price else r.refPrice, enabled = r.repeat, lastFired = now))
                    } else if (r.refPrice >= r.level && price < r.level) {
                        AlertRules.update(ctx, r.copy(refPrice = price))      // re-arm
                    }
                }
                RuleType.PRICE_BELOW -> {
                    val lo = minOf(price, recent.minOf { it.low })
                    if (r.refPrice > r.level && lo <= r.level) {
                        fire(ctx, p, r, "$label fell to ${num(r.level)}", "Price dropped to ${num(price)}.")
                        AlertRules.update(ctx, r.copy(refPrice = if (r.repeat) price else r.refPrice, enabled = r.repeat, lastFired = now))
                    } else if (r.refPrice <= r.level && price > r.level) {
                        AlertRules.update(ctx, r.copy(refPrice = price))
                    }
                }
                RuleType.DAY_MOVE -> {
                    if (Math.abs(dayPct) >= r.level) {
                        val key = "d$day${if (dayPct >= 0) "+" else "-"}"
                        if (r.lastKey != key) {
                            fire(ctx, p, r, "$label ${if (dayPct >= 0) "up" else "down"} ${String.format(Locale.US, "%.2f", Math.abs(dayPct))}% today", "Price ${num(price)}.")
                            AlertRules.update(ctx, r.copy(lastKey = key, lastFired = now, enabled = true))
                        }
                    }
                }
                RuleType.PD_BREAK -> {
                    val snap = scan?.snaps?.values?.firstOrNull()
                    val pdh = snap?.pdh
                    val pdl = snap?.pdl
                    if (pdh != null && price > pdh && r.lastKey != "h$day") {
                        fire(ctx, p, r, "$label broke yesterday's high", "Price ${num(price)} is above ${num(pdh)}.")
                        AlertRules.update(ctx, r.copy(lastKey = "h$day", lastFired = now))
                    } else if (pdl != null && price < pdl && r.lastKey != "l$day") {
                        fire(ctx, p, r, "$label broke yesterday's low", "Price ${num(price)} is below ${num(pdl)}.")
                        AlertRules.update(ctx, r.copy(lastKey = "l$day", lastFired = now))
                    }
                }
                RuleType.VOLATILITY -> {
                    val v = volatility(candles)
                    if (v != null && v.second >= r.level && r.lastKey != "v${v.first}") {
                        fire(ctx, p, r, "$label volatility spike", "Last candle was ${String.format(Locale.US, "%.1f", v.second)}× the average range.")
                        AlertRules.update(ctx, r.copy(lastKey = "v${v.first}", lastFired = now))
                    }
                }
            }
        }

        // global volatility watcher (settings toggle)
        if (p.notifyVolatility) {
            val v = volatility(candles)
            val key = "vol|$symbol|${v?.first}"
            if (v != null && v.second >= p.volMult && key !in seenVol) {
                seenVol.add(key)
                if (seenVol.size > 300) seenVol.clear()
                Notifier.send(ctx, AlertKind.VOLATILITY, symbol, "", "$label volatility spike",
                    "Last closed candle was ${String.format(Locale.US, "%.1f", v.second)}× the average range — expect fast moves.", push = true)
            }
        }
    }

    private val seenVol = HashSet<String>()

    /** (time of last closed candle, its range ÷ average range of the 20 before it). */
    private fun volatility(candles: List<Candle>): Pair<Long, Double>? {
        if (candles.size < 25) return null
        val closed = candles.dropLast(1)
        val last = closed.last()
        val avg = closed.dropLast(1).takeLast(20).map { it.range }.average()
        if (avg.isNaN() || avg <= 0.0) return null
        return last.time to last.range / avg
    }
}
