package com.tradeaxis.app

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import java.util.Locale

fun verdictColor(v: Verdict): Color = when (v) { Verdict.TAKE -> UpGreen; Verdict.WATCH -> Amber; Verdict.BLOCKED -> DownRed }

@Composable
private fun Level(label: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(1.dp)) {
        Text(label, color = Muted, fontSize = 11.sp)
        Text(value, color = color, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1)
    }
}

/** One Copilot decision: Buy/Sell, levels, size, confidence, and why. */
@Composable
fun DecisionCard(d: Decision, compact: Boolean = false, onClick: () -> Unit) {
    val side = if (d.buy) "BUY" else "SELL"
    val sc = sideColor(d.buy)
    val vc = verdictColor(d.verdict)
    val s = d.setup
    Column(
        Modifier.fillMaxWidth().glass(accent = if (d.verdict == Verdict.BLOCKED) DownRed else sc).clickable(onClick = onClick).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(
                Modifier.clip(RoundedCornerShape(14.dp)).background(sc.copy(alpha = 0.18f)).padding(horizontal = 14.dp, vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) { Text(side, color = sc, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp) }
            Column(Modifier.weight(1f)) {
                Text(Instruments.label(d.symbol), fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                Text("${s.method.short} · ${d.tf} · grade ${s.grade}", color = Muted, style = MaterialTheme.typography.bodySmall, maxLines = 1)
            }
            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Pill(d.verdict.label, vc)
                if (!compact) Text("conf ${d.confidence}", color = vc, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
            if (compact) ConfidenceRing(d.confidence, "conf", vc, 52.dp)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Level("Entry", num(s.entry), Ink, Modifier.weight(1f))
            Level("Stop loss", num(s.sl), DownRed, Modifier.weight(1f))
            Level("TP1", num(s.tp1), UpGreen, Modifier.weight(1f))
            Level("TP2", num(s.tp2), UpGreen, Modifier.weight(1f))
        }
        if (d.lots > 0) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Size ${String.format(Locale.US, "%.2f", d.lots)} lots · risk \$${usd(d.riskUsd)}", color = Muted, style = MaterialTheme.typography.bodySmall)
                Text("Stop ${distTxt(d.symbol, s.risk)} · 1:${String.format(Locale.US, "%.1f", s.rr)}", color = Muted, style = MaterialTheme.typography.bodySmall)
            }
        }
        if (!compact) {
            if (d.blocks.isNotEmpty()) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("RISK GUARD", style = MaterialTheme.typography.titleSmall, color = DownRed)
                    d.blocks.forEach { CheckRow(false, it) }
                }
            }
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("WHY", style = MaterialTheme.typography.titleSmall, color = Muted)
                d.reasons.take(5).forEach { CheckRow(it.ok, it.text, dim = !it.ok) }
                d.notes.forEach { Text("• $it", color = Muted, style = MaterialTheme.typography.bodySmall) }
            }
        }
    }
}

@Composable
fun GuardCard(acc: Account, p: Prefs) {
    val stateColor = when (acc.state) { GuardState.SAFE -> UpGreen; GuardState.CAUTION -> Amber; GuardState.LOCKED -> DownRed }
    SectionCard(
        "Risk guard", accent = if (acc.state == GuardState.SAFE) null else stateColor,
        trailing = { Pill(if (p.guardOn) acc.state.label else "OFF", if (p.guardOn) stateColor else Muted) }
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatTile("Equity", "\$" + usd(acc.equity), modifier = Modifier.weight(1f))
            StatTile("Today", signedUsd(acc.todayPnl), if (acc.todayPnl >= 0) UpGreen else DownRed, Modifier.weight(1f))
        }
        if (p.guardOn) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Daily loss", color = Muted, style = MaterialTheme.typography.bodySmall)
                    Text("${String.format(Locale.US, "%.2f", acc.dailyUsedPct)}% of ${String.format(Locale.US, "%.1f", p.dailyLossPct)}%", style = MaterialTheme.typography.bodySmall)
                }
                BarMeter((acc.dailyUsedPct / p.dailyLossPct.coerceAtLeast(0.1f)).toFloat(), if (acc.dailyUsedPct >= p.dailyLossPct * 0.6) DownRed else UpGreen)
                Spacer(Modifier.height(2.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Drawdown", color = Muted, style = MaterialTheme.typography.bodySmall)
                    Text("${String.format(Locale.US, "%.2f", acc.ddPct)}% of ${String.format(Locale.US, "%.1f", p.maxDdPct)}%", style = MaterialTheme.typography.bodySmall)
                }
                BarMeter((acc.ddPct / p.maxDdPct.coerceAtLeast(0.1f)).toFloat(), if (acc.ddPct >= p.maxDdPct * 0.6) DownRed else Nova)
                if (p.profitTargetPct > 0) {
                    Spacer(Modifier.height(2.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Profit target", color = Muted, style = MaterialTheme.typography.bodySmall)
                        Text("${String.format(Locale.US, "%.0f", acc.progressPct.coerceAtLeast(0.0))}% of ${String.format(Locale.US, "%.0f", p.profitTargetPct)}%", style = MaterialTheme.typography.bodySmall)
                    }
                    BarMeter((acc.progressPct / 100.0).toFloat(), Cyan)
                }
            }
        }
        if (acc.reason.isNotEmpty()) Text(acc.reason, color = stateColor, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodySmall)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("${acc.openCount} open · risk \$${usd(acc.openRiskUsd)}", color = Muted, style = MaterialTheme.typography.bodySmall)
            Text("${acc.tradesToday} trades · ${acc.lossesToday} losses today", color = Muted, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun MarketRow(ins: Instrument, st: SymState?, onClick: () -> Unit) {
    val chg = st?.dayPct ?: 0.0
    val col = if (chg >= 0) UpGreen else DownRed
    val dec = st?.decisions?.values?.minByOrNull { it.verdict.ordinal }
    Row(
        Modifier.fillMaxWidth().glass(radius = 18.dp).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Column(Modifier.weight(1.1f)) {
            Text(ins.pair, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(ins.name, color = Muted, fontSize = 11.sp, maxLines = 1)
                if (st != null && st.htf != Bias.UNKNOWN) {
                    Box(Modifier.size(5.dp).background(when (st.htf) { Bias.BULL -> UpGreen; Bias.BEAR -> DownRed; else -> Muted }, CircleShape))
                }
            }
        }
        if (st != null && st.spark.size > 2) Sparkline(st.spark, col, Modifier.weight(1f).height(30.dp), dot = false)
        else Spacer(Modifier.weight(1f))
        Column(horizontalAlignment = Alignment.End, modifier = Modifier.weight(1.1f)) {
            Text(if (st != null) num(st.price) else "—", fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1)
            if (dec != null && dec.verdict != Verdict.BLOCKED) {
                Pill((if (dec.buy) "BUY" else "SELL") + " " + dec.confidence, sideColor(dec.buy))
            } else {
                Text(String.format(Locale.US, "%+.2f%%", chg), color = col, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun HomeScreen(
    ui: UiState,
    trades: List<TradeRecord>,
    p: Prefs,
    onToggle: () -> Unit,
    onOpenChart: (String) -> Unit,
    onOpenSettings: () -> Unit,
    onOpenTrade: () -> Unit,
    onOpenAlerts: () -> Unit
) {
    val ctx = LocalContext.current
    val acc = remember(trades, ui.lastUpdate, p.balance, p.guardOn, p.dailyLossPct, p.maxDdPct) { RiskGuard.account(p, trades, System.currentTimeMillis()) }
    val watched = p.watched()

    // when monitoring is off, the demo feed still previews prices so the screen is alive
    var preview by remember { mutableStateOf<Map<String, SymState>>(emptyMap()) }
    LaunchedEffect(ui.running, p.source, watched.joinToString()) {
        if (!ui.running && p.isDemo) {
            while (isActive) {
                val out = HashMap<String, SymState>()
                withContext(Dispatchers.IO) {
                    for (id in watched) {
                        try {
                            val c = Feed.fetch(Prefs(ctx), id, "M5", 120)
                            val px = c.last().close
                            PriceBook.set(id, px)
                            out[id] = SymState(id, px, AlertEngine.dayChangePct(c, px, System.currentTimeMillis()), c.takeLast(60).map { it.close }, Bias.UNKNOWN, "", 0.0, null, emptyMap(), System.currentTimeMillis())
                        } catch (_: Exception) { }
                    }
                }
                preview = out
                delay(4000)
            }
        }
    }

    val decisions = ui.decisions()
    Column(
        Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 16.dp)
            .then(Modifier),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        androidx.compose.foundation.lazy.LazyColumn(
            Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(top = 14.dp, bottom = 120.dp)
        ) {
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    NovaLogo(44.dp)
                    Column(Modifier.weight(1f)) {
                        Text("TradeAxis", style = MaterialTheme.typography.titleLarge)
                        Text("Plan • Analyze • Execute", color = Muted, style = MaterialTheme.typography.bodySmall)
                    }
                    if (p.isDemo) Pill("DEMO", Amber)
                }
            }
            item {
                GradientButton(
                    if (ui.running) "Stop monitoring" else "Start monitoring",
                    onToggle, Modifier.fillMaxWidth(), danger = ui.running
                )
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    GradientButton("New trade", onOpenTrade, Modifier.weight(1f), ico = Ico.Plus)
                    GhostButton("Alerts${if (ui.unseenAlerts > 0) " · ${ui.unseenAlerts}" else ""}", onOpenAlerts, Modifier.weight(1f))
                }
            }
            if (p.isDemo) item {
                GlassCard(accent = Amber) {
                    Text("Demo feed is on", fontWeight = FontWeight.Bold, color = Amber)
                    Text(
                        "Prices are simulated so you can explore every feature right away. They are not real market data — don't trade on them. " +
                            "Connect OANDA or Twelve Data in Settings for live prices.",
                        style = MaterialTheme.typography.bodySmall, color = Muted
                    )
                    GhostButton("Connect live data", onOpenSettings)
                }
            }
            if (ui.error != null) item {
                GlassCard(accent = DownRed) {
                    Text("Data problem", fontWeight = FontWeight.Bold, color = DownRed)
                    Text(ui.error, style = MaterialTheme.typography.bodySmall, color = Muted)
                }
            }
            item { GuardCard(acc, p) }
            item {
                SectionCard("Copilot · live signals", accent = if (decisions.any { it.verdict == Verdict.TAKE }) UpGreen else null) {
                    if (decisions.isEmpty()) {
                        Text(
                            if (ui.running) "Scanning ${watched.size} markets… Copilot only speaks when a setup passes the price engine, your history and the Risk Guard."
                            else "Start monitoring and Copilot will watch every market for you.",
                            color = Muted, style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }
            items(decisions.take(8), key = { it.id }) { d -> DecisionCard(d, onClick = { onOpenChart(d.symbol) }) }
            item {
                Text("MARKETS", style = MaterialTheme.typography.titleSmall, color = Muted, modifier = Modifier.padding(top = 4.dp, start = 4.dp))
            }
            items(Instruments.all.filter { it.id in watched }, key = { it.id }) { ins ->
                MarketRow(ins, ui.symbols[ins.id] ?: preview[ins.id]) { onOpenChart(ins.id) }
            }
            if (watched.isEmpty()) item {
                Text("No markets selected. Pick some in Settings → Markets.", color = Muted, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            }
            item {
                Text(
                    "Signals are analysis, not financial advice. Trading leveraged products can lose more than you expect.",
                    color = Muted.copy(alpha = 0.7f), style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
                )
            }
        }
    }
}
