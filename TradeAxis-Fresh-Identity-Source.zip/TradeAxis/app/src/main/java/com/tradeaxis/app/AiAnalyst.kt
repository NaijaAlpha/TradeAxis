package com.tradeaxis.app

import java.util.Calendar
import java.util.Locale
import java.util.TimeZone
import kotlin.math.abs
import kotlin.math.roundToInt

/** [tone]: 1 = strength, 0 = note, -1 = weakness. [muteKey] lets the user switch the weak spot off in one tap. */
data class Insight(val title: String, val detail: String, val tone: Int, val muteKey: String? = null, val muteLabel: String = "")

data class Edge(val n: Int, val winRate: Double, val avgR: Double)

/**
 * On-device pattern analysis of the trade journal. This is plain statistics (no cloud model, nothing leaves the phone):
 * it groups closed trades by market, method, session, weekday, side, grade and Copilot verdict, and flags where the
 * results are clearly better or worse than average. Small samples are labelled as such.
 */
object AiAnalyst {
    private const val MIN_N = 5

    fun session(ms: Long): String {
        val h = ((ms / 3_600_000L) % 24).toInt()
        return when {
            h < 7 -> "Asian"
            h < 12 -> "London"
            h < 17 -> "New York"
            else -> "Late NY"
        }
    }

    private fun weekday(ms: Long): String {
        val c = Calendar.getInstance(TimeZone.getTimeZone("UTC")); c.timeInMillis = ms
        return arrayOf("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday")[c.get(Calendar.DAY_OF_WEEK) - 1]
    }

    private fun scored(t: TradeRecord) = t.outcome == Outcome.WIN || t.outcome == Outcome.LOSS || t.outcome == Outcome.BE || t.outcome == Outcome.EXPIRED

    fun edgeOf(list: List<TradeRecord>): Edge? {
        val c = list.filter { scored(it) }
        if (c.isEmpty()) return null
        val wl = c.filter { it.outcome == Outcome.WIN || it.outcome == Outcome.LOSS }
        val wr = if (wl.isEmpty()) 0.0 else wl.count { it.outcome == Outcome.WIN }.toDouble() / wl.size
        return Edge(c.size, wr, c.sumOf { it.r } / c.size)
    }

    /** History of one method on one market, used by Copilot to nudge confidence. */
    fun edge(trades: List<TradeRecord>, symbol: String, method: Method): Edge? =
        edgeOf(trades.filter { it.symbol == symbol && it.method == method.name })

    private fun f1(v: Double) = String.format(Locale.US, "%+.2f", v)
    private fun pc(v: Double) = "${(v * 100).roundToInt()}%"

    private fun dimension(
        closed: List<TradeRecord>, overall: Edge, name: String, keyPrefix: String?,
        keyOf: (TradeRecord) -> String, labelOf: (String) -> String = { it }
    ): List<Insight> {
        val out = ArrayList<Insight>()
        val groups = closed.groupBy(keyOf).mapNotNull { (k, v) -> edgeOf(v)?.let { Triple(k, v, it) } }.filter { it.third.n >= MIN_N }
        if (groups.size < 2) return out
        val best = groups.maxByOrNull { it.third.avgR }!!
        val worst = groups.minByOrNull { it.third.avgR }!!
        if (best.third.avgR > 0.15 && best.third.avgR > overall.avgR + 0.1) {
            out += Insight(
                "Best $name: ${labelOf(best.first)}",
                "${best.third.n} trades · ${pc(best.third.winRate)} wins · ${f1(best.third.avgR)}R per trade (overall ${f1(overall.avgR)}R).",
                1
            )
        }
        if (worst.third.avgR < -0.15 && worst.third.avgR < overall.avgR - 0.1) {
            val mk = keyPrefix?.let { "$it:${worst.first}" }
            out += Insight(
                "Weakest $name: ${labelOf(worst.first)}",
                "${worst.third.n} trades · ${pc(worst.third.winRate)} wins · ${f1(worst.third.avgR)}R per trade. Consider skipping these setups.",
                -1, mk, "Mute ${labelOf(worst.first)}"
            )
        }
        return out
    }

    fun analyze(trades: List<TradeRecord>): List<Insight> {
        val closed = trades.filter { scored(it) }.sortedBy { it.openTime }
        val overall = edgeOf(closed)
        if (overall == null || closed.size < 8) {
            val need = 8 - closed.size
            return listOf(
                Insight(
                    "Learning your results",
                    "Pattern analysis needs at least 8 closed signals (${maxOf(0, need)} more). Keep monitoring or run a backtest, then check back here.",
                    0
                )
            )
        }
        val out = ArrayList<Insight>()
        val be = 1.0 / (1.0 + closed.map { it.rr }.average())
        out += Insight(
            "Expectancy ${f1(overall.avgR)}R per trade",
            "${closed.size} closed · ${pc(overall.winRate)} win rate. At your average reward of 1:${String.format(Locale.US, "%.1f", closed.map { it.rr }.average())} the break-even win rate is ${pc(be)}.",
            if (overall.avgR > 0.05) 1 else if (overall.avgR < -0.05) -1 else 0
        )
        if (closed.size < 30) {
            out += Insight("Small sample", "Only ${closed.size} trades so far. Treat the patterns below as hints, not proof — they firm up after 30 or more.", 0)
        }

        out += dimension(closed, overall, "market", "symbol", { it.symbol }, { Instruments.label(it) })
        out += dimension(closed, overall, "entry method", "method", { it.method }, { k -> Method.values().firstOrNull { it.name == k }?.short ?: k })
        out += dimension(closed, overall, "session", "session", { session(it.openTime) }, { "$it session" })
        out += dimension(closed, overall, "weekday", null, { weekday(it.openTime) })
        out += dimension(closed, overall, "direction", null, { if (it.side == Dir.BULLISH) "BUY" else "SELL" })

        // does the grade / Copilot confidence mean anything?
        val hi = closed.filter { it.grade == "A+" || it.grade == "A" }
        val lo = closed.filter { it.grade == "B" || it.grade == "C" }
        val eh = edgeOf(hi)
        val el = edgeOf(lo)
        if (eh != null && el != null && eh.n >= MIN_N && el.n >= MIN_N) {
            if (eh.avgR > el.avgR + 0.15) out += Insight("High grades pay off", "A / A+ signals: ${f1(eh.avgR)}R vs B / C: ${f1(el.avgR)}R. Raising the minimum score is worth considering.", 1)
            else if (el.avgR > eh.avgR + 0.15) out += Insight("Grades are not predictive yet", "B / C signals did better (${f1(el.avgR)}R) than A / A+ (${f1(eh.avgR)}R) in this sample.", 0)
        }
        val take = edgeOf(closed.filter { it.copilot == "TAKE" })
        val watch = edgeOf(closed.filter { it.copilot == "WATCH" })
        if (take != null && watch != null && take.n >= MIN_N && watch.n >= MIN_N) {
            out += Insight(
                if (take.avgR >= watch.avgR) "Copilot TAKE calls beat WATCH calls" else "Copilot WATCH calls did better than TAKE",
                "TAKE: ${f1(take.avgR)}R over ${take.n} trades · WATCH: ${f1(watch.avgR)}R over ${watch.n} trades.",
                if (take.avgR >= watch.avgR) 1 else 0
            )
        }

        // behaviour after losses
        val after = ArrayList<TradeRecord>()
        for (i in 2 until closed.size) {
            if (closed[i - 1].outcome == Outcome.LOSS && closed[i - 2].outcome == Outcome.LOSS) after += closed[i]
        }
        val ea = edgeOf(after)
        if (ea != null && ea.n >= MIN_N && ea.avgR < overall.avgR - 0.3) {
            out += Insight(
                "Trades after two losses do worse",
                "${ea.n} such trades averaged ${f1(ea.avgR)}R vs ${f1(overall.avgR)}R overall. A pause after two losses may help.",
                -1
            )
        }
        // order: weaknesses first so they are seen
        return out.sortedBy { it.tone }
    }

    /** Candidate keys for the Copilot mute check. */
    fun keysFor(symbol: String, method: Method, ms: Long): List<String> =
        listOf("symbol:$symbol", "method:${method.name}", "session:${session(ms)}")
}
