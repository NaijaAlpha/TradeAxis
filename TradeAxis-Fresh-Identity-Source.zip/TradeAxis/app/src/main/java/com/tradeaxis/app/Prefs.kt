package com.tradeaxis.app

import android.content.Context

private const val DEFAULT_API_KEY = ""
private const val DEFAULT_OANDA_TOKEN = ""

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE)

    var apiKey: String get() = sp.getString("apiKey", DEFAULT_API_KEY) ?: DEFAULT_API_KEY; set(v) = sp.edit().putString("apiKey", v).apply()
    var symbol: String get() = sp.getString("symbol", "XAU_USD") ?: "XAU_USD"; set(v) = sp.edit().putString("symbol", v).apply()
    var tf: String get() = sp.getString("tf", "M5") ?: "M5"; set(v) = sp.edit().putString("tf", v).apply()
    var pollSec: Int get() = sp.getInt("pollSec", 120); set(v) = sp.edit().putInt("pollSec", v).apply()
    var bearish: Boolean get() = sp.getBoolean("bearish", true); set(v) = sp.edit().putBoolean("bearish", v).apply()
    var bullish: Boolean get() = sp.getBoolean("bullish", true); set(v) = sp.edit().putBoolean("bullish", v).apply()
    var reqOb: Boolean get() = sp.getBoolean("reqOb", true); set(v) = sp.edit().putBoolean("reqOb", v).apply()
    var reqSweep: Boolean get() = sp.getBoolean("reqSweep", true); set(v) = sp.edit().putBoolean("reqSweep", v).apply()
    var reqDisp: Boolean get() = sp.getBoolean("reqDisp", true); set(v) = sp.edit().putBoolean("reqDisp", v).apply()
    var sweepPdOnly: Boolean get() = sp.getBoolean("sweepPdOnly", true); set(v) = sp.edit().putBoolean("sweepPdOnly", v).apply()
    var dispMult: Float get() = sp.getFloat("dispMult", 1.5f); set(v) = sp.edit().putFloat("dispMult", v).apply()
    var sweepLookback: Int get() = sp.getInt("sweepLookback", 12); set(v) = sp.edit().putInt("sweepLookback", v).apply()
    var signals: Boolean get() = sp.getBoolean("signals", true); set(v) = sp.edit().putBoolean("signals", v).apply()
    var rr: Float get() = sp.getFloat("rr", 2.0f); set(v) = sp.edit().putFloat("rr", v).apply()
    var expiryHours: Int get() = sp.getInt("expiryHours", 24); set(v) = sp.edit().putInt("expiryHours", v).apply()
    var cooldownMin: Int get() = sp.getInt("cooldownMin", 30); set(v) = sp.edit().putInt("cooldownMin", v).apply()
    var hoursOn: Boolean get() = sp.getBoolean("hoursOn", false); set(v) = sp.edit().putBoolean("hoursOn", v).apply()
    var hoursStart: Int get() = sp.getInt("hoursStart", 7); set(v) = sp.edit().putInt("hoursStart", v).apply()
    var hoursEnd: Int get() = sp.getInt("hoursEnd", 20); set(v) = sp.edit().putInt("hoursEnd", v).apply()
    var notifyOutcome: Boolean get() = sp.getBoolean("notifyOutcome", true); set(v) = sp.edit().putBoolean("notifyOutcome", v).apply()
    var source: String get() = sp.getString("source", "DEMO") ?: "DEMO"; set(v) = sp.edit().putString("source", v).apply()
    var oandaToken: String get() = sp.getString("oandaToken", DEFAULT_OANDA_TOKEN) ?: DEFAULT_OANDA_TOKEN; set(v) = sp.edit().putString("oandaToken", v).apply()
    var oandaLive: Boolean get() = sp.getBoolean("oandaLive", false); set(v) = sp.edit().putBoolean("oandaLive", v).apply()
    var dayStartHour: Int get() = sp.getInt("dayStartHour", 0); set(v) = sp.edit().putInt("dayStartHour", v).apply()
    var methods: String get() = sp.getString("methods", Method.values().joinToString(",") { it.name }) ?: ""; set(v) = sp.edit().putString("methods", v).apply()
    var minScore: Int get() = sp.getInt("minScore", 55); set(v) = sp.edit().putInt("minScore", v).apply()
    var htfFilter: Boolean get() = sp.getBoolean("htfFilter", false); set(v) = sp.edit().putBoolean("htfFilter", v).apply()
    var beAfterTp1: Boolean get() = sp.getBoolean("beAfterTp1", false); set(v) = sp.edit().putBoolean("beAfterTp1", v).apply()
    var balance: Float get() = sp.getFloat("balance", 1000f); set(v) = sp.edit().putFloat("balance", v).apply()
    var riskPct: Float get() = sp.getFloat("riskPct", 1f); set(v) = sp.edit().putFloat("riskPct", v).apply()
    var contract: Float get() = sp.getFloat("contract", 100f); set(v) = sp.edit().putFloat("contract", v).apply()
    var maxLossesPerDay: Int get() = sp.getInt("maxLossesPerDay", 3); set(v) = sp.edit().putInt("maxLossesPerDay", v).apply()
    var immersive: Boolean get() = sp.getBoolean("immersive", true); set(v) = sp.edit().putBoolean("immersive", v).apply()
    var keepAwake: Boolean get() = sp.getBoolean("keepAwake", true); set(v) = sp.edit().putBoolean("keepAwake", v).apply()
    var backtestCandles: Int get() = sp.getInt("backtestCandles", 1500); set(v) = sp.edit().putInt("backtestCandles", v).apply()

    // ── TradeAxis: watchlist, copilot and prop guard ──
    var watch: String get() = sp.getString("watch", Instruments.all.joinToString(",") { it.code }) ?: ""; set(v) = sp.edit().putString("watch", v).apply()
    var guardOn: Boolean get() = sp.getBoolean("guardOn", true); set(v) = sp.edit().putBoolean("guardOn", v).apply()
    var dailyLossPct: Float get() = sp.getFloat("dailyLossPct", 4f); set(v) = sp.edit().putFloat("dailyLossPct", v).apply()

    // ── data source helper ──
    val isDemo: Boolean get() = source == "DEMO"

    // ── Risk guard (prop-firm style rules) ──
    var maxDdPct: Float get() = sp.getFloat("maxDdPct", 8f); set(v) = sp.edit().putFloat("maxDdPct", v).apply()
    var profitTargetPct: Float get() = sp.getFloat("profitTargetPct", 0f); set(v) = sp.edit().putFloat("profitTargetPct", v).apply()
    var maxOpen: Int get() = sp.getInt("maxOpen", 4); set(v) = sp.edit().putInt("maxOpen", v).apply()
    var maxTradesDay: Int get() = sp.getInt("maxTradesDay", 6); set(v) = sp.edit().putInt("maxTradesDay", v).apply()
    var maxOpenRiskPct: Float get() = sp.getFloat("maxOpenRiskPct", 3f); set(v) = sp.edit().putFloat("maxOpenRiskPct", v).apply()
    var corrGuard: Boolean get() = sp.getBoolean("corrGuard", true); set(v) = sp.edit().putBoolean("corrGuard", v).apply()
    var weekendGuard: Boolean get() = sp.getBoolean("weekendGuard", true); set(v) = sp.edit().putBoolean("weekendGuard", v).apply()
    var cutRiskInDd: Boolean get() = sp.getBoolean("cutRiskInDd", true); set(v) = sp.edit().putBoolean("cutRiskInDd", v).apply()

    // ── Copilot ──
    var takeConf: Int get() = sp.getInt("takeConf", 65); set(v) = sp.edit().putInt("takeConf", v).apply()
    var useEdge: Boolean get() = sp.getBoolean("useEdge", true); set(v) = sp.edit().putBoolean("useEdge", v).apply()
    var alertWatch: Boolean get() = sp.getBoolean("alertWatch", false); set(v) = sp.edit().putBoolean("alertWatch", v).apply()
    var muted: String get() = sp.getString("muted", "") ?: ""; set(v) = sp.edit().putString("muted", v).apply()

    // ── Notifications ──
    var notifyPrice: Boolean get() = sp.getBoolean("notifyPrice", true); set(v) = sp.edit().putBoolean("notifyPrice", v).apply()
    var notifyGuard: Boolean get() = sp.getBoolean("notifyGuard", true); set(v) = sp.edit().putBoolean("notifyGuard", v).apply()
    var notifyBlocked: Boolean get() = sp.getBoolean("notifyBlocked", false); set(v) = sp.edit().putBoolean("notifyBlocked", v).apply()
    var notifyVolatility: Boolean get() = sp.getBoolean("notifyVolatility", false); set(v) = sp.edit().putBoolean("notifyVolatility", v).apply()
    var volMult: Float get() = sp.getFloat("volMult", 3f); set(v) = sp.edit().putFloat("volMult", v).apply()

    // ── Chart and app ──
    var chartTf: String get() = sp.getString("chartTf", "M5") ?: "M5"; set(v) = sp.edit().putString("chartTf", v).apply()
    var chartStyle: Int get() = sp.getInt("chartStyle", 0); set(v) = sp.edit().putInt("chartStyle", v).apply()
    var showEma: Boolean get() = sp.getBoolean("showEma", true); set(v) = sp.edit().putBoolean("showEma", v).apply()
    var showSmc: Boolean get() = sp.getBoolean("showSmc", true); set(v) = sp.edit().putBoolean("showSmc", v).apply()
    var showTrades: Boolean get() = sp.getBoolean("showTrades", true); set(v) = sp.edit().putBoolean("showTrades", v).apply()
    var chartMode: String get() = sp.getString("chartMode", "NATIVE") ?: "NATIVE"; set(v) = sp.edit().putString("chartMode", v).apply()
    var showIntro: Boolean get() = sp.getBoolean("showIntro", true); set(v) = sp.edit().putBoolean("showIntro", v).apply()

    /** Markets being monitored, in watchlist order. */
    fun watched(): List<String> = watchlist()

    /** Keys the user muted from the AI analysis (weak markets, methods, sessions). */
    fun mutedSet(): Set<String> = muted.split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet()

    fun mute(key: String, on: Boolean) {
        val cur = mutedSet().toMutableSet()
        if (on) cur.add(key) else cur.remove(key)
        muted = cur.joinToString(",")
    }

    fun watchlist(): List<String> =
        watch.split(",").map { it.trim() }.filter { c -> Instruments.of(c) != null }

    fun setWatched(code: String, on: Boolean) {
        val cur = watchlist().toMutableList()
        if (on && code !in cur) cur.add(code)
        if (!on) cur.remove(code)
        watch = cur.joinToString(",")
    }

    fun methodSet(): Set<Method> =
        methods.split(",").mapNotNull { n -> Method.values().firstOrNull { it.name == n } }.toSet()

    fun setMethod(m: Method, on: Boolean) {
        val cur = methodSet().toMutableSet()
        if (on) cur.add(m) else cur.remove(m)
        methods = cur.joinToString(",") { it.name }
    }

    fun config(): Config = Config(
        dispMult = dispMult.toDouble(),
        sweepLookback = sweepLookback,
        sweepPdOnly = sweepPdOnly,
        dayStartHourUtc = dayStartHour,
        rr = rr.toDouble(),
        htfFilter = htfFilter
    )
}
