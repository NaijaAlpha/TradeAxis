package com.tradeaxis.app

import kotlin.math.abs

data class Candle(val time: Long, val open: Double, val high: Double, val low: Double, val close: Double) {
    val body get() = abs(close - open)
    val range get() = high - low
}

enum class Dir { BEARISH, BULLISH }

data class Zone(val low: Double, val high: Double, val dir: Dir, val time: Long) {
    fun contains(p: Double) = p in low..high
}

data class Sweep(val dir: Dir, val level: Double, val label: String, val barsAgo: Int)
data class Displacement(val dir: Dir, val barsAgo: Int)

data class Signal(val side: Dir, val entry: Double, val sl: Double, val tp: Double, val rr: Double) {
    val risk get() = abs(entry - sl)
}

data class Config(
    val dispMult: Double = 1.5,        // body must be >= 1.5x avg body of previous 20 candles
    val dispBodyRatio: Double = 0.6,   // body must be >= 60% of candle range
    val dispLookback: Int = 6,         // displacement must be within last N candles
    val obLookback: Int = 40,
    val fvgLookback: Int = 60,
    val sweepLookback: Int = 12,
    val sweepPdOnly: Boolean = true,   // true: only previous-day high/low counts as liquidity
    val dayStartHourUtc: Int = 0,      // UTC hour when the trading day starts (for previous-day high/low)
    val rr: Double = 2.0,              // TP2 = risk x rr
    val minRiskAtr: Double = 0.3,      // ignore setups whose stop is tighter than 0.3 ATR
    val maxRiskAtr: Double = 8.0,      // ignore setups whose stop is wider than 8 ATR
    val htfFilter: Boolean = false,    // true: block setups against the higher-timeframe trend
    val retestLookback: Int = 30       // how far back a displacement / break may be for retest entries
)

data class Rule(
    val dir: Dir = Dir.BEARISH,
    val requireOb: Boolean = true,
    val requireSweep: Boolean = true,
    val requireDisplacement: Boolean = true
)

data class Snapshot(
    val symbol: String, val tf: String, val price: Double, val dir: Dir,
    val pdh: Double?, val pdl: Double?,
    val ob: Zone?, val fvg: Zone?,
    val sweep: Sweep?, val displacement: Displacement?
) {
    val inOb get() = ob?.contains(price) == true
}

object SmcEngine {

    /** [all] = candles oldest -> newest; the LAST one is the forming (live) candle. */
    fun analyze(all: List<Candle>, symbol: String, tf: String, dir: Dir, cfg: Config): Snapshot? {
        if (all.size < 60) return null
        val closed = all.dropLast(1)
        val price = all.last().close
        val (pdh, pdl) = previousDayRange(all, cfg.dayStartHourUtc)
        return Snapshot(
            symbol, tf, price, dir, pdh, pdl,
            ob = findOrderBlock(closed, dir, cfg),
            fvg = findFvg(closed, dir, cfg),
            sweep = findSweep(all, dir, pdh, pdl, cfg),
            displacement = findDisplacement(closed, dir, cfg)
        )
    }

    private fun avgRange(c: List<Candle>, n: Int = 14): Double {
        val tail = c.takeLast(n)
        return if (tail.isEmpty()) 0.0 else tail.map { it.range }.average()
    }

    /**
     * Entry = live price. SL = beyond the OB / sweep wick (whichever is further) + 0.2x avg range buffer.
     * TP = entry -/+ risk * rr. Bearish -> SELL, bullish -> BUY.
     */
    fun signal(all: List<Candle>, s: Snapshot, rr: Double, bufferMult: Double = 0.2): Signal? {
        val bear = s.dir == Dir.BEARISH
        val buffer = avgRange(all.dropLast(1)) * bufferMult
        val ext = mutableListOf<Double>()
        s.ob?.let { ext += if (bear) it.high else it.low }
        s.sweep?.let { sw ->
            val seg = all.subList((all.size - 1 - sw.barsAgo).coerceAtLeast(0), all.size)
            ext += if (bear) seg.maxOf { it.high } else seg.minOf { it.low }
        }
        if (ext.isEmpty()) {
            val seg = all.takeLast(10)
            ext += if (bear) seg.maxOf { it.high } else seg.minOf { it.low }
        }
        val entry = s.price
        val sl = if (bear) ext.maxOf { it } + buffer else ext.minOf { it } - buffer
        val risk = if (bear) sl - entry else entry - sl
        if (risk <= 0.0) return null
        val tp = if (bear) entry - risk * rr else entry + risk * rr
        return Signal(s.dir, entry, sl, tp, rr)
    }

    fun triggered(s: Snapshot, r: Rule): Boolean {
        if (r.requireOb && !s.inOb) return false
        if (r.requireSweep && s.sweep == null) return false
        if (r.requireDisplacement && s.displacement == null) return false
        return true
    }

    // Previous UTC day's high/low (skips weekends automatically: uses the day before the latest one present).
    private fun previousDayRange(all: List<Candle>, startHour: Int): Pair<Double?, Double?> {
        val byDay = all.groupBy { (it.time - startHour * 3_600_000L) / 86_400_000L }
        val days = byDay.keys.sorted()
        if (days.size < 2) return null to null
        val prev = byDay[days[days.size - 2]]!!
        return prev.maxOf { it.high } to prev.minOf { it.low }
    }

    fun isDisplacement(c: List<Candle>, i: Int, dir: Dir, cfg: Config): Boolean {
        if (i < 21) return false
        val k = c[i]
        val dirOk = if (dir == Dir.BEARISH) k.close < k.open else k.close > k.open
        if (!dirOk || k.range <= 0) return false
        val avg = (i - 20 until i).map { c[it].body }.average()
        return k.body >= cfg.dispMult * avg && k.body / k.range >= cfg.dispBodyRatio
    }

    private fun findDisplacement(c: List<Candle>, dir: Dir, cfg: Config): Displacement? {
        for (ago in 0 until cfg.dispLookback) {
            val i = c.lastIndex - ago
            if (isDisplacement(c, i, dir, cfg)) return Displacement(dir, ago)
        }
        return null
    }

    // Bearish OB = last bullish candle before a bearish displacement (mirror for bullish).
    // Invalidated once a later candle closes beyond the OB.
    private fun findOrderBlock(c: List<Candle>, dir: Dir, cfg: Config): Zone? {
        val start = c.lastIndex
        val stop = maxOf(21, c.size - cfg.obLookback)
        for (i in start downTo stop) {
            if (!isDisplacement(c, i, dir, cfg)) continue
            for (j in i - 1 downTo maxOf(0, i - 5)) {
                val k = c[j]
                val opposite = if (dir == Dir.BEARISH) k.close > k.open else k.close < k.open
                if (!opposite) continue
                val broken = (j + 1..c.lastIndex).any {
                    if (dir == Dir.BEARISH) c[it].close > k.high else c[it].close < k.low
                }
                if (!broken) return Zone(k.low, k.high, dir, k.time)
                break
            }
        }
        return null
    }

    // 3-candle imbalance, most recent one not yet fully filled.
    fun findFvg(c: List<Candle>, dir: Dir, cfg: Config): Zone? {
        for (k in c.lastIndex downTo maxOf(2, c.size - cfg.fvgLookback)) {
            val c1 = c[k - 2]; val c3 = c[k]
            if (dir == Dir.BEARISH && c1.low > c3.high) {
                val z = Zone(c3.high, c1.low, dir, c[k - 1].time)
                if ((k + 1..c.lastIndex).none { c[it].high >= z.high }) return z
            }
            if (dir == Dir.BULLISH && c1.high < c3.low) {
                val z = Zone(c1.high, c3.low, dir, c[k - 1].time)
                if ((k + 1..c.lastIndex).none { c[it].low <= z.low }) return z
            }
        }
        return null
    }

    // Bearish sweep: wick above a high, close back below it. Bullish: mirror on lows.
    fun findSweep(all: List<Candle>, dir: Dir, pdh: Double?, pdl: Double?, cfg: Config): Sweep? {
        for (ago in 0 until cfg.sweepLookback) {
            val i = all.lastIndex - ago
            val k = all[i]
            val levels = mutableListOf<Pair<String, Double>>()
            if (dir == Dir.BEARISH) {
                pdh?.let { levels += "Previous Day High" to it }
                if (!cfg.sweepPdOnly) swings(all, i, true).forEach { levels += "Swing High" to it }
                levels.firstOrNull { k.high > it.second && k.close < it.second }
                    ?.let { return Sweep(dir, it.second, it.first, ago) }
            } else {
                pdl?.let { levels += "Previous Day Low" to it }
                if (!cfg.sweepPdOnly) swings(all, i, false).forEach { levels += "Swing Low" to it }
                levels.firstOrNull { k.low < it.second && k.close > it.second }
                    ?.let { return Sweep(dir, it.second, it.first, ago) }
            }
        }
        return null
    }

    // Fractal swing highs/lows (2 bars each side) that formed before candle [before].
    private fun swings(c: List<Candle>, before: Int, highs: Boolean): List<Double> {
        val out = mutableListOf<Double>()
        for (j in maxOf(2, before - 80)..before - 3) {
            val v = if (highs) c[j].high else c[j].low
            val ok = (-2..2).filter { it != 0 }.all {
                if (highs) v > c[j + it].high else v < c[j + it].low
            }
            if (ok) out += v
        }
        return out
    }
}
