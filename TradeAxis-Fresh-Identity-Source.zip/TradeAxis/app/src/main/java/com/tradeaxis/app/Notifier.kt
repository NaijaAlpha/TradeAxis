package com.tradeaxis.app

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

object Notifier {
    const val CH_SIGNAL = "tn_signals"
    const val CH_ALERT = "tn_alerts"
    const val CH_RISK = "tn_risk"
    const val CH_RESULT = "tn_results"
    const val CH_STATUS = "tn_status"
    const val STATUS_ID = 1

    fun channels(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(NotificationManager::class.java)
        fun ch(id: String, name: String, imp: Int, desc: String) {
            if (nm.getNotificationChannel(id) == null) {
                nm.createNotificationChannel(NotificationChannel(id, name, imp).apply { description = desc; enableVibration(imp >= NotificationManager.IMPORTANCE_DEFAULT) })
            }
        }
        ch(CH_SIGNAL, "Buy / Sell signals", NotificationManager.IMPORTANCE_HIGH, "Copilot-approved trade signals")
        ch(CH_ALERT, "Price & market alerts", NotificationManager.IMPORTANCE_HIGH, "Your price rules, daily moves, volatility spikes")
        ch(CH_RISK, "Risk guard", NotificationManager.IMPORTANCE_HIGH, "Daily loss, drawdown and trading locks")
        ch(CH_RESULT, "Trade results", NotificationManager.IMPORTANCE_DEFAULT, "Take profit, stop loss and expiry")
        ch(CH_STATUS, "Monitoring status", NotificationManager.IMPORTANCE_LOW, "Shown while TradeAxis watches the markets")
    }

    fun canPost(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun open(ctx: Context): PendingIntent =
        PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    private fun channelFor(kind: AlertKind) = when (kind) {
        AlertKind.SIGNAL -> CH_SIGNAL
        AlertKind.PRICE, AlertKind.VOLATILITY -> CH_ALERT
        AlertKind.RISK -> CH_RISK
        AlertKind.RESULT -> CH_RESULT
        AlertKind.BLOCKED -> CH_ALERT
        AlertKind.SYSTEM -> CH_STATUS
    }

    /** Records the alert in the in-app feed and, if allowed, posts a system notification. */
    fun send(ctx: Context, kind: AlertKind, symbol: String, side: String, title: String, body: String, push: Boolean = true) {
        val app = ctx.applicationContext
        AlertHistory.add(app, AlertRecord(System.currentTimeMillis(), kind, symbol, side, title, body))
        MonitorState.update { it.copy(unseenAlerts = it.unseenAlerts + 1) }
        if (!push || !canPost(app)) return
        channels(app)
        val n = NotificationCompat.Builder(app, channelFor(kind))
            .setSmallIcon(R.drawable.ic_stat_nova)
            .setContentTitle(title)
            .setContentText(body.lineSequence().firstOrNull() ?: body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setContentIntent(open(app))
            .setAutoCancel(true)
            .setPriority(if (kind == AlertKind.RESULT) NotificationCompat.PRIORITY_DEFAULT else NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setColor(0xFF8B6BFF.toInt())
            .build()
        val id = (System.currentTimeMillis() % Int.MAX_VALUE).toInt().coerceAtLeast(100)
        try { app.getSystemService(NotificationManager::class.java).notify(id, n) } catch (_: SecurityException) { }
    }

    fun statusNotification(ctx: Context, text: String): Notification {
        channels(ctx)
        return NotificationCompat.Builder(ctx, CH_STATUS)
            .setSmallIcon(R.drawable.ic_stat_nova)
            .setContentTitle("TradeAxis is watching")
            .setContentText(text)
            .setContentIntent(open(ctx))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setColor(0xFF8B6BFF.toInt())
            .build()
    }

    fun updateStatus(ctx: Context, text: String) {
        if (!canPost(ctx)) return
        try { ctx.getSystemService(NotificationManager::class.java).notify(STATUS_ID, statusNotification(ctx, text)) } catch (_: SecurityException) { }
    }
}

object AlertText {
    fun signalTitle(d: Decision): String {
        val side = if (d.buy) "BUY" else "SELL"
        val tag = when (d.verdict) { Verdict.TAKE -> "TAKE"; Verdict.WATCH -> "WATCH"; Verdict.BLOCKED -> "BLOCKED" }
        return "$side ${Instruments.label(d.symbol)} · $tag ${d.confidence}"
    }

    fun signalBody(d: Decision): String {
        val s = d.setup
        val sb = StringBuilder()
        sb.append(s.method.label).append(" · ").append(d.tf).append(" · grade ").append(s.grade).append('\n')
        sb.append("Entry ").append(num(s.entry)).append("   SL ").append(num(s.sl)).append('\n')
        sb.append("TP1 ").append(num(s.tp1)).append("   TP2 ").append(num(s.tp2)).append("  (1:").append(String.format(java.util.Locale.US, "%.1f", s.rr)).append(")\n")
        if (d.lots > 0) sb.append("Size ").append(String.format(java.util.Locale.US, "%.2f", d.lots)).append(" lots · risk $").append(usd(d.riskUsd))
        if (d.blocks.isNotEmpty()) sb.append('\n').append("Guard: ").append(d.blocks.first())
        return sb.toString().trim()
    }
}
