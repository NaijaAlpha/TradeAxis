package com.tradeaxis.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object BacktestRunner {
    suspend fun run(p: Prefs, symbol: String, onProgress: (Int, Int) -> Unit): BtResult = withContext(Dispatchers.Default) {
        val tf = p.tf
        val htfTf = Backtester.htfOf(tf)
        val count = p.backtestCandles
        val candles = Feed.fetch(p, symbol, tf, count)
        if (candles.size < 260) throw IllegalStateException("Only ${candles.size} candles available — need at least 260")
        val ratio = Backtester.periodMs(htfTf).toDouble() / Backtester.periodMs(tf)
        val htfCount = (candles.size / ratio).toInt() + 120
        val htf = try { Feed.fetch(p, symbol, htfTf, htfCount.coerceAtMost(2000)) } catch (_: Exception) { emptyList() }
        val s = BtSettings(
            symbol = symbol, tf = tf, cfg = p.config(),
            rule = Rule(Dir.BEARISH, p.reqOb, p.reqSweep, p.reqDisp),
            enabled = p.methodSet(), minScore = p.minScore, cooldownMin = p.cooldownMin,
            hoursOn = p.hoursOn, hoursStart = p.hoursStart, hoursEnd = p.hoursEnd,
            expiryHours = p.expiryHours, beAfterTp1 = p.beAfterTp1
        )
        Backtester.run(candles, htf, htfTf, s, onProgress)
    }
}
