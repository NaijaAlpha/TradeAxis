package com.tradeaxis.app

import android.annotation.SuppressLint
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt

data class ChartLevel(val price: Double, val label: String, val color: Color, val dashed: Boolean = true)
data class ChartZone(val low: Double, val high: Double, val label: String, val color: Color)
data class ChartOverlays(val levels: List<ChartLevel> = emptyList(), val zones: List<ChartZone> = emptyList())

private const val RIGHT_PAD = 6f
private val TF_LIST = listOf("M1", "M5", "M15", "M30", "H1", "H4")
private val STYLE_NAMES = listOf("Candles", "Line", "Area")

private fun niceStep(raw: Double): Double {
    if (raw <= 0.0 || raw.isNaN()) return 1.0
    val e = floor(log10(raw))
    val f = raw / 10.0.pow(e)
    val nf = when { f < 1.5 -> 1.0; f < 3.0 -> 2.0; f < 7.0 -> 5.0; else -> 10.0 }
    return nf * 10.0.pow(e)
}

private fun DrawScope.axisTag(tm: TextMeasurer, text: String, x: Float, w: Float, y: Float, bg: Color) {
    val lay = tm.measure(text, TextStyle(color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold))
    val h = lay.size.height + 6.dp.toPx()
    drawRoundRect(bg, Offset(x, y - h / 2), Size(w, h), CornerRadius(4.dp.toPx()))
    drawText(lay, topLeft = Offset(x + (w - lay.size.width) / 2f, y - lay.size.height / 2f))
}

/** TradingView-style native chart: drag to scroll, pinch to zoom, double-tap to reset, crosshair mode for exact values. */
@Composable
fun CandleChart(
    symbol: String,
    tf: String,
    candles: List<Candle>,
    overlays: ChartOverlays,
    style: Int,
    showEma: Boolean,
    showOverlays: Boolean,
    crosshairOn: Boolean,
    modifier: Modifier = Modifier
) {
    val tm = rememberTextMeasurer()
    val density = LocalDensity.current
    var visible by remember(symbol, tf) { mutableFloatStateOf(80f) }
    var offset by remember(symbol, tf) { mutableFloatStateOf(0f) }
    var cross by remember { mutableStateOf<Offset?>(null) }
    var plotW by remember { mutableFloatStateOf(1f) }
    val n = candles.size
    val nNow by rememberUpdatedState(n)
    val closes = remember(candles) { candles.map { it.close } }
    val ema20 = remember(candles) { if (closes.isEmpty()) DoubleArray(0) else Scanner.ema(closes, 20) }
    val ema50 = remember(candles) { if (closes.isEmpty()) DoubleArray(0) else Scanner.ema(closes, 50) }
    val hm = remember { SimpleDateFormat("HH:mm", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") } }
    val dm = remember { SimpleDateFormat("d MMM", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") } }
    val full = remember { SimpleDateFormat("EEE d MMM HH:mm", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") } }
    val dayTf = tf == "H4"

    Box(
        modifier
            .onSizeChanged { plotW = (it.width - with(density) { 66.dp.toPx() }).coerceAtLeast(1f) }
            .pointerInput(symbol, tf) { detectTapGestures(onDoubleTap = { visible = 80f; offset = 0f }) }
            .pointerInput(crosshairOn, symbol, tf) {
                if (crosshairOn) {
                    detectDragGestures(
                        onDragStart = { cross = it },
                        onDrag = { change, _ -> cross = change.position; change.consume() },
                        onDragEnd = { },
                        onDragCancel = { }
                    )
                } else {
                    cross = null
                    detectTransformGestures { _, pan, zoom, _ ->
                        val barW = plotW / (visible + RIGHT_PAD)
                        offset = (offset + pan.x / barW).coerceIn(0f, max(0, nNow - 12).toFloat())
                        visible = (visible / zoom).coerceIn(15f, min(500f, nNow.toFloat() + 5f).coerceAtLeast(16f))
                    }
                }
            }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            if (n < 2) return@Canvas
            val axisW = 66.dp.toPx()
            val timeH = 24.dp.toPx()
            val topPad = 36.dp.toPx()
            val pw = size.width - axisW
            val ph = size.height - timeH - topPad
            if (pw <= 10f || ph <= 10f) return@Canvas
            val vis = visible.coerceIn(15f, 500f)
            val barW = pw / (vis + RIGHT_PAD)
            val lastF = (n - 1) - offset
            fun xOf(i: Int) = pw - (lastF - i + RIGHT_PAD - 0.5f) * barW
            val first = max(0, (lastF - vis).toInt() - 1)
            val last = min(n - 1, ceil(lastF).toInt())
            if (first >= last) return@Canvas

            var hi = Double.NEGATIVE_INFINITY
            var lo = Double.POSITIVE_INFINITY
            for (i in first..last) { hi = max(hi, candles[i].high); lo = min(lo, candles[i].low) }
            val padV = (hi - lo).coerceAtLeast(hi * 1e-5) * 0.08
            hi += padV; lo -= padV
            fun yOf(v: Double) = (topPad + (hi - v) / (hi - lo) * ph).toFloat()

            val gridCol = Color.White.copy(alpha = 0.055f)
            val txt = TextStyle(color = Muted, fontSize = 10.sp)

            // price grid + axis labels
            val step = niceStep((hi - lo) / 6.0)
            var g = ceil(lo / step) * step
            while (g <= hi) {
                val y = yOf(g)
                drawLine(gridCol, Offset(0f, y), Offset(pw, y), 1f)
                val lay = tm.measure(num(g), txt)
                drawText(lay, topLeft = Offset(pw + 8.dp.toPx(), y - lay.size.height / 2f))
                g += step
            }

            // time grid + labels
            val everyBars = max(1, ceil(96.dp.toPx() / barW).toInt())
            var i0 = first - Math.floorMod(first, everyBars) + everyBars
            var lastDay = -1L
            while (i0 <= last) {
                val x = xOf(i0)
                if (x in 0f..pw) {
                    drawLine(gridCol, Offset(x, topPad), Offset(x, topPad + ph), 1f)
                    val tt = candles[i0].time
                    val day = tt / 86_400_000L
                    val label = if (dayTf || day != lastDay && lastDay != -1L) dm.format(Date(tt)) else hm.format(Date(tt))
                    lastDay = day
                    val lay = tm.measure(label, txt)
                    drawText(lay, topLeft = Offset(x - lay.size.width / 2f, topPad + ph + 5.dp.toPx()))
                }
                i0 += everyBars
            }

            clipRect(0f, topPad, pw, topPad + ph) {
                // SMC zones
                if (showOverlays) for (z in overlays.zones) {
                    if (z.high < lo || z.low > hi) continue
                    val y1 = yOf(z.high)
                    val y2 = yOf(z.low)
                    drawRect(z.color.copy(alpha = 0.13f), Offset(0f, y1), Size(pw, (y2 - y1).coerceAtLeast(2f)))
                    drawLine(z.color.copy(alpha = 0.55f), Offset(0f, y1), Offset(pw, y1), 1f)
                    drawLine(z.color.copy(alpha = 0.55f), Offset(0f, y2), Offset(pw, y2), 1f)
                    val lay = tm.measure(z.label, TextStyle(color = z.color, fontSize = 9.sp, fontWeight = FontWeight.Bold))
                    drawText(lay, topLeft = Offset(6.dp.toPx(), y1 + 2.dp.toPx()))
                }

                // series
                when (style) {
                    1, 2 -> {
                        val line = Path()
                        var started = false
                        for (i in first..last) {
                            val x = xOf(i); val y = yOf(candles[i].close)
                            if (!started) { line.moveTo(x, y); started = true } else line.lineTo(x, y)
                        }
                        if (style == 2) {
                            val area = Path().apply { addPath(line); lineTo(xOf(last), topPad + ph); lineTo(xOf(first), topPad + ph); close() }
                            drawPath(area, Brush.verticalGradient(listOf(Nova.copy(alpha = 0.35f), Color.Transparent), startY = topPad, endY = topPad + ph))
                        }
                        drawPath(line, Brush.horizontalGradient(listOf(Nova, Cyan)), style = Stroke(2.2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
                    }
                    else -> {
                        val bw = (barW * 0.72f).coerceAtLeast(1f)
                        for (i in first..last) {
                            val c = candles[i]
                            val x = xOf(i)
                            if (x < -barW || x > pw + barW) continue
                            val up = c.close >= c.open
                            val col = if (up) UpGreen else DownRed
                            drawLine(col, Offset(x, yOf(c.high)), Offset(x, yOf(c.low)), max(1f, bw * 0.14f))
                            val yo = yOf(c.open); val yc = yOf(c.close)
                            drawRect(col, Offset(x - bw / 2, min(yo, yc)), Size(bw, max(1.5f, kotlin.math.abs(yo - yc))))
                        }
                    }
                }

                // EMAs
                if (showEma) {
                    fun ema(arr: DoubleArray, col: Color) {
                        if (arr.size != n) return
                        val pth = Path()
                        var st = false
                        for (i in max(first, 1)..last) {
                            val x = xOf(i); val y = yOf(arr[i])
                            if (!st) { pth.moveTo(x, y); st = true } else pth.lineTo(x, y)
                        }
                        drawPath(pth, col.copy(alpha = 0.9f), style = Stroke(1.4.dp.toPx(), cap = StrokeCap.Round))
                    }
                    ema(ema20, Amber)
                    ema(ema50, Cyan)
                }

                // levels
                if (showOverlays) for (l in overlays.levels) {
                    if (l.price < lo || l.price > hi) continue
                    val y = yOf(l.price)
                    drawLine(
                        l.color.copy(alpha = 0.85f), Offset(0f, y), Offset(pw, y), 1.2.dp.toPx(),
                        pathEffect = if (l.dashed) PathEffect.dashPathEffect(floatArrayOf(14f, 10f)) else null
                    )
                    val lay = tm.measure(l.label, TextStyle(color = l.color, fontSize = 9.sp, fontWeight = FontWeight.Bold))
                    drawText(lay, topLeft = Offset(pw - lay.size.width - 6.dp.toPx(), y - lay.size.height - 1.dp.toPx()))
                }
            }

            // level tags on the price axis
            if (showOverlays) for (l in overlays.levels) {
                if (l.price < lo || l.price > hi) continue
                axisTag(tm, num(l.price), pw + 2.dp.toPx(), axisW - 4.dp.toPx(), yOf(l.price), l.color.copy(alpha = 0.9f))
            }

            // last price
            val lc = candles[n - 1]
            if (lc.close in lo..hi) {
                val col = if (lc.close >= lc.open) UpGreen else DownRed
                val y = yOf(lc.close)
                drawLine(col.copy(alpha = 0.7f), Offset(0f, y), Offset(pw, y), 1.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 6f)))
                axisTag(tm, num(lc.close), pw + 2.dp.toPx(), axisW - 4.dp.toPx(), y, col)
            }

            // crosshair
            val cp = if (crosshairOn) cross else null
            var infoIdx = n - 1
            if (cp != null) {
                val ci = (lastF + RIGHT_PAD - 0.5f - (pw - cp.x) / barW).roundToInt().coerceIn(0, n - 1)
                infoIdx = ci
                val cx = xOf(ci).coerceIn(0f, pw)
                val cy = cp.y.coerceIn(topPad, topPad + ph)
                val dash = PathEffect.dashPathEffect(floatArrayOf(8f, 8f))
                drawLine(Color.White.copy(alpha = 0.55f), Offset(cx, topPad), Offset(cx, topPad + ph), 1.dp.toPx(), pathEffect = dash)
                drawLine(Color.White.copy(alpha = 0.55f), Offset(0f, cy), Offset(pw, cy), 1.dp.toPx(), pathEffect = dash)
                val pr = hi - (cy - topPad) / ph * (hi - lo)
                axisTag(tm, num(pr), pw + 2.dp.toPx(), axisW - 4.dp.toPx(), cy, Color(0xFF3A4468))
                val tl = tm.measure(full.format(Date(candles[ci].time)), TextStyle(color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold))
                val tw = tl.size.width + 14.dp.toPx()
                val tx = (cx - tw / 2).coerceIn(0f, pw - tw)
                drawRoundRect(Color(0xFF3A4468), Offset(tx, topPad + ph + 2.dp.toPx()), Size(tw, timeH - 4.dp.toPx()), CornerRadius(4.dp.toPx()))
                drawText(tl, topLeft = Offset(tx + 7.dp.toPx(), topPad + ph + 2.dp.toPx() + (timeH - 4.dp.toPx() - tl.size.height) / 2f))
            }

            // header: symbol + OHLC
            val c = candles[infoIdx]
            val up = c.close >= c.open
            val head = tm.measure("${Instruments.label(symbol)} · $tf", TextStyle(color = Ink, fontSize = 13.sp, fontWeight = FontWeight.Bold))
            drawText(head, topLeft = Offset(8.dp.toPx(), 4.dp.toPx()))
            val oc = if (up) UpGreen else DownRed
            val chg = if (c.open != 0.0) (c.close - c.open) / c.open * 100 else 0.0
            val ohlc = "O ${num(c.open)}  H ${num(c.high)}  L ${num(c.low)}  C ${num(c.close)}  " + String.format(Locale.US, "%+.2f%%", chg)
            val ol = tm.measure(ohlc, TextStyle(color = oc, fontSize = 10.sp))
            drawText(ol, topLeft = Offset(8.dp.toPx(), 21.dp.toPx()))

            // legend for EMAs
            if (showEma) {
                val l1 = tm.measure("EMA20", TextStyle(color = Amber, fontSize = 9.sp, fontWeight = FontWeight.Bold))
                val l2 = tm.measure("EMA50", TextStyle(color = Cyan, fontSize = 9.sp, fontWeight = FontWeight.Bold))
                val xr = pw - l1.size.width - l2.size.width - 20.dp.toPx()
                drawText(l1, topLeft = Offset(xr, 6.dp.toPx()))
                drawText(l2, topLeft = Offset(xr + l1.size.width + 10.dp.toPx(), 6.dp.toPx()))
            }
        }
        if (offset > 0.5f) {
            Box(
                Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = 74.dp, bottom = 32.dp)
                    .clip(RoundedCornerShape(50))
                    .background(Nova.copy(alpha = 0.9f))
                    .clickable { offset = 0f }
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) { Text("Latest ›", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
        }
    }
}

/** The real TradingView chart (their free embeddable widget). Needs internet; shows TradingView's own data and tools. */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun TradingViewChart(symbol: String, tf: String, modifier: Modifier = Modifier) {
    val ins = Instruments.get(symbol)
    val interval = when (tf) { "M1" -> "1"; "M5" -> "5"; "M15" -> "15"; "M30" -> "30"; "H1" -> "60"; "H4" -> "240"; else -> "15" }
    val html = remember(symbol, tf) {
        """
        <html><head><meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <style>html,body{margin:0;height:100%;background:#05070F}#tv{height:100%;width:100%}</style></head><body>
        <div id="tv"></div>
        <script src="https://s3.tradingview.com/tv.js"></script>
        <script>
        new TradingView.widget({autosize:true,symbol:"${ins.tv}",interval:"$interval",timezone:"Etc/UTC",theme:"dark",style:"1",locale:"en",
        toolbar_bg:"#0C1120",backgroundColor:"#05070F",enable_publishing:false,hide_top_toolbar:false,hide_legend:false,save_image:false,
        allow_symbol_change:false,container_id:"tv",studies:["MASimple@tv-basicstudies"]});
        </script></body></html>
        """.trimIndent()
    }
    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            WebView(ctx).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                setBackgroundColor(0xFF05070F.toInt())
                webViewClient = WebViewClient()
            }
        },
        update = { w ->
            if (w.tag != html) {
                w.tag = html
                w.loadDataWithBaseURL("https://www.tradingview.com", html, "text/html", "utf-8", null)
            }
        },
        onRelease = { it.destroy() }
    )
}

fun buildOverlays(sym: SymState?, openTrades: List<TradeRecord>, showTrades: Boolean): ChartOverlays {
    val levels = ArrayList<ChartLevel>()
    val zones = ArrayList<ChartZone>()
    val scan = sym?.scan
    if (scan != null) {
        for ((d, s) in scan.snaps) {
            val dn = if (d == Dir.BULLISH) "Bull" else "Bear"
            s.ob?.let { zones += ChartZone(it.low, it.high, "$dn OB", ObBlue) }
            s.fvg?.let { zones += ChartZone(it.low, it.high, "$dn FVG", Amber) }
        }
        scan.snaps.values.firstOrNull()?.let { s ->
            s.pdh?.let { levels += ChartLevel(it, "PDH", Orange) }
            s.pdl?.let { levels += ChartLevel(it, "PDL", Orange) }
        }
        scan.asianHigh?.let { levels += ChartLevel(it, "Asia H", Muted) }
        scan.asianLow?.let { levels += ChartLevel(it, "Asia L", Muted) }
    }
    if (showTrades) {
        for (t in openTrades) {
            val tag = if (t.side == Dir.BULLISH) "BUY" else "SELL"
            levels += ChartLevel(t.entry, "$tag ENTRY", NovaLight, dashed = false)
            levels += ChartLevel(t.sl, "SL", DownRed, dashed = false)
            levels += ChartLevel(t.tp, "TP", UpGreen, dashed = false)
            if (t.tp1 != 0.0) levels += ChartLevel(t.tp1, "TP1", UpGreen.copy(alpha = 0.7f))
        }
        sym?.decisions?.values?.filter { it.verdict != Verdict.BLOCKED }?.forEach { d ->
            val tag = if (d.buy) "BUY" else "SELL"
            levels += ChartLevel(d.setup.entry, "$tag SIGNAL", Pink)
            levels += ChartLevel(d.setup.sl, "SL", DownRed.copy(alpha = 0.7f))
            levels += ChartLevel(d.setup.tp2, "TP", UpGreen.copy(alpha = 0.7f))
        }
    }
    return ChartOverlays(levels, zones)
}

@Composable
fun ChartScreen(
    ui: UiState,
    trades: List<TradeRecord>,
    symbol: String,
    onSymbol: (String) -> Unit,
    p: Prefs
) {
    val ctx = LocalContext.current
    var chartTf by remember { mutableStateOf(p.chartTf) }
    var style by remember { mutableIntStateOf(p.chartStyle) }
    var showEma by remember { mutableStateOf(p.showEma) }
    var showSmc by remember { mutableStateOf(p.showSmc) }
    var showTrades by remember { mutableStateOf(p.showTrades) }
    var tvMode by remember { mutableStateOf(p.chartMode == "TV") }
    var cross by remember { mutableStateOf(false) }
    var candles by remember(symbol, chartTf) { mutableStateOf<List<Candle>>(emptyList()) }
    var err by remember(symbol, chartTf) { mutableStateOf<String?>(null) }

    LaunchedEffect(symbol, chartTf) {
        while (isActive) {
            val pp = Prefs(ctx)
            try {
                val c = withContext(Dispatchers.IO) { Feed.fetch(pp, symbol, chartTf, 500) }
                if (c.isNotEmpty()) { candles = c; PriceBook.set(symbol, c.last().close) }
                err = null
            } catch (e: Exception) { err = e.message ?: "Could not load candles" }
            delay(if (pp.isDemo) 1500L else if (pp.source == "OANDA") 4000L else 30_000L)
        }
    }

    val sym = ui.symbols[symbol]
    val open = remember(trades, symbol) { trades.filter { it.symbol == symbol && it.outcome == Outcome.OPEN } }
    val overlays = remember(sym, open, showTrades) { buildOverlays(sym, open, showTrades) }
    val price = candles.lastOrNull()?.close ?: sym?.price
    val dayPct = if (candles.size > 2 && price != null) AlertEngine.dayChangePct(candles, price, System.currentTimeMillis()) else sym?.dayPct ?: 0.0

    Column(Modifier.fillMaxSize().statusBarsPadding().padding(top = 10.dp)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text(Instruments.get(symbol).name, color = Muted, style = androidx.compose.material3.MaterialTheme.typography.bodySmall)
                Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(if (price != null) num(price) else "—", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                    Pill(String.format(Locale.US, "%+.2f%%", dayPct), if (dayPct >= 0) UpGreen else DownRed)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                Pill(Feed.sourceLabel(p).uppercase(), if (p.isDemo) Amber else UpGreen)
                MiniChip(if (tvMode) "TradingView" else "Nova chart", tvMode) { tvMode = !tvMode; p.chartMode = if (tvMode) "TV" else "NATIVE" }
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Instruments.all.forEach { ins -> Chip(ins.pair, ins.id == symbol) { onSymbol(ins.id) } }
        }
        Spacer(Modifier.height(6.dp))
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.CenterVertically
        ) {
            TF_LIST.forEach { MiniChip(it, it == chartTf) { chartTf = it; p.chartTf = it } }
            Spacer(Modifier.width(8.dp))
            if (!tvMode) {
                MiniChip(STYLE_NAMES[style], false) { style = (style + 1) % 3; p.chartStyle = style }
                MiniChip("EMA", showEma) { showEma = !showEma; p.showEma = showEma }
                MiniChip("SMC", showSmc) { showSmc = !showSmc; p.showSmc = showSmc }
                MiniChip("Trades", showTrades) { showTrades = !showTrades; p.showTrades = showTrades }
                MiniChip("Crosshair", cross) { cross = !cross }
            }
        }
        Spacer(Modifier.height(6.dp))
        Box(
            Modifier.weight(1f).fillMaxWidth().padding(horizontal = 10.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(Color(0xFF080C18))
        ) {
            if (tvMode) {
                TradingViewChart(symbol, chartTf, Modifier.fillMaxSize())
            } else if (candles.size < 2) {
                Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (err == null) { Text("Loading ${Instruments.label(symbol)}…", color = Muted) }
                    else {
                        Text("Can't load the chart", fontWeight = FontWeight.Bold, color = DownRed)
                        Text(err ?: "", color = Muted, style = androidx.compose.material3.MaterialTheme.typography.bodySmall, modifier = Modifier.padding(horizontal = 24.dp))
                    }
                }
            } else {
                CandleChart(symbol, chartTf, candles, overlays, style, showEma, showSmc, cross, Modifier.fillMaxSize())
            }
        }
        Spacer(Modifier.height(8.dp))
        Column(Modifier.padding(horizontal = 10.dp).padding(bottom = 96.dp)) {
            val best = sym?.decisions?.values?.sortedWith(compareBy<Decision> { it.verdict.ordinal }.thenByDescending { it.confidence })?.firstOrNull()
            if (best != null) {
                DecisionCard(best, compact = true, onClick = {})
            } else {
                Row(Modifier.fillMaxWidth().glass(radius = 18.dp).padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(if (ui.running) "Scanning ${Instruments.label(symbol)} on ${p.tf}…" else "Monitoring is off", fontWeight = FontWeight.Bold)
                        Text(
                            if (!ui.running) "Start monitoring on the Home tab to get Buy / Sell signals."
                            else "No valid setup right now · higher-timeframe trend: " + biasText(sym?.htf ?: Bias.UNKNOWN),
                            color = Muted, style = androidx.compose.material3.MaterialTheme.typography.bodySmall
                        )
                    }
                    if (ui.running) PulseDot(UpGreen)
                }
            }
        }
    }
}

fun biasText(b: Bias): String = when (b) { Bias.BULL -> "bullish"; Bias.BEAR -> "bearish"; Bias.NEUTRAL -> "neutral"; Bias.UNKNOWN -> "unknown" }
