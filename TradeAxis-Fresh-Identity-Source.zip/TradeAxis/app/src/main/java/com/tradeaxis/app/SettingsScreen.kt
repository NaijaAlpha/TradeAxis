package com.tradeaxis.app

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.math.roundToInt

@Composable
private fun PrefSwitch(label: String, get: () -> Boolean, set: (Boolean) -> Unit) {
    var on by remember { mutableStateOf(get()) }
    SwitchRow(label, on) { on = it; set(it) }
}

@Composable
private fun PrefSlider(label: String, get: () -> Float, set: (Float) -> Unit, range: ClosedFloatingPointRange<Float>, fmt: (Float) -> String, whole: Boolean = false) {
    var v by remember { mutableFloatStateOf(get()) }
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = Muted, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
            Text(fmt(v), fontWeight = FontWeight.Bold)
        }
        NovaSlider(v, { v = if (whole) it.roundToInt().toFloat() else it }, { set(v) }, range)
    }
}

@Composable
private fun PrefNumber(label: String, get: () -> Float, set: (Float) -> Unit) {
    var text by remember { mutableStateOf(String.format(Locale.US, "%.0f", get())) }
    OutlinedTextField(
        value = text,
        onValueChange = { t -> text = t; t.replace(",", "").toFloatOrNull()?.let { if (it > 0) set(it) } },
        label = { Text(label) }, singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
fun SettingsScreen(p: Prefs, onWatchChanged: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var source by remember { mutableStateOf(p.source) }
    var tf by remember { mutableStateOf(p.tf) }
    var token by remember { mutableStateOf(p.oandaToken) }
    var key by remember { mutableStateOf(p.apiKey) }
    var watched by remember { mutableStateOf(p.watched().toSet()) }
    var test by remember { mutableStateOf<String?>(null) }
    var testing by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 16.dp, vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ScreenHeader("Settings")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 120.dp)) {

            item {
                SectionCard("Market data", accent = if (source == "DEMO") Amber else null) {
                    Segmented(listOf("Demo" to Amber, "OANDA" to Nova, "Twelve Data" to Nova), listOf("DEMO", "OANDA", "TWELVE").indexOf(source)) {
                        source = listOf("DEMO", "OANDA", "TWELVE")[it]; p.source = source; test = null; onWatchChanged()
                    }
                    when (source) {
                        "DEMO" -> Hint("Simulated prices so the whole app works instantly. Not real market data — use it to learn the app, never to trade.")
                        "OANDA" -> {
                            Hint("Free practice account from oanda.com → My Hub → API access. Covers all 11 markets with live candles.")
                            OutlinedTextField(token, { token = it.trim(); p.oandaToken = token }, label = { Text("OANDA API token") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
                            PrefSwitch("Live account (off = practice)", { p.oandaLive }, { p.oandaLive = it })
                        }
                        else -> {
                            Hint("Free key from twelvedata.com. The free plan allows about 800 requests a day, so watching all 11 markets will run out — pick only a few or use OANDA.")
                            OutlinedTextField(key, { key = it.trim(); p.apiKey = key }, label = { Text("Twelve Data API key") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
                        }
                    }
                    PrefSlider("Check every", { p.pollSec.toFloat() }, { p.pollSec = it.roundToInt() }, 5f..120f, { "${it.roundToInt()} s" }, whole = true)
                    GhostButton(if (testing) "Testing…" else "Test connection", {
                        if (!testing) {
                            testing = true; test = null
                            scope.launch {
                                test = try {
                                    val c = withContext(Dispatchers.IO) { Feed.fetch(Prefs(ctx), "XAU_USD", "M5", 20) }
                                    "Connected ✓  ${c.size} candles · XAU/USD ${num(c.last().close)}"
                                } catch (e: Exception) { "Failed: ${e.message}" }
                                testing = false
                            }
                        }
                    })
                    test?.let { Text(it, color = if (it.startsWith("Connected")) UpGreen else DownRed, style = MaterialTheme.typography.bodySmall) }
                }
            }

            item {
                SectionCard("Markets to watch") {
                    Cat.values().forEach { cat ->
                        Text(cat.label.uppercase(), style = MaterialTheme.typography.titleSmall, color = Muted)
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Instruments.all.filter { it.cat == cat }.forEach { ins ->
                                Chip(ins.pair, ins.id in watched) {
                                    val on = ins.id !in watched
                                    p.setWatched(ins.id, on)
                                    watched = p.watched().toSet()
                                    onWatchChanged()
                                }
                            }
                        }
                    }
                    Hint("${watched.size} of ${Instruments.all.size} markets selected.")
                }
            }

            item {
                SectionCard("Price engine") {
                    Text("Timeframe", color = Muted, style = MaterialTheme.typography.bodySmall)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("M1", "M5", "M15", "M30", "H1", "H4").forEach { Chip(it, it == tf) { tf = it; p.tf = it } }
                    }
                    Text("Entry methods", color = Muted, style = MaterialTheme.typography.bodySmall)
                    Method.values().forEach { m ->
                        PrefSwitch(m.label, { m in p.methodSet() }, { p.setMethod(m, it) })
                    }
                    PrefSwitch("Allow BUY signals", { p.bullish }, { p.bullish = it })
                    PrefSwitch("Allow SELL signals", { p.bearish }, { p.bearish = it })
                    PrefSwitch("Only trade with the higher-timeframe trend", { p.htfFilter }, { p.htfFilter = it })
                    PrefSlider("Minimum setup score", { p.minScore.toFloat() }, { p.minScore = it.roundToInt() }, 40f..90f, { "${it.roundToInt()}" }, whole = true)
                    PrefSlider("Target reward : risk", { p.rr }, { p.rr = it }, 1f..4f, { "1 : ${String.format(Locale.US, "%.1f", it)}" })
                    Hint("Sweep + OB retest options")
                    PrefSwitch("Require order block", { p.reqOb }, { p.reqOb = it })
                    PrefSwitch("Require liquidity sweep", { p.reqSweep }, { p.reqSweep = it })
                    PrefSwitch("Require displacement candle", { p.reqDisp }, { p.reqDisp = it })
                    PrefSwitch("Sweep only previous-day high / low", { p.sweepPdOnly }, { p.sweepPdOnly = it })
                }
            }

            item {
                SectionCard("Risk guard", accent = Nova) {
                    Hint("Protects your account like a prop-firm rulebook. Signals that would break a rule are marked BLOCKED instead of sent. The day resets at 00:00 UTC.")
                    PrefSwitch("Risk guard on", { p.guardOn }, { p.guardOn = it })
                    PrefNumber("Account balance (USD)", { p.balance }, { p.balance = it })
                    PrefSlider("Risk per trade", { p.riskPct }, { p.riskPct = it }, 0.1f..3f, { String.format(Locale.US, "%.2f%%", it) })
                    PrefSlider("Daily loss limit", { p.dailyLossPct }, { p.dailyLossPct = it }, 1f..10f, { String.format(Locale.US, "%.1f%%", it) })
                    PrefSlider("Max drawdown", { p.maxDdPct }, { p.maxDdPct = it }, 2f..20f, { String.format(Locale.US, "%.1f%%", it) })
                    PrefSlider("Profit target", { p.profitTargetPct }, { p.profitTargetPct = it }, 0f..20f, { String.format(Locale.US, "%.0f%%", it) }, whole = true)
                    PrefSlider("Max open signals", { p.maxOpen.toFloat() }, { p.maxOpen = it.roundToInt() }, 1f..10f, { "${it.roundToInt()}" }, whole = true)
                    PrefSlider("Max signals per day", { p.maxTradesDay.toFloat() }, { p.maxTradesDay = it.roundToInt() }, 1f..20f, { "${it.roundToInt()}" }, whole = true)
                    PrefSlider("Pause after losses in a day", { p.maxLossesPerDay.toFloat() }, { p.maxLossesPerDay = it.roundToInt() }, 1f..8f, { "${it.roundToInt()}" }, whole = true)
                    PrefSlider("Max total open risk", { p.maxOpenRiskPct }, { p.maxOpenRiskPct = it }, 0.5f..10f, { String.format(Locale.US, "%.1f%%", it) })
                    PrefSwitch("Block over-exposure to one currency / asset", { p.corrGuard }, { p.corrGuard = it })
                    PrefSwitch("Block trades when the market is closed (weekend)", { p.weekendGuard }, { p.weekendGuard = it })
                    PrefSwitch("Halve risk while in drawdown", { p.cutRiskInDd }, { p.cutRiskInDd = it })
                }
            }

            item {
                SectionCard("Copilot") {
                    Hint("Copilot combines the price engine score, the higher-timeframe trend, your own track record and the Risk Guard into one verdict: TAKE, WATCH or BLOCKED.")
                    PrefSlider("TAKE when confidence is at least", { p.takeConf.toFloat() }, { p.takeConf = it.roundToInt() }, 50f..90f, { "${it.roundToInt()}" }, whole = true)
                    PrefSwitch("Also alert on WATCH setups", { p.alertWatch }, { p.alertWatch = it })
                    PrefSwitch("Use my track record to adjust confidence", { p.useEdge }, { p.useEdge = it })
                }
            }

            item {
                SectionCard("Alerts & trade handling") {
                    PrefSwitch("Trade results (TP / SL / expiry)", { p.notifyOutcome }, { p.notifyOutcome = it })
                    PrefSwitch("Price alerts as notifications", { p.notifyPrice }, { p.notifyPrice = it })
                    PrefSwitch("Risk guard warnings", { p.notifyGuard }, { p.notifyGuard = it })
                    PrefSwitch("Tell me about signals the Guard blocked", { p.notifyBlocked }, { p.notifyBlocked = it })
                    PrefSwitch("Volatility spike alerts (all markets)", { p.notifyVolatility }, { p.notifyVolatility = it })
                    PrefSlider("Spike = candle this many × average", { p.volMult }, { p.volMult = it }, 2f..6f, { String.format(Locale.US, "%.1f×", it) })
                    PrefSlider("Cooldown between signals on a market", { p.cooldownMin.toFloat() }, { p.cooldownMin = it.roundToInt() }, 0f..180f, { "${it.roundToInt()} min" }, whole = true)
                    PrefSlider("Signal expires after", { p.expiryHours.toFloat() }, { p.expiryHours = it.roundToInt() }, 0f..72f, { if (it.roundToInt() == 0) "never" else "${it.roundToInt()} h" }, whole = true)
                    PrefSwitch("Move stop to entry after TP1", { p.beAfterTp1 }, { p.beAfterTp1 = it })
                    PrefSwitch("Only send signals in set hours (UTC)", { p.hoursOn }, { p.hoursOn = it })
                    PrefSlider("From", { p.hoursStart.toFloat() }, { p.hoursStart = it.roundToInt() }, 0f..23f, { "%02d:00".format(it.roundToInt()) }, whole = true)
                    PrefSlider("To", { p.hoursEnd.toFloat() }, { p.hoursEnd = it.roundToInt() }, 0f..23f, { "%02d:00".format(it.roundToInt()) }, whole = true)
                    GhostButton("Send a test notification", {
                        Notifier.send(ctx, AlertKind.SIGNAL, "XAU_USD", "BUY", "BUY XAU/USD · TAKE 82", "Sweep+OB · M5 · grade A\nEntry 2,650.40   SL 2,646.10\nTP1 2,656.00   TP2 2,659.00  (1:2.0)\nThis is a test.")
                    })
                }
            }

            item {
                SectionCard("App") {
                    PrefSwitch("Show animated intro on launch", { p.showIntro }, { p.showIntro = it })
                    PrefSwitch("Keep screen on while the app is open", { p.keepAwake }, { p.keepAwake = it })
                    Hint("TradeAxis · analysis workspace. It never places trades. Signals are not financial advice.")
                }
            }
        }
    }
}
