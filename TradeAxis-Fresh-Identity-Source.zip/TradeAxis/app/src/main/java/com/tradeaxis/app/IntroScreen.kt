package com.tradeaxis.app

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun IntroScreen(onDone: () -> Unit) {
    val burst = remember { Animatable(0f) }
    val reveal = remember { Animatable(0f) }
    val title = remember { Animatable(0f) }
    val bar = remember { Animatable(0f) }
    var finished by remember { mutableStateOf(false) }
    fun finish() { if (!finished) { finished = true; onDone() } }

    LaunchedEffect(Unit) {
        launch { burst.animateTo(1f, tween(1500, easing = FastOutSlowInEasing)) }
        launch { bar.animateTo(1f, tween(2000, easing = LinearEasing)) }
        reveal.animateTo(1f, tween(900, easing = FastOutSlowInEasing))
        title.animateTo(1f, tween(600))
        delay(900)
        finish()
    }

    Box(
        Modifier.fillMaxSize().clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { finish() },
        contentAlignment = Alignment.Center
    ) {
        AxisBackground()
        Canvas(Modifier.fillMaxSize()) {
            val c = Offset(size.width / 2, size.height * 0.4f)
            val b = burst.value
            for (k in 0..2) {
                val r = b * size.width * (0.45f + k * 0.28f)
                drawCircle(
                    (if (k == 1) Cyan else Nova).copy(alpha = (1f - b) * (0.45f - k * 0.1f)),
                    radius = r, center = c, style = Stroke(width = 2.dp.toPx())
                )
            }
            for (i in 0 until 16) {
                val a = Math.toRadians(i * 22.5)
                val r0 = size.width * 0.18f + b * size.width * 0.1f
                val r1 = r0 + b * size.width * 0.35f
                val col = if (i % 2 == 0) Cyan else Nova
                drawLine(
                    col.copy(alpha = (1f - b) * 0.55f),
                    Offset(c.x + cos(a).toFloat() * r0, c.y + sin(a).toFloat() * r0),
                    Offset(c.x + cos(a).toFloat() * r1, c.y + sin(a).toFloat() * r1),
                    strokeWidth = 2.dp.toPx(), cap = StrokeCap.Round
                )
            }
        }
        Column(Modifier.fillMaxSize().padding(bottom = 40.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Spacer(Modifier.weight(0.8f))
            NovaLogo(170.dp, reveal.value)
            Spacer(Modifier.height(18.dp))
            Text(
                "TRADEAXIS", Modifier.alpha(title.value), fontSize = 32.sp, fontWeight = FontWeight.ExtraBold,
                letterSpacing = 8.sp, color = Ink
            )
            Spacer(Modifier.height(8.dp))
            Text("PLAN  /  ANALYZE  /  EXECUTE", Modifier.alpha(title.value), fontSize = 14.sp, color = Muted, letterSpacing = 1.5.sp)
            Spacer(Modifier.weight(1f))
            Box(
                Modifier.width(150.dp).height(4.dp).alpha(title.value)
                    .background(Color.White.copy(alpha = 0.08f), androidx.compose.foundation.shape.RoundedCornerShape(2.dp))
            ) {
                Box(Modifier.fillMaxWidth(bar.value).fillMaxHeight().background(NovaBrushH, androidx.compose.foundation.shape.RoundedCornerShape(2.dp)))
            }
        }
    }
}
