package com.tradeaxis.app

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale
import kotlin.math.abs

@Composable
private fun AxisField(label: String, value: String, onValue: (String) -> Unit, modifier: Modifier = Modifier, suffix: String? = null) {
    OutlinedTextField(
        value = value,
        onValueChange = onValue,
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        trailingIcon = suffix?.let { { Text(it, color = Muted, fontSize = 12.sp, modifier = Modifier.padding(end = 10.dp)) } },
        modifier = modifier
    )
}

@Composable
fun TradeEntryScreen(p: Prefs, onSaved: () -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var buy by remember { mutableStateOf(true) }
    var symbol by remember { mutableStateOf(p.symbol) }
    var tf by remember { mutableStateOf(p.tf) }
    var entryType by remember { mutableStateOf("Market") }
    var method by remember { mutableStateOf(Method.SWEEP_OB) }
    var entry by remember { mutableStateOf((PriceBook.get(symbol) ?: 0.0).let { if (it > 0) String.format(Locale.US, "%.5f", it).trimEnd('0').trimEnd('.') else "" }) }
    var sl by remember { mutableStateOf("") }
    var tp1 by remember { mutableStateOf("") }
    var tp2 by remember { mutableStateOf("") }
    var riskPct by remember { mutableStateOf(String.format(Locale.US, "%.1f", p.riskPct)) }
    var lots by remember { mutableStateOf("") }
    var grade by remember { mutableStateOf("A") }
    var note by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var guard by remember { mutableStateOf<GuardCheck?>(null) }

    val e = entry.toDoubleOrNull() ?: 0.0
    val s = sl.toDoubleOrNull() ?: 0.0
    val t1 = tp1.toDoubleOrNull() ?: 0.0
    val t2 = tp2.toDoubleOrNull() ?: 0.0
    val riskDist = abs(e - s)
    val rr = if (riskDist > 0 && t2 > 0) abs(t2 - e) / riskDist else 0.0
    val plannedRisk = (p.balance * (riskPct.toDoubleOrNull() ?: p.riskPct.toDouble()) / 100.0).coerceAtLeast(0.0)
    val autoLots = if (riskDist > 0 && e > 0) Sizing.lots(symbol, plannedRisk, riskDist, e) else 0.0
    val displayLots = lots.toDoubleOrNull() ?: autoLots
    val actualRisk = if (riskDist > 0 && displayLots > 0) Sizing.riskUsdFor(symbol, displayLots, riskDist, e) else plannedRisk
    val side = if (buy) Dir.BULLISH else Dir.BEARISH
    val guardCheck = guard

    fun recalcGuard() {
        guard = if (e > 0 && s > 0 && displayLots > 0) RiskGuard.check(p, TradeJournal.visible(TradeJournal.items.value, p.isDemo), symbol, side, actualRisk, System.currentTimeMillis()) else null
    }

    LazyColumn(
        Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(top = 14.dp, bottom = 124.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("New trade", style = MaterialTheme.typography.headlineSmall)
                    Text("Plan the trade before you execute it.", color = Muted, style = MaterialTheme.typography.bodySmall)
                }
                Pill(if (p.isDemo) "DEMO" else "LIVE DATA", if (p.isDemo) Amber else Nova)
            }
        }
        item {
            SectionCard("Direction", accent = if (buy) UpGreen else DownRed) {
                Segmented(listOf("BUY" to UpGreen, "SELL" to DownRed), if (buy) 0 else 1) { buy = it == 0; guard = null }
            }
        }
        item {
            SectionCard("Market") {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Instruments.all.forEach { ins -> Chip(ins.pair, ins.id == symbol) { symbol = ins.id; p.symbol = ins.id; entry = PriceBook.get(ins.id)?.let { String.format(Locale.US, "%.5f", it).trimEnd('0').trimEnd('.') } ?: entry; guard = null } }
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("M1", "M5", "M15", "M30", "H1", "H4", "D1").forEach { Chip(it, it == tf) { tf = it; p.tf = it } }
                }
            }
        }
        item {
            SectionCard("Entry mode", accent = Nova) {
                Segmented(listOf("Market" to Nova, "Limit" to ObBlue, "Breakout" to Amber, "Retest" to Cyan), listOf("Market", "Limit", "Breakout", "Retest").indexOf(entryType)) { entryType = listOf("Market", "Limit", "Breakout", "Retest")[it] }
                Text("Entry price", color = Muted, style = MaterialTheme.typography.bodySmall)
                AxisField("Entry", entry, { entry = it; guard = null }, Modifier.fillMaxWidth())
                Text("Define the exact level where your plan becomes active.", color = Muted, style = MaterialTheme.typography.bodySmall)
            }
        }
        item {
            SectionCard("Protection & targets") {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    AxisField("Stop loss", sl, { sl = it; guard = null }, Modifier.weight(1f))
                    AxisField("TP1", tp1, { tp1 = it; guard = null }, Modifier.weight(1f))
                }
                AxisField("TP2 / final target", tp2, { tp2 = it; guard = null }, Modifier.fillMaxWidth())
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Risk : Reward", color = Muted, style = MaterialTheme.typography.bodySmall)
                    Text(if (rr > 0) "1 : ${String.format(Locale.US, "%.2f", rr)}" else "—", color = if (rr >= 2) UpGreen else Ink, fontWeight = FontWeight.Bold)
                }
            }
        }
        item {
            SectionCard("Risk & sizing") {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    AxisField("Risk %", riskPct, { riskPct = it; guard = null }, Modifier.weight(1f), "%")
                    AxisField("Position size", lots, { lots = it; guard = null }, Modifier.weight(1f), "lots")
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Planned risk", color = Muted, style = MaterialTheme.typography.bodySmall)
                    Text("\$${String.format(Locale.US, "%.2f", actualRisk)}", fontWeight = FontWeight.Bold)
                }
                Text("Auto-size: ${String.format(Locale.US, "%.2f", autoLots)} lots based on your account and stop distance.", color = Muted, style = MaterialTheme.typography.bodySmall)
            }
        }
        item {
            SectionCard("Setup") {
                Text("Strategy", color = Muted, style = MaterialTheme.typography.bodySmall)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Method.values().forEach { m -> Chip(m.short, m == method) { method = m } }
                }
                Text("Trade grade", color = Muted, style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("A+", "A", "B", "C").forEach { Chip(it, it == grade) { grade = it } } }
                OutlinedTextField(note, { note = it }, label = { Text("Thesis / notes") }, minLines = 3, modifier = Modifier.fillMaxWidth())
            }
        }
        item {
            SectionCard("Risk Guard", accent = guardCheck?.let { if (it.blocks.isEmpty()) UpGreen else DownRed }) {
                if (guardCheck == null) {
                    CheckRow(true, "Set entry, stop, target and position size to run the guard")
                } else if (guardCheck.blocks.isEmpty()) {
                    CheckRow(true, "Risk Guard passed — trade is within your limits")
                    guardCheck.warns.forEach { CheckRow(false, it, dim = true) }
                } else {
                    guardCheck.blocks.forEach { CheckRow(false, it) }
                }
            }
        }
        item {
            error?.let { Text(it, color = DownRed, style = MaterialTheme.typography.bodySmall) }
            GradientButton("Review & confirm trade", {
                error = null
                when {
                    e <= 0 || s <= 0 || t1 <= 0 || t2 <= 0 -> error = "Enter valid entry, stop loss, TP1 and TP2 levels."
                    riskDist <= 0 -> error = "Stop loss must be different from the entry."
                    (buy && (s >= e || t1 <= e || t2 <= e)) || (!buy && (s <= e || t1 >= e || t2 >= e)) -> error = "Your levels do not match the selected direction."
                    rr < 1.0 -> error = "Target must be at least 1:1 R:R."
                    else -> {
                        recalcGuard()
                        val g = guard
                        if (g != null && g.blocks.isNotEmpty()) error = g.blocks.joinToString(" • ")
                        else {
                            TradeJournal.add(ctx, TradeRecord(0L, symbol, tf, side, e, s, t2, rr, System.currentTimeMillis(), manual = true, method = method.name, grade = grade, score = 0, tp1 = t1, beAfterTp1 = p.beAfterTp1, lots = displayLots, riskUsd = actualRisk, copilot = "MANUAL", confidence = 0, note = "$entryType · $note", demo = p.isDemo))
                            onSaved()
                        }
                    }
                }
            }, Modifier.fillMaxWidth(), ico = Ico.Check)
        }
    }
}
