package com.tradeaxis.app

import java.util.concurrent.ConcurrentHashMap
import kotlin.math.floor

/** Latest known price per market, shared by every screen and the monitor service. */
object PriceBook {
    private val prices = ConcurrentHashMap<String, Double>()

    fun get(symbol: String): Double? = prices[Instruments.normalize(symbol)]

    fun set(symbol: String, price: Double) {
        if (price.isNaN() || price.isInfinite() || price <= 0.0) return
        val id = Instruments.normalize(symbol)
        prices[id] = price
        Rates.observe(id, price)
    }
}

/** Position sizing: how many lots risk about the wanted USD amount over a given stop distance. */
object Sizing {
    const val MIN_LOT = 0.01
    const val MAX_LOT = 50.0

    private fun usdPerUnitPerLot(symbol: String): Double = Rates.usdPerUnitPerLot(Instruments.of(symbol))

    /** Lots (rounded down to 0.01, never below the minimum lot) risking about [riskUsd]. 0.0 if the inputs make no sense. */
    @Suppress("UNUSED_PARAMETER")
    fun lots(symbol: String, riskUsd: Double, riskDist: Double, price: Double): Double {
        val perLot = riskDist * usdPerUnitPerLot(symbol)
        if (riskUsd <= 0.0 || perLot <= 0.0 || perLot.isNaN() || perLot.isInfinite()) return 0.0
        val raw = floor(riskUsd / perLot * 100.0) / 100.0
        return raw.coerceIn(MIN_LOT, MAX_LOT)
    }

    /** USD lost if the stop is hit with this many lots. */
    @Suppress("UNUSED_PARAMETER")
    fun riskUsdFor(symbol: String, lots: Double, riskDist: Double, price: Double): Double =
        lots * riskDist * usdPerUnitPerLot(symbol)
}
