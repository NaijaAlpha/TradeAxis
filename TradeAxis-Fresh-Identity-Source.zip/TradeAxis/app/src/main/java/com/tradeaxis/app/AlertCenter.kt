package com.tradeaxis.app

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject

// ───────────────────────── alert history ─────────────────────────

enum class AlertKind(val label: String) {
    SIGNAL("Signal"), PRICE("Price"), VOLATILITY("Volatility"), RISK("Risk"), RESULT("Result"), BLOCKED("Blocked"), SYSTEM("System")
}

data class AlertRecord(
    val time: Long,
    val kind: AlertKind,
    val symbol: String,
    val side: String,          // "BUY", "SELL" or ""
    val title: String,
    val body: String
)

object AlertHistory {
    val items = MutableStateFlow<List<AlertRecord>>(emptyList())
    private var loaded = false

    private fun sp(ctx: Context) = ctx.applicationContext.getSharedPreferences("tradenova_history", Context.MODE_PRIVATE)

    @Synchronized
    fun load(ctx: Context) {
        if (loaded) return
        loaded = true
        try {
            val arr = JSONArray(sp(ctx).getString("items", "[]"))
            items.value = List(arr.length()) {
                val o = arr.getJSONObject(it)
                AlertRecord(
                    o.getLong("t"),
                    runCatching { AlertKind.valueOf(o.getString("k")) }.getOrDefault(AlertKind.SYSTEM),
                    o.optString("s", ""), o.optString("d", ""), o.getString("title"), o.getString("body")
                )
            }
        } catch (_: Exception) { items.value = emptyList() }
    }

    @Synchronized
    fun add(ctx: Context, r: AlertRecord) {
        load(ctx)
        items.value = (listOf(r) + items.value).take(200)
        save(ctx)
    }

    @Synchronized
    fun clear(ctx: Context) {
        load(ctx)
        items.value = emptyList()
        save(ctx)
    }

    private fun save(ctx: Context) {
        val arr = JSONArray()
        items.value.forEach {
            arr.put(JSONObject().put("t", it.time).put("k", it.kind.name).put("s", it.symbol).put("d", it.side).put("title", it.title).put("body", it.body))
        }
        sp(ctx).edit().putString("items", arr.toString()).apply()
    }
}

// ───────────────────────── user alert rules ─────────────────────────

enum class RuleType(val label: String, val hint: String, val usesLevel: Boolean) {
    PRICE_ABOVE("Price rises to", "Alert when price reaches this level from below", true),
    PRICE_BELOW("Price falls to", "Alert when price reaches this level from above", true),
    DAY_MOVE("Daily move of", "Alert when the market is up or down this many percent on the day", true),
    PD_BREAK("Breaks previous day high / low", "Alert when price trades beyond yesterday's high or low", false),
    VOLATILITY("Volatility spike", "Alert when a candle is this many times the average range", true)
}

data class AlertRule(
    val id: Long,
    val type: RuleType,
    val symbol: String,
    val level: Double,
    val refPrice: Double,          // price when the rule was created / re-armed
    val repeat: Boolean = false,
    val enabled: Boolean = true,
    val lastFired: Long = 0L,
    val lastKey: String = ""       // de-dupe key (candle time, day number…)
) {
    fun describe(): String = when (type) {
        RuleType.PRICE_ABOVE -> "${Instruments.label(symbol)} rises to ${num(level)}"
        RuleType.PRICE_BELOW -> "${Instruments.label(symbol)} falls to ${num(level)}"
        RuleType.DAY_MOVE -> "${Instruments.label(symbol)} moves ±${String.format(java.util.Locale.US, "%.1f", level)}% on the day"
        RuleType.PD_BREAK -> "${Instruments.label(symbol)} breaks the previous day's high or low"
        RuleType.VOLATILITY -> "${Instruments.label(symbol)} candle ≥ ${String.format(java.util.Locale.US, "%.1f", level)}× average range"
    }
}

object AlertRules {
    val items = MutableStateFlow<List<AlertRule>>(emptyList())
    private var loaded = false

    private fun sp(ctx: Context) = ctx.applicationContext.getSharedPreferences("tradenova_rules", Context.MODE_PRIVATE)

    @Synchronized
    fun load(ctx: Context) {
        if (loaded) return
        loaded = true
        try {
            val arr = JSONArray(sp(ctx).getString("items", "[]"))
            items.value = List(arr.length()) {
                val o = arr.getJSONObject(it)
                AlertRule(
                    id = o.getLong("id"),
                    type = runCatching { RuleType.valueOf(o.getString("type")) }.getOrDefault(RuleType.PRICE_ABOVE),
                    symbol = o.getString("symbol"), level = o.getDouble("level"), refPrice = o.getDouble("ref"),
                    repeat = o.optBoolean("repeat", false), enabled = o.optBoolean("enabled", true),
                    lastFired = o.optLong("lastFired", 0L), lastKey = o.optString("lastKey", "")
                )
            }
        } catch (_: Exception) { items.value = emptyList() }
    }

    @Synchronized
    fun add(ctx: Context, r: AlertRule) {
        load(ctx)
        val id = maxOf(System.currentTimeMillis(), (items.value.maxOfOrNull { it.id } ?: 0L) + 1)
        items.value = listOf(r.copy(id = id)) + items.value
        save(ctx)
    }

    @Synchronized
    fun update(ctx: Context, r: AlertRule) {
        load(ctx)
        items.value = items.value.map { if (it.id == r.id) r else it }
        save(ctx)
    }

    @Synchronized
    fun delete(ctx: Context, id: Long) {
        load(ctx)
        items.value = items.value.filter { it.id != id }
        save(ctx)
    }

    private fun save(ctx: Context) {
        val arr = JSONArray()
        items.value.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("type", it.type.name).put("symbol", it.symbol).put("level", it.level)
                    .put("ref", it.refPrice).put("repeat", it.repeat).put("enabled", it.enabled)
                    .put("lastFired", it.lastFired).put("lastKey", it.lastKey)
            )
        }
        sp(ctx).edit().putString("items", arr.toString()).apply()
    }
}
