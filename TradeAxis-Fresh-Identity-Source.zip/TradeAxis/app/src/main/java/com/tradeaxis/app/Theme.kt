package com.tradeaxis.app

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// ── TradeAxis visual system: graphite surfaces + disciplined emerald accent ──
val Bg = Color(0xFF06100F)
val Surface1 = Color(0xFF0B1715)
val Surface2 = Color(0xFF11221F)
val Ink = Color(0xFFF0F7F4)
val Muted = Color(0xFF8B9F99)

val Nova = Color(0xFF00D995)
val NovaLight = Color(0xFF7FFFD4)
val NovaDeep = Color(0xFF00A874)
val Cyan = Color(0xFF55D8C4)

val UpGreen = Color(0xFF19D99B)
val DownRed = Color(0xFFFF5D73)
val Amber = Color(0xFFFFB84D)
val ObBlue = Color(0xFF5CA7FF)
val Orange = Color(0xFFFF9466)
val Pink = Color(0xFFFF82C8)

val NovaBrush = Brush.linearGradient(listOf(Nova, Cyan))
val NovaBrushH = Brush.horizontalGradient(listOf(NovaDeep, Nova, NovaLight))

fun gradeColor(g: String): Color = when (g) {
    "A+" -> Color(0xFF8DFFD3)
    "A" -> UpGreen
    "B" -> Amber
    else -> Muted
}

fun sideColor(buy: Boolean): Color = if (buy) UpGreen else DownRed

private val AxisTypography = Typography(
    headlineSmall = TextStyle(fontSize = 27.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.7).sp),
    titleLarge = TextStyle(fontSize = 23.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.5).sp),
    titleSmall = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontSize = 12.sp, lineHeight = 17.sp),
    labelMedium = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.2.sp)
)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Nova, onPrimary = Color(0xFF00150E), secondary = Cyan,
            background = Bg, onBackground = Ink, surface = Surface1, onSurface = Ink,
            surfaceVariant = Surface2, onSurfaceVariant = Muted, outline = Color(0x33FFFFFF), error = DownRed
        ),
        typography = AxisTypography, content = content
    )
}
