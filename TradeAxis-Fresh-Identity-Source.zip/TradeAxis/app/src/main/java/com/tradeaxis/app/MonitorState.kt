package com.tradeaxis.app

import kotlinx.coroutines.flow.MutableStateFlow

/** Everything the UI needs to know about one market. */
data class SymState(
    val symbol: String,
    val price: Double,
    val dayPct: Double,
    val spark: List<Double>,
    val htf: Bias,
    val htfTf: String,
    val atr: Double,
    val scan: ScanResult?,
    val decisions: Map<Dir, Decision>,
    val updated: Long,
    val error: String? = null
)

data class UiState(
    val running: Boolean = false,
    val status: String = "Stopped",
    val error: String? = null,
    val lastUpdate: Long = 0L,
    val symbols: Map<String, SymState> = emptyMap(),
    val unseenAlerts: Int = 0
) {
    /** Active decisions across all markets, best first. */
    fun decisions(): List<Decision> =
        symbols.values.flatMap { it.decisions.values }
            .sortedWith(compareBy<Decision> { it.verdict.ordinal }.thenByDescending { it.confidence })
}

object MonitorState {
    val ui = MutableStateFlow(UiState())

    fun update(f: (UiState) -> UiState) { ui.value = f(ui.value) }
}
