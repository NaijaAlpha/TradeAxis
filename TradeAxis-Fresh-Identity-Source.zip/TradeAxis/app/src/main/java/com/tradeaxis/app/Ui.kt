package com.tradeaxis.app

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.sin

// ───────────── surfaces ─────────────

fun Modifier.glass(accent: Color? = null, radius: Dp = 22.dp): Modifier {
    val shape = RoundedCornerShape(radius)
    val fill = if (accent != null)
        Brush.linearGradient(listOf(accent.copy(alpha = 0.16f), Surface1))
    else
        Brush.linearGradient(listOf(Surface2, Surface1))
    val edge = Brush.linearGradient(
        listOf(
            (accent ?: Color.White).copy(alpha = if (accent != null) 0.5f else 0.14f),
            Color.White.copy(alpha = 0.03f)
        )
    )
    return this.clip(shape).background(fill, shape).border(1.dp, edge, shape)
}

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    accent: Color? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier.fillMaxWidth().glass(accent).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        content = content
    )
}

@Composable
fun SectionCard(title: String, accent: Color? = null, trailing: @Composable () -> Unit = {}, content: @Composable ColumnScope.() -> Unit) {
    GlassCard(accent = accent) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.size(6.dp).background(NovaBrush, CircleShape))
                Text(title.uppercase(), style = MaterialTheme.typography.titleSmall, color = Muted)
            }
            trailing()
        }
        content()
    }
}

/** Full-screen ambient graphite background with restrained emerald glows. */
@Composable
fun AxisBackground(modifier: Modifier = Modifier) {
    Box(
        modifier
            .fillMaxSize()
            .background(Bg)
            .drawBehind {
                drawRect(
                    Brush.radialGradient(
                        listOf(Nova.copy(alpha = 0.20f), Color.Transparent),
                        center = Offset(size.width * 0.1f, size.height * 0.0f),
                        radius = size.width * 0.95f
                    )
                )
                drawRect(
                    Brush.radialGradient(
                        listOf(Cyan.copy(alpha = 0.10f), Color.Transparent),
                        center = Offset(size.width * 0.98f, size.height * 0.9f),
                        radius = size.width * 0.9f
                    )
                )
            }
    )
}

// ───────────── small widgets ─────────────

@Composable
fun Pill(text: String, color: Color) {
    Box(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(color.copy(alpha = 0.16f))
            .border(1.dp, color.copy(alpha = 0.28f), RoundedCornerShape(50))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(text, color = color, style = MaterialTheme.typography.labelMedium, maxLines = 1)
    }
}

@Composable
fun KV(k: String, v: String, vColor: Color = Color.Unspecified) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(k, color = Muted, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f).padding(end = 8.dp))
        Text(v, color = vColor, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
fun Hint(text: String) {
    Text(text, style = MaterialTheme.typography.bodySmall, color = Muted)
}

@Composable
fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, Modifier.weight(1f).padding(end = 12.dp), style = MaterialTheme.typography.bodyMedium)
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = Nova,
                checkedBorderColor = Nova,
                uncheckedThumbColor = Muted,
                uncheckedTrackColor = Surface2,
                uncheckedBorderColor = Color(0x33FFFFFF)
            )
        )
    }
}

@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    val bg by animateColorAsState(if (selected) Nova.copy(alpha = 0.22f) else Color.White.copy(alpha = 0.05f), label = "chipBg")
    val fg by animateColorAsState(if (selected) NovaLight else Muted, label = "chipFg")
    Box(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(bg)
            .border(1.dp, if (selected) Nova.copy(alpha = 0.6f) else Color.White.copy(alpha = 0.08f), RoundedCornerShape(50))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(text, color = fg, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 1)
    }
}

/** Small chip used in tight toolbars (chart timeframes). */
@Composable
fun MiniChip(text: String, selected: Boolean, onClick: () -> Unit) {
    val fg by animateColorAsState(if (selected) Color.White else Muted, label = "miniFg")
    Box(
        Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (selected) Nova.copy(alpha = 0.35f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 11.dp, vertical = 7.dp)
    ) {
        Text(text, color = fg, fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 1)
    }
}

@Composable
fun Segmented(options: List<Pair<String, Color>>, selected: Int, onSelect: (Int) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(Color.White.copy(alpha = 0.05f))
            .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(18.dp))
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        options.forEachIndexed { i, (label, col) ->
            val on = i == selected
            val bg by animateColorAsState(if (on) col.copy(alpha = 0.2f) else Color.Transparent, label = "segBg")
            Box(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(14.dp))
                    .background(bg)
                    .border(1.dp, if (on) col.copy(alpha = 0.5f) else Color.Transparent, RoundedCornerShape(14.dp))
                    .clickable { onSelect(i) }
                    .padding(vertical = 11.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(label, color = if (on) col else Muted, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
        }
    }
}

@Composable
fun GradientButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    danger: Boolean = false,
    ico: Ico? = null
) {
    val brush = if (danger)
        Brush.horizontalGradient(listOf(Color(0xFFFF4D6D), Color(0xFFD62F55)))
    else
        NovaBrushH
    Box(
        modifier
            .height(54.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(brush)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NovaIcon(ico ?: if (danger) Ico.Stop else Ico.Play, Color.White, 18.dp)
            Text(text, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
        }
    }
}

@Composable
fun GhostButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, color: Color = Ink) {
    Box(
        modifier
            .clip(RoundedCornerShape(14.dp))
            .background(Color.White.copy(alpha = 0.06f))
            .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 11.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = color) }
}

@Composable
fun RoundIconButton(ico: Ico, enabled: Boolean = true, size: Dp = 54.dp, onClick: () -> Unit) {
    Box(
        Modifier
            .size(size)
            .clip(RoundedCornerShape(18.dp))
            .background(Color.White.copy(alpha = if (enabled) 0.07f else 0.03f))
            .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(18.dp))
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        NovaIcon(ico, if (enabled) Ink else Muted.copy(alpha = 0.5f), 22.dp)
    }
}

@Composable
fun PulseDot(color: Color, animate: Boolean = true) {
    val t = rememberInfiniteTransition(label = "pulse")
    val k by t.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1400, easing = LinearEasing), RepeatMode.Restart),
        label = "pulseK"
    )
    Canvas(Modifier.size(14.dp)) {
        val c = Offset(size.width / 2, size.height / 2)
        if (animate) drawCircle(color.copy(alpha = (1f - k) * 0.5f), radius = size.width / 2 * (0.4f + k * 0.6f), center = c)
        drawCircle(color, radius = size.width * 0.22f, center = c)
    }
}

@Composable
fun StatTile(label: String, value: String, color: Color = Color.Unspecified, modifier: Modifier = Modifier) {
    Column(
        modifier.glass(radius = 18.dp).padding(horizontal = 14.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Text(value, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = color, maxLines = 1)
        Text(label, style = MaterialTheme.typography.bodySmall, color = Muted, maxLines = 1)
    }
}

@Composable
fun BarMeter(frac: Float, color: Color, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth().height(7.dp).clip(RoundedCornerShape(4.dp)).background(Color.White.copy(alpha = 0.08f))) {
        Box(Modifier.fillMaxWidth(frac.coerceIn(0f, 1f)).fillMaxHeight().background(color, RoundedCornerShape(4.dp)))
    }
}

@Composable
fun Sparkline(values: List<Double>, color: Color, modifier: Modifier = Modifier, dot: Boolean = true) {
    Canvas(modifier) {
        if (values.size < 2) return@Canvas
        val lo = values.min()
        var hi = values.max()
        if (hi - lo < 1e-12) hi = lo + 1e-6
        val dx = size.width / (values.size - 1)
        fun y(v: Double): Float = (size.height * (1 - (v - lo) / (hi - lo)) * 0.86f + size.height * 0.07f).toFloat()
        val line = Path()
        values.forEachIndexed { i, v -> if (i == 0) line.moveTo(0f, y(v)) else line.lineTo(i * dx, y(v)) }
        val fill = Path().apply {
            addPath(line)
            lineTo(size.width, size.height)
            lineTo(0f, size.height)
            close()
        }
        drawPath(fill, Brush.verticalGradient(listOf(color.copy(alpha = 0.30f), Color.Transparent)))
        drawPath(line, color, style = Stroke(width = 3f, cap = StrokeCap.Round, join = StrokeJoin.Round))
        if (dot) drawCircle(color, radius = 5f, center = Offset(size.width, y(values.last())))
    }
}

@Composable
fun ConfidenceRing(value: Int, label: String, color: Color, size: Dp = 68.dp) {
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val sw = 7.dp.toPx()
            val inset = sw / 2
            val arcSize = Size(this.size.width - sw, this.size.height - sw)
            drawArc(color.copy(alpha = 0.18f), 0f, 360f, false, Offset(inset, inset), arcSize, style = Stroke(sw))
            drawArc(
                color, -90f, 360f * value.coerceIn(0, 100) / 100f, false,
                Offset(inset, inset), arcSize, style = Stroke(sw, cap = StrokeCap.Round)
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value.toString(), fontWeight = FontWeight.ExtraBold, fontSize = 19.sp, color = color)
            Text(label, fontSize = 10.sp, color = Muted)
        }
    }
}

@Composable
fun CheckRow(ok: Boolean, text: String, dim: Boolean = false) {
    val c = if (ok) UpGreen else DownRed
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(Modifier.size(22.dp).background(c.copy(alpha = 0.16f), CircleShape), contentAlignment = Alignment.Center) {
            NovaIcon(if (ok) Ico.Check else Ico.Cross, c, 14.dp)
        }
        Text(text, color = if (dim) Muted else Ink, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
fun LegendDot(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        Box(Modifier.size(8.dp).background(color, CircleShape))
        Text(label, style = MaterialTheme.typography.bodySmall, color = Muted, maxLines = 1)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NovaSlider(value: Float, onChange: (Float) -> Unit, onDone: () -> Unit, range: ClosedFloatingPointRange<Float>) {
    Slider(
        value = value, onValueChange = onChange, onValueChangeFinished = onDone, valueRange = range,
        colors = SliderDefaults.colors(
            thumbColor = Nova, activeTrackColor = Nova,
            inactiveTrackColor = Color.White.copy(alpha = 0.1f)
        )
    )
}

@Composable
fun ScreenHeader(title: String, trailing: @Composable () -> Unit = {}) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(title, style = MaterialTheme.typography.titleLarge)
        trailing()
    }
}

// ───────────── logo ─────────────

/** The TradeAxis mark: an ascending A-axis with a directional arrow. [reveal] 0..1 animates it in. */
@Composable
fun NovaLogo(size: Dp, reveal: Float = 1f, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) { drawNovaMark(reveal) }
}

fun DrawScope.drawNovaMark(reveal: Float) {
    val s = size.width / 108f
    fun p(x: Float, y: Float) = Offset(x * s, y * s)
    val a = reveal.coerceIn(0f, 1f)
    val brush = Brush.linearGradient(listOf(Nova, NovaLight), start = p(28f, 80f), end = p(84f, 28f))
    drawCircle(Brush.radialGradient(listOf(Nova.copy(alpha = 0.18f * a), Color.Transparent), center = p(54f, 55f), radius = 54f * s), 54f * s, p(54f,55f))
    val rise = (1f - a) * 8f * s
    fun poly(vararg pts: Pair<Float, Float>) = Path().apply {
        pts.forEachIndexed { i, (x,y) -> if (i == 0) moveTo(x*s, y*s+rise) else lineTo(x*s, y*s+rise) }; close()
    }
    // Axis A: two rising legs and a clean crossbar.
    drawPath(poly(27f to 79f, 47f to 30f, 58f to 30f, 81f to 79f, 68f to 79f, 55f to 40f, 40f to 79f), brush, alpha=a)
    drawRoundRect(Color.White.copy(alpha=a), Offset(42f*s, 57f*s), Size(24f*s, 7f*s), CornerRadius(3f*s))
    // Directional arrow: the brand's "axis" toward opportunity.
    val arrow = Path().apply { moveTo(50f*s, 67f*s); lineTo(82f*s, 38f*s); lineTo(82f*s, 50f*s); lineTo(92f*s, 50f*s); lineTo(92f*s, 29f*s); lineTo(71f*s, 29f*s); lineTo(71f*s, 39f*s); lineTo(82f*s, 39f*s); lineTo(56f*s, 62f*s); close() }
    drawPath(arrow, Color.White, alpha=a)
}

// ───────────── icons (drawn, no icon library) ─────────────

enum class Ico { Home, Chart, Bell, Book, Gear, Refresh, Play, Stop, Check, Cross, Shield, Spark, Plus, Target, Trash }

@Composable
fun NovaIcon(ico: Ico, tint: Color, size: Dp = 24.dp) {
    Canvas(Modifier.size(size)) {
        val w = this.size.width
        val sw = w * 0.085f
        val st = Stroke(width = sw, cap = StrokeCap.Round, join = StrokeJoin.Round)
        when (ico) {
            Ico.Home -> {
                val c = CornerRadius(w * 0.08f)
                drawRoundRect(tint, Offset(w * 0.16f, w * 0.16f), Size(w * 0.31f, w * 0.38f), c)
                drawRoundRect(tint, Offset(w * 0.53f, w * 0.16f), Size(w * 0.31f, w * 0.22f), c)
                drawRoundRect(tint, Offset(w * 0.16f, w * 0.6f), Size(w * 0.31f, w * 0.24f), c)
                drawRoundRect(tint, Offset(w * 0.53f, w * 0.44f), Size(w * 0.31f, w * 0.4f), c)
            }
            Ico.Chart -> {
                listOf(0.24f to (0.3f to 0.62f), 0.5f to (0.2f to 0.5f), 0.76f to (0.38f to 0.78f)).forEach { (x, yy) ->
                    drawLine(tint, Offset(w * x, w * (yy.first - 0.08f)), Offset(w * x, w * (yy.second + 0.1f)), sw, StrokeCap.Round)
                    drawRoundRect(tint, Offset(w * (x - 0.07f), w * yy.first), Size(w * 0.14f, w * (yy.second - yy.first)), CornerRadius(w * 0.03f))
                }
            }
            Ico.Book -> {
                drawRoundRect(tint, Offset(w * 0.2f, w * 0.12f), Size(w * 0.6f, w * 0.76f), CornerRadius(w * 0.1f), style = st)
                drawLine(tint, Offset(w * 0.34f, w * 0.38f), Offset(w * 0.66f, w * 0.38f), sw, StrokeCap.Round)
                drawLine(tint, Offset(w * 0.34f, w * 0.56f), Offset(w * 0.58f, w * 0.56f), sw, StrokeCap.Round)
            }
            Ico.Bell -> {
                val p = Path().apply {
                    moveTo(w * 0.24f, w * 0.7f)
                    cubicTo(w * 0.3f, w * 0.6f, w * 0.3f, w * 0.5f, w * 0.3f, w * 0.42f)
                    cubicTo(w * 0.3f, w * 0.26f, w * 0.4f, w * 0.18f, w * 0.5f, w * 0.18f)
                    cubicTo(w * 0.6f, w * 0.18f, w * 0.7f, w * 0.26f, w * 0.7f, w * 0.42f)
                    cubicTo(w * 0.7f, w * 0.5f, w * 0.7f, w * 0.6f, w * 0.76f, w * 0.7f)
                    close()
                }
                drawPath(p, tint, style = st)
                drawArc(tint, 20f, 140f, false, Offset(w * 0.42f, w * 0.74f), Size(w * 0.16f, w * 0.12f), style = st)
            }
            Ico.Gear -> {
                val c = Offset(w / 2, w / 2)
                for (i in 0 until 8) {
                    val a = Math.toRadians(i * 45.0)
                    val cx = cos(a).toFloat()
                    val cy = sin(a).toFloat()
                    drawLine(tint, Offset(c.x + cx * w * 0.3f, c.y + cy * w * 0.3f), Offset(c.x + cx * w * 0.42f, c.y + cy * w * 0.42f), sw * 1.3f, StrokeCap.Round)
                }
                drawCircle(tint, radius = w * 0.25f, center = c, style = st)
                drawCircle(tint, radius = w * 0.08f, center = c)
            }
            Ico.Refresh -> {
                drawArc(tint, -50f, 285f, false, Offset(w * 0.18f, w * 0.18f), Size(w * 0.64f, w * 0.64f), style = st)
                val tip = Path().apply {
                    moveTo(w * 0.62f, w * 0.1f); lineTo(w * 0.84f, w * 0.26f); lineTo(w * 0.58f, w * 0.34f); close()
                }
                drawPath(tip, tint)
            }
            Ico.Play -> {
                val p = Path().apply { moveTo(w * 0.28f, w * 0.18f); lineTo(w * 0.8f, w * 0.5f); lineTo(w * 0.28f, w * 0.82f); close() }
                drawPath(p, tint)
            }
            Ico.Stop -> drawRoundRect(tint, Offset(w * 0.22f, w * 0.22f), Size(w * 0.56f, w * 0.56f), CornerRadius(w * 0.1f))
            Ico.Check -> {
                val p = Path().apply { moveTo(w * 0.2f, w * 0.52f); lineTo(w * 0.42f, w * 0.72f); lineTo(w * 0.8f, w * 0.28f) }
                drawPath(p, tint, style = Stroke(width = sw * 1.4f, cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
            Ico.Cross -> {
                drawLine(tint, Offset(w * 0.26f, w * 0.26f), Offset(w * 0.74f, w * 0.74f), sw * 1.4f, StrokeCap.Round)
                drawLine(tint, Offset(w * 0.74f, w * 0.26f), Offset(w * 0.26f, w * 0.74f), sw * 1.4f, StrokeCap.Round)
            }
            Ico.Shield -> {
                val p = Path().apply {
                    moveTo(w * 0.5f, w * 0.12f)
                    lineTo(w * 0.8f, w * 0.24f)
                    cubicTo(w * 0.8f, w * 0.55f, w * 0.7f, w * 0.75f, w * 0.5f, w * 0.88f)
                    cubicTo(w * 0.3f, w * 0.75f, w * 0.2f, w * 0.55f, w * 0.2f, w * 0.24f)
                    close()
                }
                drawPath(p, tint, style = st)
                val ck = Path().apply { moveTo(w * 0.36f, w * 0.5f); lineTo(w * 0.47f, w * 0.61f); lineTo(w * 0.66f, w * 0.38f) }
                drawPath(ck, tint, style = st)
            }
            Ico.Spark -> {
                val c = w / 2
                val r = w * 0.4f
                val k = r * 0.26f
                val p = Path().apply {
                    moveTo(c, c - r); lineTo(c + k, c - k); lineTo(c + r, c); lineTo(c + k, c + k)
                    lineTo(c, c + r); lineTo(c - k, c + k); lineTo(c - r, c); lineTo(c - k, c - k); close()
                }
                drawPath(p, tint)
            }
            Ico.Plus -> {
                drawLine(tint, Offset(w * 0.5f, w * 0.2f), Offset(w * 0.5f, w * 0.8f), sw * 1.4f, StrokeCap.Round)
                drawLine(tint, Offset(w * 0.2f, w * 0.5f), Offset(w * 0.8f, w * 0.5f), sw * 1.4f, StrokeCap.Round)
            }
            Ico.Target -> {
                val c = Offset(w / 2, w / 2)
                drawCircle(tint, radius = w * 0.24f, center = c, style = st)
                listOf(Offset(0f, -1f), Offset(0f, 1f), Offset(-1f, 0f), Offset(1f, 0f)).forEach {
                    drawLine(tint, Offset(c.x + it.x * w * 0.3f, c.y + it.y * w * 0.3f), Offset(c.x + it.x * w * 0.44f, c.y + it.y * w * 0.44f), sw, StrokeCap.Round)
                }
            }
            Ico.Trash -> {
                drawLine(tint, Offset(w * 0.2f, w * 0.28f), Offset(w * 0.8f, w * 0.28f), sw, StrokeCap.Round)
                drawLine(tint, Offset(w * 0.4f, w * 0.18f), Offset(w * 0.6f, w * 0.18f), sw, StrokeCap.Round)
                drawRoundRect(tint, Offset(w * 0.27f, w * 0.34f), Size(w * 0.46f, w * 0.5f), CornerRadius(w * 0.06f), style = st)
            }
        }
    }
}

// ───────────── floating navigation ─────────────

data class NavTab(val label: String, val ico: Ico)

@Composable
fun NovaNavBar(tabs: List<NavTab>, selected: Int, badge: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier
            .clip(RoundedCornerShape(30.dp))
            .background(Brush.verticalGradient(listOf(Color(0xE61A2142), Color(0xF20A0F22))))
            .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(30.dp))
            .padding(6.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        tabs.forEachIndexed { i, tab ->
            val on = i == selected
            val bg by animateColorAsState(if (on) Nova.copy(alpha = 0.22f) else Color.Transparent, label = "navBg")
            val tint by animateColorAsState(if (on) NovaLight else Muted, label = "navTint")
            Row(
                Modifier
                    .animateContentSize()
                    .clip(RoundedCornerShape(24.dp))
                    .background(bg)
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onSelect(i) }
                    .padding(horizontal = if (on) 14.dp else 12.dp, vertical = 11.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Box {
                    NovaIcon(tab.ico, tint, 22.dp)
                    if (tab.ico == Ico.Bell && badge > 0) {
                        Box(
                            Modifier.align(Alignment.TopEnd).offset(3.dp, (-2).dp).size(9.dp)
                                .background(DownRed, CircleShape).border(1.5.dp, Color(0xFF0A0F22), CircleShape)
                        )
                    }
                }
                if (on) Text(tab.label, color = tint, fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 1)
            }
        }
    }
}
