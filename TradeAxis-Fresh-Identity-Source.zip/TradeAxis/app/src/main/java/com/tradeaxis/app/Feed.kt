package com.tradeaxis.app

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import kotlin.math.PI
import kotlin.math.floor
import kotlin.math.min
import kotlin.math.sin

/** Market data. Demo = built-in simulated prices; OANDA and Twelve Data = real candles. */
object Feed {
    fun sourceLabel(p: Prefs): String = when (p.source) {
        "OANDA" -> if (p.oandaLive) "OANDA live" else "OANDA practice"
        "TWELVE" -> "Twelve Data"
        else -> "Demo feed"
    }

    /** Blocking network call: run it off the main thread. Candles come oldest first, time in UTC milliseconds. */
    fun fetch(p: Prefs, symbol: String, tf: String, count: Int): List<Candle> {
        val id = Instruments.normalize(symbol)
        val n = count.coerceIn(10, 5000)
        return when (p.source) {
            "OANDA" -> oanda(p, id, tf, n)
            "TWELVE" -> twelve(p, id, tf, n)
            else -> Demo.candles(id, tf, n, System.currentTimeMillis())
        }
    }

    // ───────────── OANDA ─────────────
    private fun oanda(p: Prefs, id: String, tf: String, n: Int): List<Candle> {
        val token = p.oandaToken.trim()
        if (token.isEmpty()) throw IllegalStateException("Add your OANDA API token in Settings")
        val host = if (p.oandaLive) "api-fxtrade.oanda.com" else "api-fxpractice.oanda.com"
        val url = "https://$host/v3/instruments/$id/candles?granularity=${oandaGranularity(tf)}&count=$n&price=M"
        val json = JSONObject(httpGet(url, mapOf("Authorization" to "Bearer $token")))
        val arr = json.optJSONArray("candles") ?: throw IllegalStateException(json.optString("errorMessage", "OANDA returned no candles"))
        val out = ArrayList<Candle>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val m = o.optJSONObject("mid") ?: continue
            out.add(
                Candle(
                    parseTime(o.getString("time")),
                    m.getString("o").toDouble(), m.getString("h").toDouble(),
                    m.getString("l").toDouble(), m.getString("c").toDouble()
                )
            )
        }
        if (out.isEmpty()) throw IllegalStateException("No candles for ${Instruments.label(id)}")
        return out
    }

    private fun oandaGranularity(tf: String): String = when (tf) {
        "M1", "M5", "M15", "M30", "H1", "H4" -> tf
        else -> "M5"
    }

    // ───────────── Twelve Data ─────────────
    private fun twelve(p: Prefs, id: String, tf: String, n: Int): List<Candle> {
        val key = p.apiKey.trim()
        if (key.isEmpty()) throw IllegalStateException("Add your Twelve Data API key in Settings")
        val sym = URLEncoder.encode(Instruments.get(id).twelve, "UTF-8")
        val url = "https://api.twelvedata.com/time_series?symbol=$sym&interval=${twelveInterval(tf)}" +
            "&outputsize=$n&order=ASC&timezone=UTC&apikey=${URLEncoder.encode(key, "UTF-8")}"
        val json = JSONObject(httpGet(url))
        if (json.optString("status") == "error") throw IllegalStateException(json.optString("message", "Twelve Data error"))
        val arr = json.optJSONArray("values") ?: throw IllegalStateException("Twelve Data returned no candles")
        val fmt = utc("yyyy-MM-dd HH:mm:ss")
        val out = ArrayList<Candle>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            var dt = o.getString("datetime")
            if (dt.length == 10) dt += " 00:00:00"
            val t = fmt.parse(dt)?.time ?: continue
            out.add(Candle(t, o.getString("open").toDouble(), o.getString("high").toDouble(), o.getString("low").toDouble(), o.getString("close").toDouble()))
        }
        out.sortBy { it.time }
        if (out.isEmpty()) throw IllegalStateException("No candles for ${Instruments.label(id)}")
        return out
    }

    private fun twelveInterval(tf: String): String = when (tf) {
        "M1" -> "1min"
        "M5" -> "5min"
        "M15" -> "15min"
        "M30" -> "30min"
        "H1" -> "1h"
        "H4" -> "4h"
        else -> "5min"
    }

    // ───────────── helpers ─────────────
    private fun utc(pattern: String): SimpleDateFormat =
        SimpleDateFormat(pattern, Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }

    private fun parseTime(s: String): Long = utc("yyyy-MM-dd'T'HH:mm:ss").parse(s.take(19))?.time ?: 0L

    private fun httpGet(url: String, headers: Map<String, String> = emptyMap()): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 10_000
            c.readTimeout = 15_000
            c.requestMethod = "GET"
            c.setRequestProperty("Accept", "application/json")
            for ((k, v) in headers) c.setRequestProperty(k, v)
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                val msg = try { JSONObject(body).optString("errorMessage", "") } catch (_: Exception) { "" }
                throw IllegalStateException("HTTP $code" + if (msg.isNotEmpty()) ": $msg" else "")
            }
            return body
        } finally {
            c.disconnect()
        }
    }
}

/**
 * Demo feed: a smooth, repeatable "market" built from a few sine waves plus noise.
 * Same symbol and time always give the same price, candles line up with each other,
 * and the last candle keeps moving with the clock.
 */
private object Demo {
    private class Spec(val base: Double, val vol: Double)

    private val specs = mapOf(
        "XAU_USD" to Spec(2650.0, 0.009),
        "XAG_USD" to Spec(31.0, 0.016),
        "WTICO_USD" to Spec(72.0, 0.016),
        "BTC_USD" to Spec(68000.0, 0.025),
        "GBP_USD" to Spec(1.31, 0.005),
        "GBP_JPY" to Spec(195.0, 0.0065),
        "EUR_USD" to Spec(1.09, 0.0045),
        "USD_JPY" to Spec(149.0, 0.0055),
        "EUR_JPY" to Spec(162.0, 0.006),
        "AUD_USD" to Spec(0.67, 0.0055),
        "USD_CAD" to Spec(1.36, 0.004)
    )
    private val periodsHours = doubleArrayOf(53.0, 17.3, 5.1, 1.7, 0.47)
    private val amps = doubleArrayOf(1.0, 0.8, 0.6, 0.45, 0.3)

    /** Deterministic pseudo-random number in 0..1 for (seed, k). */
    private fun unit(seed: Int, k: Long): Double {
        var x = k * 374761393L + seed.toLong() * 668265263L
        x = (x xor (x ushr 13)) * 1274126177L
        x = x xor (x ushr 16)
        return (x and 0xFFFFFFL).toDouble() / 0xFFFFFFL.toDouble()
    }

    /** Smooth value noise in -1..1. */
    private fun noise(seed: Int, x: Double): Double {
        val i = floor(x).toLong()
        val f = x - i
        val a = unit(seed, i) * 2.0 - 1.0
        val b = unit(seed, i + 1) * 2.0 - 1.0
        val s = f * f * (3.0 - 2.0 * f)
        return a + (b - a) * s
    }

    fun price(sym: String, t: Long): Double {
        val spec = specs[sym] ?: Spec(100.0, 0.006)
        val seed = sym.hashCode()
        val h = t / 3_600_000.0
        var wave = 0.0
        for (i in periodsHours.indices) {
            val phase = unit(seed, 100L + i) * 2.0 * PI
            wave += amps[i] * sin(2.0 * PI * h / periodsHours[i] + phase)
        }
        val n = noise(seed, t / 20_000.0)
        return spec.base * (1.0 + spec.vol * (0.22 * wave + 0.05 * n))
    }

    fun candles(sym: String, tf: String, count: Int, now: Long): List<Candle> {
        val period = Backtester.periodMs(tf)
        val last = now / period
        val out = ArrayList<Candle>(count)
        val steps = 12
        for (k in (last - count + 1)..last) {
            val start = k * period
            val end = min(start + period, now)
            val o = price(sym, start)
            var c = o
            var hi = o
            var lo = o
            for (s in 1..steps) {
                val t = start + (end - start) * s / steps
                c = price(sym, t)
                if (c > hi) hi = c
                if (c < lo) lo = c
            }
            out.add(Candle(start, o, hi, lo, c))
        }
        return out
    }
}
