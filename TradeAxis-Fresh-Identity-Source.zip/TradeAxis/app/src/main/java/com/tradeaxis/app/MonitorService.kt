package com.tradeaxis.app

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * The engine room. Every cycle, for every watched market:
 *   price engine (SMC scan) → Copilot (+ Risk Guard + AI history) → alert engine → journal.
 */
class MonitorService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private var wake: PowerManager.WakeLock? = null

    private val armed = LinkedHashSet<String>()                    // setups already alerted (de-dupe)
    private val lastSignalAt = HashMap<String, Long>()             // symbol|dir -> ms
    private val htfCache = HashMap<String, Triple<Bias, String, Long>>()
    private var lastGuardKey = ""

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopMonitoring(); return START_NOT_STICKY }
        startMonitoring()
        return START_STICKY
    }

    private fun startMonitoring() {
        if (job?.isActive == true) return
        Notifier.channels(this)
        val note = Notifier.statusNotification(this, "Starting…")
        if (Build.VERSION.SDK_INT >= 34) startForeground(Notifier.STATUS_ID, note, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else startForeground(Notifier.STATUS_ID, note)
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "TradeAxis:monitor").apply { setReferenceCounted(false); acquire(12 * 60 * 60 * 1000L) }
        } catch (_: Exception) { }
        MonitorState.update { it.copy(running = true, status = "Starting…", error = null) }
        job = scope.launch { loop() }
    }

    private fun stopMonitoring() {
        job?.cancel()
        try { wake?.let { if (it.isHeld) it.release() } } catch (_: Exception) { }
        MonitorState.update { it.copy(running = false, status = "Stopped") }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        job?.cancel()
        scope.cancel()
        try { wake?.let { if (it.isHeld) it.release() } } catch (_: Exception) { }
        MonitorState.update { it.copy(running = false, status = "Stopped") }
        super.onDestroy()
    }

    private suspend fun loop() {
        val ctx = applicationContext
        TradeJournal.load(ctx); AlertHistory.load(ctx); AlertRules.load(ctx)
        while (scope.isActive) {
            val p = Prefs(ctx)
            val symbols = p.watched()
            val states = HashMap<String, SymState>(MonitorState.ui.value.symbols)
            var ok = 0
            var firstError: String? = null
            if (symbols.isEmpty()) firstError = "No markets selected — pick some in Settings → Markets"
            for (sym in symbols) {
                if (!scope.isActive) return
                try {
                    states[sym] = processSymbol(ctx, p, sym)
                    ok++
                } catch (e: Exception) {
                    val msg = e.message ?: e.javaClass.simpleName
                    if (firstError == null) firstError = "${Instruments.label(sym)}: $msg"
                    states[sym]?.let { states[sym] = it.copy(error = msg) }
                }
            }
            for (k in states.keys.toList()) if (k !in symbols) states.remove(k)

            try { guardAlerts(ctx, p) } catch (_: Exception) { }

            val acc = RiskGuard.account(p, TradeJournal.visible(TradeJournal.items.value, p.isDemo), System.currentTimeMillis())
            val actionable = states.values.sumOf { s -> s.decisions.values.count { it.verdict == Verdict.TAKE } }
            val status = when {
                symbols.isEmpty() -> "No markets selected"
                ok == 0 -> "Waiting for data"
                else -> "Watching $ok markets · ${Feed.sourceLabel(p)}" + if (actionable > 0) " · $actionable signal" + (if (actionable > 1) "s" else "") else ""
            }
            MonitorState.update {
                it.copy(running = true, status = status, error = if (ok == 0) firstError else null, lastUpdate = System.currentTimeMillis(), symbols = states)
            }
            Notifier.updateStatus(ctx, status + if (acc.state != GuardState.SAFE) " · Guard ${acc.state.label}" else "")
            delay((if (p.isDemo) minOf(p.pollSec, 6) else p.pollSec).coerceAtLeast(3) * 1000L)
        }
    }

    private fun htfBias(p: Prefs, sym: String): Triple<Bias, String, Long> {
        val tf = Backtester.htfOf(p.tf)
        val cached = htfCache[sym]
        val now = System.currentTimeMillis()
        if (cached != null && cached.second == tf && now - cached.third < 5 * 60_000L) return cached
        val bias = try { Scanner.bias(Feed.fetch(p, sym, tf, 250)) } catch (_: Exception) { cached?.first ?: Bias.UNKNOWN }
        val t = Triple(bias, tf, now)
        htfCache[sym] = t
        return t
    }

    private fun processSymbol(ctx: Context, p: Prefs, sym: String): SymState {
        val now = System.currentTimeMillis()
        val candles = Feed.fetch(p, sym, p.tf, 400)
        if (candles.size < 60) throw IllegalStateException("not enough candles")
        val price = candles.last().close
        PriceBook.set(sym, price)

        // 1) resolve open signals on this market
        for (t in TradeJournal.items.value.filter { it.symbol == sym && it.outcome == Outcome.OPEN && it.demo == p.isDemo }) {
            val u = TradeTracker.evaluate(t, candles, now, p.expiryHours)
            if (u != t) {
                TradeJournal.update(ctx, u)
                if (u.outcome != Outcome.OPEN && p.notifyOutcome) announceResult(ctx, u)
                else if (u.tp1Hit && !t.tp1Hit && p.notifyOutcome) {
                    Notifier.send(ctx, AlertKind.RESULT, sym, if (u.side == Dir.BULLISH) "BUY" else "SELL",
                        "TP1 hit · ${Instruments.label(sym)}", "Price reached ${num(u.tp1)}." + if (u.beAfterTp1) " Stop moves to entry." else " Consider taking partials.")
                }
            }
        }

        // 2) price engine
        val (htf, htfTf, _) = htfBias(p, sym)
        val enabled = p.methodSet()
        val scan = Scanner.scan(candles, sym, p.tf, p.config(), Rule(Dir.BEARISH, p.reqOb, p.reqSweep, p.reqDisp), enabled, htf)

        // 3) copilot on each direction
        val decisions = HashMap<Dir, Decision>()
        if (scan != null) {
            val trades = TradeJournal.visible(TradeJournal.items.value, p.isDemo)
            for (d in Dir.values()) {
                if (d == Dir.BEARISH && !p.bearish) continue
                if (d == Dir.BULLISH && !p.bullish) continue
                val setup = scan.setups[d] ?: continue
                if (setup.score < p.minScore) continue
                // the setup's own entry must still be sensible against live price
                val dec = Copilot.evaluate(p, sym, p.tf, setup, price, trades, now)
                decisions[d] = dec
                handleDecision(ctx, p, dec, now)
            }
        }

        // 4) alert engine (user rules, volatility)
        try { AlertEngine.check(ctx, p, sym, candles, price, scan, now) } catch (_: Exception) { }

        return SymState(
            symbol = sym, price = price, dayPct = AlertEngine.dayChangePct(candles, price, now),
            spark = candles.takeLast(60).map { it.close }, htf = htf, htfTf = htfTf,
            atr = scan?.atr ?: 0.0, scan = scan, decisions = decisions, updated = now
        )
    }

    private fun handleDecision(ctx: Context, p: Prefs, d: Decision, now: Long) {
        if (d.id in armed) return
        val sideKey = d.symbol + "|" + d.setup.dir.name
        val last = lastSignalAt[sideKey]
        if (last != null && now - last < p.cooldownMin * 60_000L) return
        if (p.hoursOn && !inTradingHours(now, p.hoursStart, p.hoursEnd)) return

        val side = if (d.buy) "BUY" else "SELL"
        when (d.verdict) {
            Verdict.BLOCKED -> {
                armed.add(d.id)
                if (p.notifyBlocked) Notifier.send(ctx, AlertKind.BLOCKED, d.symbol, side,
                    "Skipped $side ${Instruments.label(d.symbol)}", "Setup looked valid but the Guard stopped it:\n" + d.blocks.joinToString("\n") { "• $it" }, push = true)
            }
            Verdict.WATCH -> {
                armed.add(d.id)
                if (p.alertWatch) record(ctx, p, d, now, side)
            }
            Verdict.TAKE -> {
                armed.add(d.id)
                record(ctx, p, d, now, side)
            }
        }
        while (armed.size > 600) armed.remove(armed.first())
    }

    private fun record(ctx: Context, p: Prefs, d: Decision, now: Long, side: String) {
        lastSignalAt[d.symbol + "|" + d.setup.dir.name] = now
        val s = d.setup
        TradeJournal.add(
            ctx, TradeRecord(
                id = 0, symbol = d.symbol, tf = d.tf, side = s.dir, entry = s.entry, sl = s.sl, tp = s.tp2, rr = s.rr,
                openTime = now, method = s.method.name, grade = s.grade, score = s.score, tp1 = s.tp1,
                beAfterTp1 = p.beAfterTp1, lots = d.lots, riskUsd = d.riskUsd,
                copilot = d.verdict.label, confidence = d.confidence, demo = p.isDemo
            )
        )
        Notifier.send(ctx, AlertKind.SIGNAL, d.symbol, side, AlertText.signalTitle(d), AlertText.signalBody(d), push = true)
    }

    private fun announceResult(ctx: Context, t: TradeRecord) {
        val side = if (t.side == Dir.BULLISH) "BUY" else "SELL"
        val (title, body) = when (t.outcome) {
            Outcome.WIN -> "Target hit ✓ ${Instruments.label(t.symbol)}" to "$side reached TP at ${num(t.tp)} · +${String.format(java.util.Locale.US, "%.1f", t.r)}R" + moneyTag(t)
            Outcome.LOSS -> "Stop hit ✗ ${Instruments.label(t.symbol)}" to "$side stopped out at ${num(t.sl)} · -1.0R" + moneyTag(t)
            Outcome.BE -> "Breakeven ${Instruments.label(t.symbol)}" to "$side closed at entry after TP1."
            Outcome.EXPIRED -> "Signal expired ${Instruments.label(t.symbol)}" to "$side closed at ${num(t.closePrice)} · ${String.format(java.util.Locale.US, "%+.1f", t.r)}R"
            Outcome.OPEN -> return
        }
        Notifier.send(ctx, AlertKind.RESULT, t.symbol, side, title, body, push = true)
    }

    private fun moneyTag(t: TradeRecord) = if (t.riskUsd > 0) " (${signedUsd(t.pnlUsd)})" else ""

    private fun guardAlerts(ctx: Context, p: Prefs) {
        if (!p.guardOn || !p.notifyGuard) return
        val now = System.currentTimeMillis()
        val acc = RiskGuard.account(p, TradeJournal.visible(TradeJournal.items.value, p.isDemo), now)
        val key = "${acc.state}|${now / 86_400_000L}"
        if (acc.state == GuardState.SAFE) { lastGuardKey = ""; return }
        if (key == lastGuardKey) return
        lastGuardKey = key
        val title = if (acc.state == GuardState.LOCKED) "Trading locked" else "Risk guard caution"
        Notifier.send(ctx, AlertKind.RISK, "", "", title, acc.reason + "\nToday ${signedUsd(acc.todayPnl)} · drawdown ${String.format(java.util.Locale.US, "%.1f", acc.ddPct)}%", push = true)
    }

    companion object {
        const val ACTION_STOP = "com.tradeaxis.app.STOP"

        fun start(ctx: Context) {
            val i = Intent(ctx, MonitorService::class.java)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        }

        fun stop(ctx: Context) {
            ctx.startService(Intent(ctx, MonitorService::class.java).setAction(ACTION_STOP))
        }
    }
}
