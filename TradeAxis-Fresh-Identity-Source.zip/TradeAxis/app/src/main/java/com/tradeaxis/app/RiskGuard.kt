package com.tradeaxis.app

import java.util.Calendar
import java.util.TimeZone
import kotlin.math.abs
import kotlin.math.max

enum class GuardState(val label: String) { SAFE("SAFE"), CAUTION("CAUTION"), LOCKED("LOCKED") }

/** Snapshot of the account as seen by the guard. All money is USD. */
data class Account(
    val startBalance: Double,
    val equity: Double,
    val closedPnl: Double,
    val floatingPnl: Double,
    val todayPnl: Double,            // closed today + floating
    val dailyUsedPct: Double,        // % of the starting balance lost today (0 if in profit)
    val ddPct: Double,               // % below the equity peak
    val progressPct: Double,         // % gained vs profit target (can be negative)
    val openCount: Int,
    val openRiskUsd: Double,
    val tradesToday: Int,
    val lossesToday: Int,
    val state: GuardState,
    val reason: String               // why it is CAUTION / LOCKED ("" when SAFE)
)

data class GuardCheck(
    val blocks: List<String>,
    val warnings: List<String>,
    val riskMult: Double
) {
    val ok get() = blocks.isEmpty()
}

object RiskGuard {

    fun dayStart(now: Long): Long = now - Math.floorMod(now, 86_400_000L)

    fun account(p: Prefs, trades: List<TradeRecord>, now: Long): Account {
        val start = p.balance.toDouble()
        val closed = trades.filter { it.outcome != Outcome.OPEN }.sortedBy { it.closeTime }
        var eq = start
        var peak = start
        for (t in closed) {
            eq += t.pnlUsd
            if (eq > peak) peak = eq
        }
        val closedPnl = eq - start
        val open = trades.filter { it.outcome == Outcome.OPEN }
        val floating = open.sumOf { t ->
            val px = PriceBook.get(t.symbol)
            if (px == null) 0.0 else t.rAt(px) * t.riskUsd
        }
        val equity = eq + floating
        val ds = dayStart(now)
        val todayClosed = closed.filter { it.closeTime >= ds }.sumOf { it.pnlUsd }
        val todayPnl = todayClosed + floating
        val dailyUsed = if (start > 0 && todayPnl < 0) -todayPnl / start * 100.0 else 0.0
        val ddPct = if (start > 0) max(0.0, (max(peak, equity) - equity) / start * 100.0) else 0.0
        val target = p.profitTargetPct.toDouble()
        val progress = if (start > 0 && target > 0) (equity - start) / start * 100.0 / target * 100.0 else 0.0
        val openRisk = open.sumOf { it.riskUsd }
        val tradesToday = trades.count { it.openTime >= ds }
        val lossesToday = closed.count { it.outcome == Outcome.LOSS && it.closeTime >= ds }

        var state = GuardState.SAFE
        var reason = ""
        if (p.guardOn) {
            val dl = p.dailyLossPct.toDouble()
            val md = p.maxDdPct.toDouble()
            when {
                dl > 0 && dailyUsed >= dl -> { state = GuardState.LOCKED; reason = "Daily loss limit reached" }
                md > 0 && ddPct >= md -> { state = GuardState.LOCKED; reason = "Max drawdown reached" }
                p.maxLossesPerDay > 0 && lossesToday >= p.maxLossesPerDay -> { state = GuardState.LOCKED; reason = "Max losses for today reached" }
                dl > 0 && dailyUsed >= dl * 0.6 -> { state = GuardState.CAUTION; reason = "Over 60% of the daily loss limit used" }
                md > 0 && ddPct >= md * 0.6 -> { state = GuardState.CAUTION; reason = "Over 60% of max drawdown used" }
            }
        }
        return Account(start, equity, closedPnl, floating, todayPnl, dailyUsed, ddPct, progress, open.size, openRisk, tradesToday, lossesToday, state, reason)
    }

    private fun weekendClosed(now: Long): Boolean {
        val c = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
        c.timeInMillis = now
        val d = c.get(Calendar.DAY_OF_WEEK)
        val h = c.get(Calendar.HOUR_OF_DAY)
        return (d == Calendar.FRIDAY && h >= 21) || d == Calendar.SATURDAY || (d == Calendar.SUNDAY && h < 22)
    }

    /** Net directional exposure per currency / asset across open trades (+1 per long leg, −1 per short leg). */
    private fun exposure(open: List<TradeRecord>): Map<String, Int> {
        val m = HashMap<String, Int>()
        for (t in open) {
            val ins = Instruments.get(t.symbol)
            val d = if (t.side == Dir.BULLISH) 1 else -1
            m[ins.base] = (m[ins.base] ?: 0) + d
            m[ins.quote] = (m[ins.quote] ?: 0) - d
        }
        return m
    }

    /**
     * Checks one candidate trade. [plannedRiskUsd] is the money that would be lost if the stop is hit.
     * Blocks stop the trade; warnings are shown but do not stop it.
     */
    fun check(p: Prefs, trades: List<TradeRecord>, symbol: String, dir: Dir, plannedRiskUsd: Double, now: Long): GuardCheck {
        if (!p.guardOn) return GuardCheck(emptyList(), emptyList(), 1.0)
        val blocks = ArrayList<String>()
        val warns = ArrayList<String>()
        val acc = account(p, trades, now)
        val start = acc.startBalance
        var mult = 1.0

        val dl = p.dailyLossPct.toDouble()
        if (dl > 0) {
            if (acc.dailyUsedPct >= dl) blocks += "Daily loss limit reached (${fmt1(acc.dailyUsedPct)}% of ${fmt1(dl)}%)"
            else if (start > 0 && acc.dailyUsedPct + plannedRiskUsd / start * 100.0 > dl)
                blocks += "A full stop-out would break your ${fmt1(dl)}% daily loss limit"
        }
        val md = p.maxDdPct.toDouble()
        if (md > 0) {
            if (acc.ddPct >= md) blocks += "Max drawdown reached (${fmt1(acc.ddPct)}% of ${fmt1(md)}%)"
            else if (start > 0 && acc.ddPct + plannedRiskUsd / start * 100.0 > md)
                blocks += "A full stop-out would break your ${fmt1(md)}% max drawdown"
        }
        if (p.maxLossesPerDay > 0 && acc.lossesToday >= p.maxLossesPerDay) blocks += "${acc.lossesToday} losses today — trading paused"
        if (p.maxTradesDay > 0 && acc.tradesToday >= p.maxTradesDay) blocks += "Daily trade limit reached (${p.maxTradesDay})"
        if (p.maxOpen > 0 && acc.openCount >= p.maxOpen) blocks += "Already ${acc.openCount} open signals (limit ${p.maxOpen})"
        val orp = p.maxOpenRiskPct.toDouble()
        if (orp > 0 && start > 0 && (acc.openRiskUsd + plannedRiskUsd) / start * 100.0 > orp)
            blocks += "Total open risk would exceed ${fmt1(orp)}% of the account"

        val open = trades.filter { it.outcome == Outcome.OPEN }
        if (open.any { it.symbol == symbol }) blocks += "A signal on ${Instruments.label(symbol)} is already open"

        if (p.corrGuard) {
            val ins = Instruments.get(symbol)
            val d = if (dir == Dir.BULLISH) 1 else -1
            val ex = exposure(open)
            for ((ccy, sign) in listOf(ins.base to d, ins.quote to -d)) {
                val cur = ex[ccy] ?: 0
                if (cur * sign >= 2) blocks += "Too much $ccy exposure — ${abs(cur)} open trades already lean the same way"
                else if (cur * sign == 1) warns += "Adds to your $ccy exposure"
            }
        }
        if (p.weekendGuard && !p.isDemo && Instruments.get(symbol).cat != Cat.CRYPTO && weekendClosed(now))
            blocks += "Market is closed / weekend gap risk"

        if (p.cutRiskInDd && md > 0 && acc.ddPct >= md * 0.5) {
            mult = 0.5
            warns += "Risk halved while drawdown is above 50% of the limit"
        }
        if (acc.state == GuardState.CAUTION) warns += acc.reason
        return GuardCheck(blocks, warns.distinct(), mult)
    }

    private fun fmt1(v: Double) = String.format(java.util.Locale.US, "%.1f", v)
}
