package com.tradeaxis.app

data class BtSettings(
    val symbol: String,
    val tf: String,
    val cfg: Config,
    val rule: Rule,
    val enabled: Set<Method>,
    val minScore: Int,
    val cooldownMin: Int,
    val hoursOn: Boolean,
    val hoursStart: Int,
    val hoursEnd: Int,
    val expiryHours: Int,
    val beAfterTp1: Boolean
)

data class BtResult(
    val trades: List<TradeRecord>,
    val overall: Stats,
    val byMethod: Map<String, Stats>,
    val byGrade: Map<String, Stats>,
    val candles: Int,
    val spanDays: Double
)

object Backtester {
    fun periodMs(tf: String): Long = when (tf) {
        "M1" -> 60_000L
        "M5" -> 300_000L
        "M15" -> 900_000L
        "M30" -> 1_800_000L
        "H1" -> 3_600_000L
        "H4" -> 14_400_000L
        else -> 300_000L
    }

    /** Which higher timeframe gives the trend bias for a trading timeframe. */
    fun htfOf(tf: String): String = when (tf) {
        "M1" -> "M15"
        "M5" -> "H1"
        "M15" -> "H4"
        "H1" -> "H4"
        else -> "H1"
    }

    /** Bias known at a given time, using only higher-timeframe candles that had already closed. */
    private fun biasSeries(htf: List<Candle>, periodMs: Long): (Long) -> Bias {
        if (htf.size < 60) return { Bias.UNKNOWN }
        val closes = htf.map { it.close }
        val e20 = Scanner.ema(closes, 20)
        val e50 = Scanner.ema(closes, 50)
        var ptr = 0
        return { t ->
            while (ptr + 1 < htf.size && htf[ptr + 1].time + periodMs <= t) ptr++
            if (ptr < 50 || htf[ptr].time + periodMs > t) {
                Bias.UNKNOWN
            } else {
                val f = e20[ptr]
                val s = e50[ptr]
                val px = closes[ptr]
                when {
                    f > s && px > s -> Bias.BULL
                    f < s && px < s -> Bias.BEAR
                    else -> Bias.NEUTRAL
                }
            }
        }
    }

    fun run(
        candles: List<Candle>, htf: List<Candle>, htfTf: String, s: BtSettings,
        progress: ((Int, Int) -> Unit)? = null
    ): BtResult {
        val biasAt = biasSeries(htf, periodMs(htfTf))
        val trades = ArrayList<TradeRecord>()
        val busyUntil = HashMap<Dir, Long>()
        val lastOpen = HashMap<Dir, Long>()
        val armed = HashSet<String>()
        var nextId = 1L
        val start = 220

        for (i in start until candles.size) {
            if (progress != null && i % 25 == 0) progress(i, candles.size)
            val t = candles[i].time
            val scan = Scanner.scan(candles.subList(0, i + 1), s.symbol, s.tf, s.cfg, s.rule, s.enabled, biasAt(t)) ?: continue
            for (d in Dir.values()) {
                val setup = scan.setups[d] ?: continue
                if (setup.score < s.minScore) continue
                if (setup.id in armed) continue
                if ((busyUntil[d] ?: Long.MIN_VALUE) > t) continue
                val lo = lastOpen[d]
                if (lo != null && t - lo < s.cooldownMin * 60_000L) continue
                if (s.hoursOn && !inTradingHours(t, s.hoursStart, s.hoursEnd)) continue
                armed.add(setup.id)
                val rec = TradeRecord(
                    id = nextId++, symbol = s.symbol, tf = s.tf, side = d,
                    entry = setup.entry, sl = setup.sl, tp = setup.tp2, rr = setup.rr, openTime = t,
                    method = setup.method.name, grade = setup.grade, score = setup.score,
                    tp1 = setup.tp1, beAfterTp1 = s.beAfterTp1
                )
                val (done, closeT) = TradeTracker.resolve(rec, candles, i, s.expiryHours)
                trades += done
                busyUntil[d] = closeT
                lastOpen[d] = t
            }
        }
        val span = if (candles.size > 1) (candles.last().time - candles.first().time) / 86_400_000.0 else 0.0
        return BtResult(
            trades = trades,
            overall = computeStats(trades),
            byMethod = statsByMethod(trades),
            byGrade = trades.groupBy { it.grade }.mapValues { computeStats(it.value) },
            candles = candles.size,
            spanDays = span
        )
    }
}
