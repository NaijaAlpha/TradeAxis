package com.tradeaxis.app

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.abs

enum class Outcome { OPEN, WIN, LOSS, BE, EXPIRED }

data class TradeRecord(
    val id: Long,
    val symbol: String,
    val tf: String,
    val side: Dir,
    val entry: Double,
    val sl: Double,
    val tp: Double,                    // final target (TP2)
    val rr: Double,
    val openTime: Long,
    val outcome: Outcome = Outcome.OPEN,
    val closeTime: Long = 0L,
    val closePrice: Double = 0.0,
    val manual: Boolean = false,
    val method: String = "SWEEP_OB",
    val grade: String = "",
    val score: Int = 0,
    val tp1: Double = 0.0,
    val tp1Hit: Boolean = false,
    val beAfterTp1: Boolean = false,   // true: stop moves to entry once TP1 is hit
    val lots: Double = 0.0,
    val riskUsd: Double = 0.0,         // dollars risked when the signal was issued
    val copilot: String = "",          // Copilot verdict at signal time: TAKE / WATCH
    val confidence: Int = 0,           // Copilot confidence 0..100
    val note: String = "",             // free text written by the trader
    val demo: Boolean = false          // true = produced by the simulated demo feed
) {
    val risk: Double get() = abs(entry - sl)

    val methodLabel: String get() = Method.values().firstOrNull { it.name == method }?.label ?: method

    /** Result in R if the trade were closed at [price]. */
    fun rAt(price: Double): Double {
        if (risk <= 0.0) return 0.0
        return if (side == Dir.BEARISH) (entry - price) / risk else (price - entry) / risk
    }

    /** Dollars made or lost at the risk that was set when the signal fired. */
    val pnlUsd: Double get() = r * riskUsd

    /** Realised R (0 while open). */
    val r: Double
        get() = when (outcome) {
            Outcome.WIN -> rr
            Outcome.LOSS -> -1.0
            Outcome.BE -> 0.0
            Outcome.EXPIRED -> rAt(closePrice)
            Outcome.OPEN -> 0.0
        }
}

fun inTradingHours(nowMs: Long, start: Int, end: Int): Boolean {
    if (start == end) return true
    val h = ((nowMs / 3_600_000L) % 24).toInt()
    return if (start < end) h >= start && h < end else h >= start || h < end
}

object TradeTracker {
    private fun expired(t: TradeRecord, atMs: Long, expiryHours: Int) =
        expiryHours > 0 && atMs - t.openTime > expiryHours * 3_600_000L

    /**
     * One candle's high/low against the trade. Worst case first: if the stop and a target are
     * both touched inside the same candle, the stop wins.
     */
    private fun step(t: TradeRecord, k: Candle, closeAt: Long): TradeRecord {
        val bear = t.side == Dir.BEARISH
        val movedToBe = t.tp1Hit && t.beAfterTp1
        val effSl = if (movedToBe) t.entry else t.sl
        val hitSl = if (bear) k.high >= effSl else k.low <= effSl
        if (hitSl) {
            return if (movedToBe) t.copy(outcome = Outcome.BE, closeTime = closeAt, closePrice = t.entry)
            else t.copy(outcome = Outcome.LOSS, closeTime = closeAt, closePrice = t.sl)
        }
        val hitTp = if (bear) k.low <= t.tp else k.high >= t.tp
        if (hitTp) return t.copy(outcome = Outcome.WIN, closeTime = closeAt, closePrice = t.tp)
        if (!t.tp1Hit && t.tp1 != 0.0) {
            val hitTp1 = if (bear) k.low <= t.tp1 else k.high >= t.tp1
            if (hitTp1) return t.copy(tp1Hit = true)
        }
        return t
    }

    /**
     * Live evaluation of an OPEN trade.
     * - Candles that START AFTER the signal candle are checked by high/low.
     * - The signal's own candle only counts through the live price.
     */
    fun evaluate(t: TradeRecord, candles: List<Candle>, nowMs: Long, expiryHours: Int): TradeRecord {
        if (t.outcome != Outcome.OPEN || candles.isEmpty()) return t
        val own = candles.lastOrNull { it.time <= t.openTime }?.time ?: Long.MIN_VALUE
        var cur = t
        var prevClose = t.entry
        for (k in candles) {
            if (k.time <= own) continue
            if (expired(cur, k.time, expiryHours)) {
                return cur.copy(outcome = Outcome.EXPIRED, closeTime = k.time, closePrice = prevClose)
            }
            cur = step(cur, k, maxOf(k.time, t.openTime))
            if (cur.outcome != Outcome.OPEN) return cur
            prevClose = k.close
        }
        val last = candles.last()
        if (last.time == own) {
            cur = step(cur, Candle(last.time, last.close, last.close, last.close, last.close), nowMs)
            if (cur.outcome != Outcome.OPEN) return cur
        }
        if (expired(cur, nowMs, expiryHours)) {
            return cur.copy(outcome = Outcome.EXPIRED, closeTime = nowMs, closePrice = last.close)
        }
        return cur
    }

    /** Backtest helper: plays the trade forward from candle [fromIdx]. Returns the result and the close time. */
    fun resolve(t: TradeRecord, candles: List<Candle>, fromIdx: Int, expiryHours: Int): Pair<TradeRecord, Long> {
        var cur = t
        var prevClose = t.entry
        for (idx in fromIdx + 1 until candles.size) {
            val k = candles[idx]
            if (expired(cur, k.time, expiryHours)) {
                return cur.copy(outcome = Outcome.EXPIRED, closeTime = k.time, closePrice = prevClose) to k.time
            }
            cur = step(cur, k, k.time)
            if (cur.outcome != Outcome.OPEN) return cur to k.time
            prevClose = k.close
        }
        return cur to Long.MAX_VALUE
    }
}

data class Stats(
    val closed: Int, val open: Int,
    val wins: Int, val losses: Int, val be: Int, val expired: Int,
    val netR: Double, val avgR: Double,
    val winRate: Double?, val profitFactor: Double?,
    val best: Double, val worst: Double,
    val streak: Int,                 // +n = n wins in a row, -n = n losses in a row
    val equity: List<Double>,        // cumulative R, oldest -> newest
    val maxDrawdown: Double          // largest peak-to-trough fall of the equity curve, in R
)

fun computeStats(all: List<TradeRecord>): Stats {
    val closedList = all.filter { it.outcome != Outcome.OPEN }.sortedBy { it.closeTime }
    val wins = closedList.count { it.outcome == Outcome.WIN }
    val losses = closedList.count { it.outcome == Outcome.LOSS }
    val rs = closedList.map { it.r }
    val gain = rs.filter { it > 0 }.sum()
    val loss = -rs.filter { it < 0 }.sum()
    var acc = 0.0
    val eq = rs.map { acc += it; acc }

    var peak = 0.0
    var dd = 0.0
    for (v in eq) {
        if (v > peak) peak = v
        if (peak - v > dd) dd = peak - v
    }

    var streak = 0
    for (t in closedList.asReversed()) {
        if (t.outcome != Outcome.WIN && t.outcome != Outcome.LOSS) continue
        val w = t.outcome == Outcome.WIN
        if (streak == 0) streak = if (w) 1 else -1
        else if (w && streak > 0) streak++
        else if (!w && streak < 0) streak--
        else break
    }
    val net = rs.sum()
    return Stats(
        closed = closedList.size,
        open = all.count { it.outcome == Outcome.OPEN },
        wins = wins, losses = losses,
        be = closedList.count { it.outcome == Outcome.BE },
        expired = closedList.count { it.outcome == Outcome.EXPIRED },
        netR = net,
        avgR = if (closedList.isNotEmpty()) net / closedList.size else 0.0,
        winRate = if (wins + losses > 0) wins.toDouble() / (wins + losses) else null,
        profitFactor = if (loss > 0) gain / loss else null,
        best = rs.maxOrNull() ?: 0.0,
        worst = rs.minOrNull() ?: 0.0,
        streak = streak,
        equity = eq,
        maxDrawdown = dd
    )
}

fun statsByMethod(list: List<TradeRecord>): Map<String, Stats> =
    list.groupBy { it.method }.mapValues { computeStats(it.value) }

fun journalCsv(list: List<TradeRecord>): String {
    val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
    fun n(v: Double) = String.format(Locale.US, "%.5f", v).trimEnd('0').trimEnd('.').ifEmpty { "0" }
    val sb = StringBuilder("opened_utc,symbol,tf,method,grade,score,copilot,confidence,side,entry,sl,tp1,tp2,rr,lots,risk_usd,outcome,closed_utc,close_price,r,pnl_usd,manual,demo,note\n")
    list.sortedBy { it.openTime }.forEach { t ->
        sb.append(fmt.format(Date(t.openTime))).append(',')
            .append(t.symbol).append(',').append(t.tf).append(',')
            .append(t.method).append(',').append(t.grade).append(',').append(t.score).append(',')
            .append(t.copilot).append(',').append(t.confidence).append(',')
            .append(if (t.side == Dir.BEARISH) "SELL" else "BUY").append(',')
            .append(n(t.entry)).append(',').append(n(t.sl)).append(',').append(n(t.tp1)).append(',').append(n(t.tp)).append(',')
            .append(n(t.rr)).append(',').append(n(t.lots)).append(',').append(n(t.riskUsd)).append(',')
            .append(t.outcome.name).append(',')
            .append(if (t.closeTime > 0) fmt.format(Date(t.closeTime)) else "").append(',')
            .append(if (t.outcome == Outcome.OPEN) "" else n(t.closePrice)).append(',')
            .append(n(t.r)).append(',').append(n(t.pnlUsd)).append(',')
            .append(t.manual).append(',').append(t.demo).append(',')
            .append('"').append(t.note.replace('"', '\'')).append('"').append('\n')
    }
    return sb.toString()
}
