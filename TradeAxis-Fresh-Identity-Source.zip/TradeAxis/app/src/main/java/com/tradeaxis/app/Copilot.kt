package com.tradeaxis.app

import java.util.Locale
import kotlin.math.roundToInt

enum class Verdict(val label: String) { TAKE("TAKE"), WATCH("WATCH"), BLOCKED("BLOCKED") }

/**
 * The Copilot's judgement of one setup after weighing everything together:
 * the price engine (score), higher-timeframe trend, the trader's own track record (AI analysis),
 * and the Risk Guard.
 */
data class Decision(
    val symbol: String,
    val tf: String,
    val setup: Setup,
    val verdict: Verdict,
    val confidence: Int,
    val lots: Double,
    val riskUsd: Double,
    val reasons: List<Reason>,
    val blocks: List<String>,
    val notes: List<String>,
    val time: Long
) {
    val id: String get() = symbol + "|" + setup.id
    val buy: Boolean get() = setup.dir == Dir.BULLISH
}

object Copilot {

    fun evaluate(
        p: Prefs, symbol: String, tf: String, setup: Setup, price: Double,
        trades: List<TradeRecord>, now: Long
    ): Decision {
        var conf = setup.score
        val notes = ArrayList<String>()
        val blocks = ArrayList<String>()

        // 1) the trader's own history with this method on this market
        if (p.useEdge) {
            val e = AiAnalyst.edge(trades, symbol, setup.method)
            if (e != null && e.n >= 8) {
                val adj = (e.avgR * 10.0).roundToInt().coerceIn(-10, 10)
                conf += adj
                val txt = "History: ${setup.method.short} on ${Instruments.label(symbol)} — ${(e.winRate * 100).roundToInt()}% wins, " +
                    String.format(Locale.US, "%+.2f", e.avgR) + "R over ${e.n} trades"
                notes += txt
            }
        }

        // 2) user-muted weak spots (set from the AI analysis)
        val muted = p.mutedSet()
        AiAnalyst.keysFor(symbol, setup.method, now).firstOrNull { it in muted }?.let {
            blocks += "Muted from AI analysis (${it.substringAfter(':').replace('_', ' ')}) — unmute it in Journal → AI analysis"
        }

        // 3) Risk Guard + position size
        val baseRisk = p.balance.toDouble() * p.riskPct.toDouble() / 100.0
        val g0 = RiskGuard.check(p, trades, symbol, setup.dir, baseRisk, now)
        val riskTarget = baseRisk * g0.riskMult
        val lots = Sizing.lots(symbol, riskTarget, setup.risk, price)
        val riskUsd = Sizing.riskUsdFor(symbol, lots, setup.risk, price)
        // re-check with the real risk after rounding up to the minimum lot
        val g = if (riskUsd > baseRisk * 1.05) RiskGuard.check(p, trades, symbol, setup.dir, riskUsd, now) else g0
        blocks += g.blocks
        if (riskUsd > riskTarget * 1.5 && riskTarget > 0) notes += "Smallest lot size risks \$${usd(riskUsd)}, more than the planned \$${usd(riskTarget)}"
        notes += g.warnings

        conf = conf.coerceIn(0, 100)
        val verdict = when {
            blocks.isNotEmpty() -> Verdict.BLOCKED
            conf >= p.takeConf -> Verdict.TAKE
            else -> Verdict.WATCH
        }
        return Decision(symbol, tf, setup, verdict, conf, lots, riskUsd, setup.reasons, blocks.distinct(), notes.distinct(), now)
    }
}
