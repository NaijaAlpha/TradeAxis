package com.tradeaxis.app

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color as AColor
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.material3.IconButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(SystemBarStyle.dark(AColor.TRANSPARENT), SystemBarStyle.dark(AColor.TRANSPARENT))
        TradeJournal.load(this); AlertHistory.load(this); AlertRules.load(this)
        val p = Prefs(this)
        if (p.keepAwake) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContent { AppTheme { Root(p) } }
    }
}

private val TABS = listOf(
    NavTab("Home", Ico.Home), NavTab("Chart", Ico.Chart), NavTab("Trade", Ico.Plus),
    NavTab("Journal", Ico.Book), NavTab("Settings", Ico.Gear)
)

@Composable
private fun Root(p: Prefs) {
    val ctx = LocalContext.current
    var showIntro by remember { mutableStateOf(p.showIntro) }
    var tab by remember { mutableIntStateOf(0) }
    var symbol by remember { mutableStateOf(p.symbol) }
    var rev by remember { mutableIntStateOf(0) }
    val ui by MonitorState.ui.collectAsState()
    val all by TradeJournal.items.collectAsState()
    val demo = remember(rev) { p.isDemo }
    val trades = remember(all, demo) { TradeJournal.visible(all, demo) }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    fun ensureNotifications() { if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) permission.launch(Manifest.permission.POST_NOTIFICATIONS) }
    LaunchedEffect(showIntro) { if (!showIntro) ensureNotifications() }
    BackHandler(enabled = !showIntro && tab != 0) { tab = 0 }

    Crossfade(showIntro, animationSpec = tween(400), label = "intro") { intro ->
        if (intro) IntroScreen { showIntro = false }
        else Box(Modifier.fillMaxSize()) {
            AxisBackground()
            when (tab) {
                0 -> HomeScreen(ui, trades, p,
                    onToggle = { if (ui.running) MonitorService.stop(ctx) else { ensureNotifications(); MonitorService.start(ctx) } },
                    onOpenChart = { symbol = it; p.symbol = it; tab = 1 },
                    onOpenSettings = { tab = 4 },
                    onOpenTrade = { tab = 2 },
                    onOpenAlerts = { tab = 5 })
                1 -> ChartScreen(ui, trades, symbol, { symbol = it; p.symbol = it }, p)
                2 -> TradeEntryScreen(p) { tab = 3 }
                3 -> JournalScreen(trades, p)
                4 -> SettingsScreen(p, onWatchChanged = { rev++ })
                5 -> AlertsScreen(ui, p, symbol)
            }
            if (tab == 0) {
                IconButton(onClick = { tab = 5 }, modifier = Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(end = 8.dp, top = 8.dp)) {
                    NovaIcon(Ico.Bell, if (ui.unseenAlerts > 0) Nova else Muted, 22.dp)
                }
            }
            NovaNavBar(TABS, if (tab in 0..4) tab else 0, ui.unseenAlerts, { tab = it }, Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 10.dp))
        }
    }
}
