package com.tradeaxis.app

import java.util.Locale
import kotlin.math.abs

enum class Bias { BULL, BEAR, NEUTRAL, UNKNOWN }

enum class Method(val label: String, val short: String, val blurb: String) {
    SWEEP_OB("Sweep + OB retest", "Sweep+OB", "Liquidity sweep, displacement, then price returns to the order block"),
    SWEEP_REVERSAL("Liquidity sweep reversal", "Sweep reversal", "Stop-run of a previous-day, Asian or swing level, then a displacement back"),
    FVG_RETEST("FVG retest", "FVG retest", "Price returns into the fair value gap left by a displacement"),
    BOS_RETEST("Break of structure retest", "BOS retest", "A swing high or low is broken, then price retests the broken level"),
    OTE("OTE 62–79% retrace", "OTE", "Pullback into the 62–79% zone of an impulse leg"),
    BREAKOUT("Momentum breakout", "Breakout", "Displacement candle closing beyond the previous-day or Asian level"),
    EMA_PULLBACK("EMA trend pullback", "EMA pullback", "Pullback to the 20 EMA inside a clean 20/50/200 EMA trend")
}

data class Reason(val text: String, val ok: Boolean = true)

data class Setup(
    val method: Method,
    val dir: Dir,
    val entry: Double,
    val sl: Double,
    val tp1: Double,
    val tp2: Double,
    val rr: Double,
    val score: Int,
    val reasons: List<Reason>,
    val anchor: Long,                      // time of the key candle; stops duplicate alerts for the same setup
    val zone: Zone? = null,
    val confirmedBy: List<Method> = emptyList()
) {
    val risk: Double get() = abs(entry - sl)
    val grade: String get() = when { score >= 80 -> "A+"; score >= 65 -> "A"; score >= 50 -> "B"; else -> "C" }
    val id: String get() = "${dir.name}|${method.name}|$anchor"
}

data class ScanResult(
    val snaps: Map<Dir, Snapshot>,
    val setups: Map<Dir, Setup>,           // best (merged) setup per direction
    val all: Map<Dir, List<Setup>>,        // every method that fired, best first
    val asianHigh: Double?,
    val asianLow: Double?,
    val atr: Double
)

object Scanner {

    // ───────────── indicators ─────────────
    fun ema(v: List<Double>, n: Int): DoubleArray {
        val out = DoubleArray(v.size)
        if (v.isEmpty()) return out
        val k = 2.0 / (n + 1)
        out[0] = v[0]
        for (i in 1 until v.size) out[i] = v[i] * k + out[i - 1] * (1 - k)
        return out
    }

    /** Higher-timeframe trend from CLOSED candles: EMA20 vs EMA50 and price vs EMA50. */
    fun bias(htf: List<Candle>): Bias {
        if (htf.size < 60) return Bias.UNKNOWN
        val closes = htf.dropLast(1).map { it.close }
        val f = ema(closes, 20).last()
        val s = ema(closes, 50).last()
        val px = closes.last()
        return when {
            f > s && px > s -> Bias.BULL
            f < s && px < s -> Bias.BEAR
            else -> Bias.NEUTRAL
        }
    }

    private fun asianRange(all: List<Candle>): Pair<Double?, Double?> {
        val lastT = all.last().time
        val day = lastT - Math.floorMod(lastT, 86_400_000L)
        val end = day + 7 * 3_600_000L
        if (lastT < end) return null to null              // range is still forming
        val seg = all.filter { it.time >= day && it.time < end }
        if (seg.size < 6) return null to null
        return seg.maxOf { it.high } to seg.minOf { it.low }
    }

    private class Ctx(
        val all: List<Candle>, val closed: List<Candle>, val cfg: Config, val htf: Bias,
        val price: Double, val atr: Double, val buffer: Double,
        val pdh: Double?, val pdl: Double?, val asianHigh: Double?, val asianLow: Double?,
        val e20: DoubleArray, val e50: DoubleArray, val e200: DoubleArray,
        val killzone: Boolean, val mid: Double,
        val sweepRecent: Map<Dir, Sweep?>
    )

    // ───────────── entry point ─────────────
    /** [all] = candles oldest -> newest; the LAST one is the forming (live) candle. */
    fun scan(
        all: List<Candle>, symbol: String, tf: String, cfg: Config,
        rule: Rule, enabled: Set<Method>, htf: Bias
    ): ScanResult? {
        if (all.size < 60) return null
        val snaps = HashMap<Dir, Snapshot>()
        for (d in Dir.values()) SmcEngine.analyze(all, symbol, tf, d, cfg)?.let { snaps[d] = it }
        val bearSnap = snaps[Dir.BEARISH] ?: return null

        val closed = all.dropLast(1)
        val atr = closed.takeLast(14).map { it.range }.average()
        if (atr.isNaN() || atr <= 0.0) return null
        val price = all.last().close
        val (ah, al) = asianRange(all)
        val closes = closed.map { it.close }
        val hour = ((all.last().time / 3_600_000L) % 24).toInt()
        val seg = closed.takeLast(100)
        val sweepCfg = cfg.copy(sweepLookback = 20, sweepPdOnly = false)
        val ctx = Ctx(
            all, closed, cfg, htf, price, atr, atr * 0.2,
            bearSnap.pdh, bearSnap.pdl, ah, al,
            ema(closes, 20), ema(closes, 50), ema(closes, 200),
            killzone = hour in 7..9 || hour in 12..15,
            mid = (seg.maxOf { it.high } + seg.minOf { it.low }) / 2.0,
            sweepRecent = Dir.values().associateWith { SmcEngine.findSweep(all, it, bearSnap.pdh, bearSnap.pdl, sweepCfg) }
        )

        val setups = HashMap<Dir, Setup>()
        val raw = HashMap<Dir, List<Setup>>()
        for (d in Dir.values()) {
            val found = ArrayList<Setup>()
            val snap = snaps[d] ?: continue
            if (Method.SWEEP_OB in enabled) sweepOb(ctx, snap, rule.copy(dir = d))?.let { found += it }
            if (Method.SWEEP_REVERSAL in enabled) sweepReversal(ctx, d)?.let { found += it }
            if (Method.FVG_RETEST in enabled) fvgRetest(ctx, d)?.let { found += it }
            if (Method.BOS_RETEST in enabled) bosRetest(ctx, d)?.let { found += it }
            if (Method.OTE in enabled) ote(ctx, d)?.let { found += it }
            if (Method.BREAKOUT in enabled) breakout(ctx, d)?.let { found += it }
            if (Method.EMA_PULLBACK in enabled) emaPullback(ctx, d)?.let { found += it }
            if (found.isEmpty()) continue
            found.sortByDescending { it.score }
            raw[d] = found
            val best = found[0]
            val others = found.drop(1)
            setups[d] = if (others.isEmpty()) best else best.copy(
                score = minOf(100, best.score + minOf(15, 5 * others.size)),
                confirmedBy = others.map { it.method },
                reasons = best.reasons + Reason("Also confirmed by: " + others.joinToString { it.method.short })
            )
        }
        return ScanResult(snaps, setups, raw, ah, al, atr)
    }

    // ───────────── shared finishing step: risk bounds, targets, confluence score ─────────────
    private fun finish(
        c: Ctx, m: Method, dir: Dir, entry: Double, sl: Double, base: Int,
        reasons: MutableList<Reason>, zone: Zone?, anchor: Long, skipSweep: Boolean = false
    ): Setup? {
        val bear = dir == Dir.BEARISH
        val risk = if (bear) sl - entry else entry - sl
        if (risk <= 0.0) return null
        if (risk < c.cfg.minRiskAtr * c.atr || risk > c.cfg.maxRiskAtr * c.atr) return null

        var score = base
        when {
            c.htf == Bias.UNKNOWN || c.htf == Bias.NEUTRAL -> {}
            (c.htf == Bias.BEAR) == bear -> {
                score += 15
                reasons += Reason("Higher-timeframe trend is ${if (bear) "bearish" else "bullish"}")
            }
            else -> {
                if (c.cfg.htfFilter) return null
                score -= 15
                reasons += Reason("Against the higher-timeframe trend", false)
            }
        }
        if (c.killzone) { score += 6; reasons += Reason("London / New York session") }
        val goodZone = if (bear) c.price > c.mid else c.price < c.mid
        if (goodZone) { score += 8; reasons += Reason(if (bear) "Selling from premium" else "Buying from discount") }
        if (!skipSweep) c.sweepRecent[dir]?.let {
            score += 8
            reasons += Reason("Liquidity swept recently (${it.label})")
        }
        score = score.coerceIn(0, 100)

        val rr = c.cfg.rr
        val tp1 = if (bear) entry - risk else entry + risk
        val tp2 = if (bear) entry - risk * rr else entry + risk * rr
        return Setup(m, dir, entry, sl, tp1, tp2, rr, score, reasons.toList(), anchor, zone)
    }

    // ───────────── 1. Sweep + OB retest (original composite rule) ─────────────
    private fun sweepOb(c: Ctx, snap: Snapshot, rule: Rule): Setup? {
        if (!SmcEngine.triggered(snap, rule)) return null
        val sig = SmcEngine.signal(c.all, snap, c.cfg.rr) ?: return null
        val bear = snap.dir == Dir.BEARISH
        val reasons = mutableListOf<Reason>()
        var base = 55
        snap.sweep?.let {
            reasons += Reason("Swept ${it.label} ${num(it.level)}")
            base += if (it.label.startsWith("Previous")) 8 else 4
        }
        snap.displacement?.let {
            reasons += Reason("${if (bear) "Bearish" else "Bullish"} displacement (${it.barsAgo} bars ago)")
            base += 6
        }
        snap.ob?.let {
            if (snap.inOb) {
                reasons += Reason("Price inside the ${if (bear) "bearish" else "bullish"} order block ${num(it.low)}–${num(it.high)}")
                base += 6
            }
        }
        snap.fvg?.let { reasons += Reason("Unfilled FVG ${num(it.low)}–${num(it.high)}") }
        return finish(c, Method.SWEEP_OB, snap.dir, sig.entry, sig.sl, base, reasons, snap.ob,
            snap.ob?.time ?: c.all.last().time, skipSweep = true)
    }

    // ───────────── helpers ─────────────
    /** Fractal swing points (2 candles each side) as (index, price). */
    private fun swingPts(c: List<Candle>, highs: Boolean, from: Int, to: Int): List<Pair<Int, Double>> {
        val out = ArrayList<Pair<Int, Double>>()
        for (j in maxOf(2, from)..minOf(to, c.lastIndex - 2)) {
            val v = if (highs) c[j].high else c[j].low
            var ok = true
            for (o in intArrayOf(-2, -1, 1, 2)) {
                val x = c[j + o]
                val worse = if (highs) v <= x.high else v >= x.low
                if (worse) { ok = false; break }
            }
            if (ok) out += j to v
        }
        return out
    }

    // ───────────── 2. Liquidity sweep reversal ─────────────
    private fun sweepReversal(c: Ctx, dir: Dir): Setup? {
        val bear = dir == Dir.BEARISH
        val cl = c.closed
        val last = cl.lastIndex
        val sw = swingPts(cl, bear, last - 120, last - 3)
        for (j in last downTo maxOf(1, last - 5)) {
            val k = cl[j]
            val cands = ArrayList<Triple<String, Double, Int>>()
            if (bear) {
                c.pdh?.let { cands += Triple("Previous Day High", it, 10) }
                c.asianHigh?.let { cands += Triple("Asian range high", it, 8) }
            } else {
                c.pdl?.let { cands += Triple("Previous Day Low", it, 10) }
                c.asianLow?.let { cands += Triple("Asian range low", it, 8) }
            }
            for ((s, v) in sw) if (s + 2 < j) cands += Triple(if (bear) "Swing high" else "Swing low", v, 4)
            val hit = cands
                .filter { (_, lv, _) -> if (bear) k.high > lv && k.close < lv else k.low < lv && k.close > lv }
                .maxByOrNull { it.third } ?: continue
            val (label, level, bonus) = hit
            val confirmed = (j..last).any { SmcEngine.isDisplacement(cl, it, dir, c.cfg) }
            if (!confirmed) continue
            if (bear && c.price >= level || !bear && c.price <= level) continue
            if (abs(level - c.price) > 3.0 * c.atr) continue
            val wick = if (bear) maxOf(cl.subList(j, cl.size).maxOf { it.high }, c.all.last().high)
            else minOf(cl.subList(j, cl.size).minOf { it.low }, c.all.last().low)
            val sl = if (bear) wick + c.buffer else wick - c.buffer
            val reasons = mutableListOf(
                Reason("Swept $label ${num(level)}"),
                Reason("Closed back ${if (bear) "below" else "above"} the level"),
                Reason("${if (bear) "Bearish" else "Bullish"} displacement confirms the reversal")
            )
            return finish(c, Method.SWEEP_REVERSAL, dir, c.price, sl, 52 + bonus, reasons, null, k.time, skipSweep = true)
        }
        return null
    }

    // ───────────── 3. FVG retest ─────────────
    private fun fvgRetest(c: Ctx, dir: Dir): Setup? {
        val bear = dir == Dir.BEARISH
        val cl = c.closed
        val last = cl.lastIndex
        for (i in last - 1 downTo maxOf(22, last - c.cfg.retestLookback)) {
            if (!SmcEngine.isDisplacement(cl, i, dir, c.cfg)) continue
            val c1 = cl[i - 1]
            val c3 = cl[i + 1]
            val zone: Zone = if (bear) {
                if (c1.low > c3.high) Zone(c3.high, c1.low, dir, cl[i].time) else continue
            } else {
                if (c1.high < c3.low) Zone(c1.high, c3.low, dir, cl[i].time) else continue
            }
            val broken = (i + 2..last).any { if (bear) cl[it].close > zone.high else cl[it].close < zone.low }
            if (broken) continue
            if (!zone.contains(c.price)) continue
            val ref = if (bear) maxOf(c1.high, cl[i].high) else minOf(c1.low, cl[i].low)
            val sl = if (bear) ref + c.buffer else ref - c.buffer
            val reasons = mutableListOf(
                Reason("${if (bear) "Bearish" else "Bullish"} displacement left a fair value gap"),
                Reason("Price retraced into the gap ${num(zone.low)}–${num(zone.high)}")
            )
            return finish(c, Method.FVG_RETEST, dir, c.price, sl, 52, reasons, zone, cl[i].time)
        }
        return null
    }

    // ───────────── 4. Break of structure + retest ─────────────
    private fun bosRetest(c: Ctx, dir: Dir): Setup? {
        val bear = dir == Dir.BEARISH
        val cl = c.closed
        val last = cl.lastIndex
        // bullish BOS = a swing HIGH is broken, bearish BOS = a swing LOW is broken
        val sw = swingPts(cl, !bear, last - 90, last - 3)
        for ((s, level) in sw.asReversed()) {
            val b = (s + 3..last).firstOrNull { if (bear) cl[it].close < level else cl[it].close > level } ?: continue
            if (last - b > c.cfg.retestLookback || last - b < 2) continue
            val seg = cl.subList(b, cl.size)
            val extreme = if (bear) seg.minOf { it.low } else seg.maxOf { it.high }
            if (abs(extreme - level) < 0.8 * c.atr) continue
            val failed = seg.any { if (bear) it.close > level + 0.5 * c.atr else it.close < level - 0.5 * c.atr }
            if (failed) continue
            val inRetest = if (bear) c.price >= level - 0.6 * c.atr && c.price <= level + 0.3 * c.atr
            else c.price >= level - 0.3 * c.atr && c.price <= level + 0.6 * c.atr
            if (!inRetest) continue
            val origin = if (bear) cl.subList(s, cl.size).maxOf { it.high } else cl.subList(s, cl.size).minOf { it.low }
            val sl = if (bear) origin + c.buffer else origin - c.buffer
            val reasons = mutableListOf(
                Reason("Broke the swing ${if (bear) "low" else "high"} at ${num(level)}"),
                Reason("Price is retesting the broken level")
            )
            var base = 50
            if (SmcEngine.isDisplacement(cl, b, dir, c.cfg)) {
                base += 10
                reasons += Reason("The break came with displacement")
            }
            return finish(c, Method.BOS_RETEST, dir, c.price, sl, base, reasons,
                Zone(level - 0.3 * c.atr, level + 0.3 * c.atr, dir, cl[b].time), cl[b].time)
        }
        return null
    }

    // ───────────── 5. OTE (optimal trade entry) ─────────────
    private fun ote(c: Ctx, dir: Dir): Setup? {
        val bear = dir == Dir.BEARISH
        val cl = c.closed
        val last = cl.lastIndex
        for (i in last downTo maxOf(22, last - c.cfg.retestLookback)) {
            if (!SmcEngine.isDisplacement(cl, i, dir, c.cfg)) continue
            val from = maxOf(0, i - 5)
            val origin = if (bear) cl.subList(from, i + 1).maxOf { it.high } else cl.subList(from, i + 1).minOf { it.low }
            val seg = cl.subList(i, cl.size)
            val peak = if (bear) seg.minOf { it.low } else seg.maxOf { it.high }
            val leg = abs(peak - origin)
            if (leg < 1.5 * c.atr) continue
            if (seg.any { if (bear) it.close > origin else it.close < origin }) continue
            val zl = if (bear) peak + 0.62 * leg else peak - 0.79 * leg
            val zh = if (bear) peak + 0.79 * leg else peak - 0.62 * leg
            if (c.price < zl || c.price > zh) continue
            val sl = if (bear) origin + c.buffer else origin - c.buffer
            val reasons = mutableListOf(
                Reason("Impulse leg of ${num(leg)}"),
                Reason("Price is in the 62–79% retracement zone ${num(zl)}–${num(zh)}")
            )
            var base = 52
            SmcEngine.findFvg(cl, dir, c.cfg)?.let {
                if (it.high >= zl && it.low <= zh) { base += 8; reasons += Reason("Unfilled FVG inside the zone") }
            }
            return finish(c, Method.OTE, dir, c.price, sl, base, reasons, Zone(zl, zh, dir, cl[i].time), cl[i].time)
        }
        return null
    }

    // ───────────── 6. Momentum breakout ─────────────
    private fun breakout(c: Ctx, dir: Dir): Setup? {
        val bear = dir == Dir.BEARISH
        val cl = c.closed
        val last = cl.lastIndex
        val levels = ArrayList<Triple<String, Double, Int>>()
        if (bear) {
            c.pdl?.let { levels += Triple("Previous Day Low", it, 10) }
            c.asianLow?.let { levels += Triple("Asian range low", it, 6) }
        } else {
            c.pdh?.let { levels += Triple("Previous Day High", it, 10) }
            c.asianHigh?.let { levels += Triple("Asian range high", it, 6) }
        }
        for (b in last downTo maxOf(1, last - 2)) {
            if (!SmcEngine.isDisplacement(cl, b, dir, c.cfg)) continue
            for ((label, lv, bonus) in levels) {
                val fresh = if (bear) cl[b].close < lv && cl[b - 1].close >= lv else cl[b].close > lv && cl[b - 1].close <= lv
                if (!fresh) continue
                val holding = if (bear) c.price < lv else c.price > lv
                if (!holding || abs(c.price - lv) > 3.0 * c.atr) continue
                val sl = if (bear) cl[b].high + c.buffer else cl[b].low - c.buffer
                val reasons = mutableListOf(
                    Reason("Displacement candle closed ${if (bear) "below" else "above"} $label ${num(lv)}"),
                    Reason("Price is holding beyond the level")
                )
                return finish(c, Method.BREAKOUT, dir, c.price, sl, 45 + bonus, reasons, null, cl[b].time)
            }
        }
        return null
    }

    // ───────────── 7. EMA trend pullback ─────────────
    private fun emaPullback(c: Ctx, dir: Dir): Setup? {
        val bear = dir == Dir.BEARISH
        val cl = c.closed
        val last = cl.lastIndex
        if (last < 210) return null
        val e20 = c.e20
        val e50 = c.e50
        val e200 = c.e200
        val stacked = if (bear) e20[last] < e50[last] && e50[last] < e200[last] else e20[last] > e50[last] && e50[last] > e200[last]
        val sloping = if (bear) e50[last] < e50[last - 10] else e50[last] > e50[last - 10]
        if (!stacked || !sloping) return null
        val onSide = if (bear) c.price < e20[last] else c.price > e20[last]
        if (!onSide || abs(c.price - e20[last]) > 1.5 * c.atr) return null
        val win = (last - 5)..last
        val touch = win.lastOrNull {
            if (bear) cl[it].high >= e20[it] - 0.15 * c.atr else cl[it].low <= e20[it] + 0.15 * c.atr
        } ?: return null
        val rejected = if (bear) cl[last].close < e20[last] else cl[last].close > e20[last]
        if (!rejected) return null
        val extreme = if (bear) win.maxOf { cl[it].high } else win.minOf { cl[it].low }
        val sl = if (bear) extreme + c.buffer else extreme - c.buffer
        val reasons = mutableListOf(
            Reason("EMA 20 / 50 / 200 are stacked ${if (bear) "down" else "up"}"),
            Reason("Pulled back to the 20 EMA and was rejected")
        )
        return finish(c, Method.EMA_PULLBACK, dir, c.price, sl, 45, reasons, null, cl[touch].time)
    }
}
