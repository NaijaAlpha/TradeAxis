package com.tradeaxis.app

import java.util.Locale
import kotlin.math.abs

/*
 * Shared display helpers used across the app (alerts, chart, copilot, journal, notifications).
 * They were referenced everywhere but never defined, which broke compileDebugKotlin.
 */

private fun bad(v: Double) = v.isNaN() || v.isInfinite()

/** A market price with a sensible number of decimals and thousands separators: 2,345.67 / 150.123 / 1.08543. */
fun num(v: Double): String {
    if (bad(v)) return "—"
    val a = abs(v)
    val decimals = when {
        a >= 1000.0 -> 2   // BTC, gold
        a >= 10.0 -> 3     // JPY pairs, oil, silver
        else -> 5          // majors such as EUR/USD
    }
    return String.format(Locale.US, "%,.${decimals}f", v)
}

/** A US-dollar amount without the $ sign: 1,234.50 */
fun usd(v: Double): String = if (bad(v)) "—" else String.format(Locale.US, "%,.2f", v)

/** A signed US-dollar amount: +$12.50 or -$12.50 */
fun signedUsd(v: Double): String {
    if (bad(v)) return "—"
    val sign = if (v < 0) "-" else "+"
    return sign + "$" + String.format(Locale.US, "%,.2f", abs(v))
}

/** Stop distance as pips for forex, price units for everything else. [dist] is a price difference. */
fun distTxt(symbol: String, dist: Double): String {
    if (bad(dist)) return "—"
    val inst = Instruments.of(symbol)
    return if (inst != null && inst.cat == Cat.FOREX) {
        val pip = if (inst.quote == "JPY") 0.01 else 0.0001
        String.format(Locale.US, "%.1f pips", dist / pip)
    } else {
        String.format(Locale.US, "%s pts", num(dist))
    }
}
