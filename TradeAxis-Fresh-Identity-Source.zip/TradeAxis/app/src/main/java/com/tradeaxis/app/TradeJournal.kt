package com.tradeaxis.app

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject

object TradeJournal {
    val items = MutableStateFlow<List<TradeRecord>>(emptyList())   // newest first
    private var loaded = false

    private fun sp(ctx: Context) = ctx.applicationContext.getSharedPreferences("tradeaxis_journal", Context.MODE_PRIVATE)

    /** Demo-feed trades and real trades never mix: each mode only sees its own. */
    fun visible(all: List<TradeRecord>, demo: Boolean): List<TradeRecord> = all.filter { it.demo == demo }

    @Synchronized
    fun load(ctx: Context) {
        if (loaded) return
        loaded = true
        try {
            val arr = JSONArray(sp(ctx).getString("items", "[]"))
            items.value = List(arr.length()) {
                val o = arr.getJSONObject(it)
                TradeRecord(
                    id = o.getLong("id"),
                    symbol = o.getString("symbol"),
                    tf = o.getString("tf"),
                    side = Dir.valueOf(o.getString("side")),
                    entry = o.getDouble("entry"),
                    sl = o.getDouble("sl"),
                    tp = o.getDouble("tp"),
                    rr = o.getDouble("rr"),
                    openTime = o.getLong("openTime"),
                    outcome = Outcome.valueOf(o.getString("outcome")),
                    closeTime = o.optLong("closeTime", 0L),
                    closePrice = o.optDouble("closePrice", 0.0),
                    manual = o.optBoolean("manual", false),
                    method = o.optString("method", "SWEEP_OB"),
                    grade = o.optString("grade", ""),
                    score = o.optInt("score", 0),
                    tp1 = o.optDouble("tp1", 0.0),
                    tp1Hit = o.optBoolean("tp1Hit", false),
                    beAfterTp1 = o.optBoolean("beAfterTp1", false),
                    lots = o.optDouble("lots", 0.0),
                    riskUsd = o.optDouble("riskUsd", 0.0),
                    copilot = o.optString("copilot", ""),
                    confidence = o.optInt("confidence", 0),
                    note = o.optString("note", ""),
                    demo = o.optBoolean("demo", false)
                )
            }
        } catch (_: Exception) {
            items.value = emptyList()
        }
    }

    @Synchronized
    fun add(ctx: Context, t: TradeRecord) {
        load(ctx)
        val id = maxOf(System.currentTimeMillis(), (items.value.maxOfOrNull { it.id } ?: 0L) + 1)
        items.value = (listOf(t.copy(id = id)) + items.value).take(1000)
        save(ctx)
    }

    @Synchronized
    fun update(ctx: Context, t: TradeRecord) {
        load(ctx)
        items.value = items.value.map { if (it.id == t.id) t else it }
        save(ctx)
    }

    @Synchronized
    fun delete(ctx: Context, id: Long) {
        load(ctx)
        items.value = items.value.filter { it.id != id }
        save(ctx)
    }

    /** Clears only the trades of the current mode (demo or real). */
    @Synchronized
    fun clear(ctx: Context, demo: Boolean) {
        load(ctx)
        items.value = items.value.filter { it.demo != demo }
        save(ctx)
    }

    private fun save(ctx: Context) {
        val arr = JSONArray()
        items.value.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id).put("symbol", it.symbol).put("tf", it.tf)
                    .put("side", it.side.name).put("entry", it.entry).put("sl", it.sl)
                    .put("tp", it.tp).put("rr", it.rr).put("openTime", it.openTime)
                    .put("outcome", it.outcome.name).put("closeTime", it.closeTime)
                    .put("closePrice", it.closePrice).put("manual", it.manual)
                    .put("method", it.method).put("grade", it.grade).put("score", it.score)
                    .put("tp1", it.tp1).put("tp1Hit", it.tp1Hit).put("beAfterTp1", it.beAfterTp1)
                    .put("lots", it.lots).put("riskUsd", it.riskUsd).put("copilot", it.copilot)
                    .put("confidence", it.confidence).put("note", it.note).put("demo", it.demo)
            )
        }
        sp(ctx).edit().putString("items", arr.toString()).apply()
    }
}
