package com.tradeaxis.app

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

fun kindColor(k: AlertKind): Color = when (k) {
    AlertKind.SIGNAL -> UpGreen
    AlertKind.PRICE -> Cyan
    AlertKind.VOLATILITY -> Orange
    AlertKind.RISK -> DownRed
    AlertKind.RESULT -> NovaLight
    AlertKind.BLOCKED -> Amber
    AlertKind.SYSTEM -> Muted
}

fun ago(ms: Long): String {
    val s = (System.currentTimeMillis() - ms) / 1000
    return when {
        s < 60 -> "just now"
        s < 3600 -> "${s / 60}m ago"
        s < 86_400 -> "${s / 3600}h ago"
        else -> "${s / 86_400}d ago"
    }
}

@Composable
fun AlertsScreen(ui: UiState, p: Prefs, defaultSymbol: String) {
    val ctx = LocalContext.current
    val history by AlertHistory.items.collectAsState()
    val rules by AlertRules.items.collectAsState()
    var tab by remember { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    LaunchedEffect(history.size) { MonitorState.update { it.copy(unseenAlerts = 0) } }

    Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 16.dp, vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ScreenHeader("Alerts") {
            if (tab == 0 && history.isNotEmpty()) GhostButton("Clear", { AlertHistory.clear(ctx) })
            if (tab == 1) GhostButton("+ New alert", { showAdd = true }, color = NovaLight)
        }
        Segmented(listOf("Feed" to Nova, "My alerts" to Nova), tab) { tab = it }

        if (tab == 0) {
            if (history.isEmpty()) {
                GlassCard {
                    Text("Nothing yet", fontWeight = FontWeight.Bold)
                    Text("Signals, price alerts, volatility spikes, risk warnings and trade results all land here — and as notifications when TradeAxis is monitoring.", color = Muted, style = MaterialTheme.typography.bodyMedium)
                }
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 120.dp)) {
                items(history) { a ->
                    val c = kindColor(a.kind)
                    GlassCard(accent = if (a.kind == AlertKind.SIGNAL) c else null) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(Modifier.size(8.dp).background(c, CircleShape))
                            Text(a.kind.label.uppercase(), color = c, style = MaterialTheme.typography.titleSmall)
                            Spacer(Modifier.weight(1f))
                            Text(ago(a.time), color = Muted, style = MaterialTheme.typography.bodySmall)
                        }
                        Text(a.title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text(a.body, color = Muted, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 120.dp)) {
                item {
                    GlassCard(accent = Nova) {
                        Text("Automatic alerts are always on", fontWeight = FontWeight.Bold)
                        Text(
                            "Buy / Sell signals, trade results and risk warnings come from the engine without any setup. " +
                                "Use alerts below for anything extra: a price level, a big daily move, a break of yesterday's high or low, or a volatility spike — on any market.",
                            color = Muted, style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
                if (rules.isEmpty()) item { Text("No custom alerts yet. Tap + New alert.", color = Muted, modifier = Modifier.padding(4.dp)) }
                items(rules, key = { it.id }) { r ->
                    GlassCard {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(r.describe(), fontWeight = FontWeight.Bold)
                                Text(
                                    (if (r.repeat) "Repeats" else "Once") + if (r.lastFired > 0) " · last fired ${ago(r.lastFired)}" else " · waiting",
                                    color = Muted, style = MaterialTheme.typography.bodySmall
                                )
                            }
                            Switch(
                                checked = r.enabled,
                                onCheckedChange = { on ->
                                    // re-arm from the current price when switched back on
                                    AlertRules.update(ctx, r.copy(enabled = on, refPrice = PriceBook.get(r.symbol) ?: r.refPrice, lastKey = ""))
                                },
                                colors = SwitchDefaults.colors(checkedTrackColor = Nova, checkedThumbColor = Color.White)
                            )
                            Spacer(Modifier.width(6.dp))
                            RoundIconButton(Ico.Trash, size = 40.dp) { AlertRules.delete(ctx, r.id) }
                        }
                    }
                }
            }
        }
    }

    if (showAdd) AddRuleDialog(defaultSymbol, onDismiss = { showAdd = false }) { rule -> AlertRules.add(ctx, rule); showAdd = false }
}

@Composable
private fun AddRuleDialog(defaultSymbol: String, onDismiss: () -> Unit, onAdd: (AlertRule) -> Unit) {
    var symbol by remember { mutableStateOf(defaultSymbol) }
    var type by remember { mutableStateOf(RuleType.PRICE_ABOVE) }
    var repeat by remember { mutableStateOf(false) }
    val cur = PriceBook.get(symbol)
    fun suggest(t: RuleType): String = when (t) {
        RuleType.PRICE_ABOVE -> cur?.let { num(it * 1.003).replace(",", "") } ?: ""
        RuleType.PRICE_BELOW -> cur?.let { num(it * 0.997).replace(",", "") } ?: ""
        RuleType.DAY_MOVE -> "1.0"
        RuleType.VOLATILITY -> "3.0"
        RuleType.PD_BREAK -> ""
    }
    var levelText by remember { mutableStateOf(suggest(RuleType.PRICE_ABOVE)) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Surface1,
        title = { Text("New alert", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Market", color = Muted, style = MaterialTheme.typography.bodySmall)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Instruments.all.forEach { Chip(it.pair, it.id == symbol) { symbol = it.id; levelText = suggest(type); error = null } }
                }
                Text("Alert me when…", color = Muted, style = MaterialTheme.typography.bodySmall)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    RuleType.values().forEach { Chip(it.label, it == type) { type = it; levelText = suggest(it); error = null } }
                }
                Hint(type.hint)
                if (type.usesLevel) {
                    OutlinedTextField(
                        value = levelText, onValueChange = { levelText = it; error = null },
                        label = { Text(when (type) { RuleType.DAY_MOVE -> "Percent"; RuleType.VOLATILITY -> "Times the average range"; else -> "Price level" }) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        supportingText = { if (cur != null && (type == RuleType.PRICE_ABOVE || type == RuleType.PRICE_BELOW)) Text("Now ${num(cur)}") }
                    )
                }
                if (type == RuleType.PRICE_ABOVE || type == RuleType.PRICE_BELOW) SwitchRow("Repeat each time it crosses", repeat) { repeat = it }
                error?.let { Text(it, color = DownRed, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val lv = if (type.usesLevel) levelText.replace(",", "").toDoubleOrNull() else 0.0
                if (lv == null || (type.usesLevel && lv <= 0.0)) { error = "Enter a number"; return@TextButton }
                if (cur != null && type == RuleType.PRICE_ABOVE && lv <= cur) { error = "Level must be above the current price (${num(cur)})"; return@TextButton }
                if (cur != null && type == RuleType.PRICE_BELOW && lv >= cur) { error = "Level must be below the current price (${num(cur)})"; return@TextButton }
                onAdd(AlertRule(0, type, symbol, lv, cur ?: lv, repeat = repeat && (type == RuleType.PRICE_ABOVE || type == RuleType.PRICE_BELOW)))
            }) { Text("Create", color = NovaLight, fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Muted) } }
    )
}
