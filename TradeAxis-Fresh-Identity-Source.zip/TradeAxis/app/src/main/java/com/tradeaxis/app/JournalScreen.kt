package com.tradeaxis.app

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

private fun r1(v: Double) = String.format(Locale.US, "%+.2fR", v)

fun outcomeColor(o: Outcome): Color = when (o) {
    Outcome.WIN -> UpGreen; Outcome.LOSS -> DownRed; Outcome.BE -> Amber; Outcome.EXPIRED -> Muted; Outcome.OPEN -> Cyan
}

@Composable
fun JournalScreen(trades: List<TradeRecord>, p: Prefs) {
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    var confirmClear by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 16.dp, vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ScreenHeader("Journal") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GhostButton("Export", {
                    val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_SUBJECT, "TradeAxis journal"); putExtra(Intent.EXTRA_TEXT, journalCsv(trades)) }
                    ctx.startActivity(Intent.createChooser(send, "Export journal (CSV)").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                })
                if (trades.isNotEmpty()) GhostButton("Clear", { confirmClear = true }, color = DownRed)
            }
        }
        Segmented(listOf("Stats" to Nova, "AI" to Cyan, "Trades" to Nova, "Backtest" to Nova), tab) { tab = it }
        if (p.isDemo) Text("Showing trades from the demo feed only. They are kept separate from real-data trades.", color = Amber, style = MaterialTheme.typography.bodySmall)
        when (tab) {
            0 -> StatsTab(trades)
            1 -> AiTab(trades, p)
            2 -> TradesTab(trades)
            else -> BacktestTab(p)
        }
    }

    if (confirmClear) AlertDialog(
        onDismissRequest = { confirmClear = false }, containerColor = Surface1,
        title = { Text("Clear journal?") },
        text = { Text("This deletes the ${trades.size} trades shown here (${if (p.isDemo) "demo feed" else "real data"}). It can't be undone.") },
        confirmButton = { TextButton({ TradeJournal.clear(ctx, p.isDemo); confirmClear = false }) { Text("Delete", color = DownRed) } },
        dismissButton = { TextButton({ confirmClear = false }) { Text("Cancel", color = Muted) } }
    )
}

// ─────────────── stats ───────────────

@Composable
private fun StatsTab(trades: List<TradeRecord>) {
    val st = remember(trades) { computeStats(trades) }
    val pnl = remember(trades) { trades.filter { it.outcome != Outcome.OPEN }.sumOf { it.pnlUsd } }
    val curve = remember(trades) {
        var acc = 0.0
        listOf(0.0) + trades.filter { it.outcome != Outcome.OPEN }.sortedBy { it.closeTime }.map { acc += it.pnlUsd; acc }
    }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 120.dp)) {
        if (st.closed == 0) item {
            GlassCard {
                Text("No closed trades yet", fontWeight = FontWeight.Bold)
                Text("Every signal TradeAxis sends is recorded here and tracked to its stop or target. Start monitoring, or run a backtest.", color = Muted, style = MaterialTheme.typography.bodyMedium)
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile("Net P&L", signedUsd(pnl), if (pnl >= 0) UpGreen else DownRed, Modifier.weight(1f))
                StatTile("Net R", r1(st.netR), if (st.netR >= 0) UpGreen else DownRed, Modifier.weight(1f))
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile("Win rate", st.winRate?.let { "${(it * 100).toInt()}%" } ?: "—", modifier = Modifier.weight(1f))
                StatTile("Profit factor", st.profitFactor?.let { String.format(Locale.US, "%.2f", it) } ?: "—", modifier = Modifier.weight(1f))
                StatTile("Open", st.open.toString(), Cyan, Modifier.weight(1f))
            }
        }
        if (curve.size > 2) item {
            SectionCard("Equity curve (USD)") {
                Sparkline(curve, if (curve.last() >= 0) UpGreen else DownRed, Modifier.fillMaxWidth().height(110.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Max drawdown ${String.format(Locale.US, "%.1f", st.maxDrawdown)}R", color = Muted, style = MaterialTheme.typography.bodySmall)
                    Text("Streak " + (if (st.streak >= 0) "${st.streak}W" else "${-st.streak}L"), color = Muted, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item { BreakdownCard("By market", trades.groupBy { it.symbol }.map { (k, v) -> Instruments.label(k) to computeStats(v) }) }
        item {
            BreakdownCard("By entry method", trades.groupBy { it.method }.map { (k, v) ->
                (Method.values().firstOrNull { it.name == k }?.short ?: k) to computeStats(v)
            })
        }
        item { BreakdownCard("By Copilot verdict", trades.filter { it.copilot.isNotEmpty() }.groupBy { it.copilot }.map { (k, v) -> k to computeStats(v) }) }
    }
}

@Composable
private fun BreakdownCard(title: String, rows: List<Pair<String, Stats>>) {
    if (rows.isEmpty()) return
    SectionCard(title) {
        Row(Modifier.fillMaxWidth()) {
            Text("", Modifier.weight(1.6f)); Text("Trades", Modifier.weight(0.8f), color = Muted, fontSize = 11.sp)
            Text("Win", Modifier.weight(0.8f), color = Muted, fontSize = 11.sp); Text("Net R", Modifier.weight(0.9f), color = Muted, fontSize = 11.sp)
        }
        rows.sortedByDescending { it.second.netR }.forEach { (name, s) ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(name, Modifier.weight(1.6f), fontWeight = FontWeight.SemiBold, maxLines = 1)
                Text("${s.closed}", Modifier.weight(0.8f))
                Text(s.winRate?.let { "${(it * 100).toInt()}%" } ?: "—", Modifier.weight(0.8f))
                Text(r1(s.netR), Modifier.weight(0.9f), color = if (s.netR >= 0) UpGreen else DownRed, fontWeight = FontWeight.Bold)
            }
        }
    }
}

// ─────────────── AI analysis ───────────────

@Composable
private fun AiTab(trades: List<TradeRecord>, p: Prefs) {
    val insights = remember(trades) { AiAnalyst.analyze(trades) }
    var muted by remember { mutableStateOf(p.mutedSet()) }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 120.dp)) {
        item {
            GlassCard(accent = Cyan) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NovaIcon(Ico.Spark, Cyan, 18.dp)
                    Text("Pattern analysis", fontWeight = FontWeight.Bold, color = Cyan)
                }
                Text(
                    "Looks through your closed trades for what works and what doesn't — by market, entry method, session, weekday and direction. " +
                        "It runs on your phone with plain statistics, so it needs a decent number of trades before its findings mean much.",
                    color = Muted, style = MaterialTheme.typography.bodySmall
                )
                SwitchRow("Let Copilot use my track record to adjust confidence", p.useEdge) { p.useEdge = it }
            }
        }
        items(insights, key = { it.title }) { ins ->
            val c = when (ins.tone) { 1 -> UpGreen; -1 -> DownRed; else -> NovaLight }
            GlassCard(accent = if (ins.tone != 0) c else null) {
                Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(Modifier.padding(top = 6.dp).size(8.dp).background(c, CircleShape))
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(ins.title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text(ins.detail, color = Muted, style = MaterialTheme.typography.bodyMedium)
                    }
                }
                if (ins.muteKey != null) {
                    val on = ins.muteKey in muted
                    GhostButton(if (on) "Muted — tap to unmute" else ins.muteLabel, {
                        p.mute(ins.muteKey, !on); muted = p.mutedSet()
                    }, color = if (on) UpGreen else Amber)
                }
            }
        }
        if (muted.isNotEmpty()) item {
            SectionCard("Muted by you") {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    muted.forEach { k ->
                        val label = k.substringAfter(':').let { v -> Instruments.of(v)?.pair ?: Method.values().firstOrNull { it.name == v }?.short ?: v }
                        Chip("$label ✕", true) { p.mute(k, false); muted = p.mutedSet() }
                    }
                }
                Hint("Copilot marks these as BLOCKED instead of sending an alert. Tap one to unmute.")
            }
        }
    }
}

// ─────────────── trades ───────────────

private val dateFmt = SimpleDateFormat("d MMM HH:mm", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }

@Composable
private fun TradesTab(trades: List<TradeRecord>) {
    val ctx = LocalContext.current
    var noteFor by remember { mutableStateOf<TradeRecord?>(null) }
    if (trades.isEmpty()) {
        GlassCard { Text("No trades yet", fontWeight = FontWeight.Bold); Text("Signals appear here the moment they're sent.", color = Muted) }
        return
    }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 120.dp)) {
        items(trades, key = { it.id }) { t ->
            val sc = sideColor(t.side == Dir.BULLISH)
            val oc = outcomeColor(t.outcome)
            val live = if (t.outcome == Outcome.OPEN) PriceBook.get(t.symbol)?.let { t.rAt(it) } else null
            GlassCard {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill(if (t.side == Dir.BULLISH) "BUY" else "SELL", sc)
                    Text(Instruments.label(t.symbol), fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                    Spacer(Modifier.weight(1f))
                    Pill(if (t.outcome == Outcome.OPEN) "OPEN" else t.outcome.name, oc)
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("${t.methodLabel} · ${t.tf}" + if (t.grade.isNotEmpty()) " · ${t.grade}" else "", color = Muted, style = MaterialTheme.typography.bodySmall)
                    Text(dateFmt.format(Date(t.openTime)), color = Muted, style = MaterialTheme.typography.bodySmall)
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Entry ${num(t.entry)}", style = MaterialTheme.typography.bodySmall)
                    Text("SL ${num(t.sl)}", color = DownRed, style = MaterialTheme.typography.bodySmall)
                    Text("TP ${num(t.tp)}", color = UpGreen, style = MaterialTheme.typography.bodySmall)
                }
                val resultTxt = when {
                    t.outcome != Outcome.OPEN -> r1(t.r) + if (t.riskUsd > 0) "  ·  " + signedUsd(t.pnlUsd) else ""
                    live != null -> "Floating " + r1(live) + if (t.riskUsd > 0) "  ·  " + signedUsd(live * t.riskUsd) else ""
                    else -> ""
                }
                if (resultTxt.isNotEmpty()) Text(resultTxt, fontWeight = FontWeight.Bold, color = if ((live ?: t.r) >= 0) UpGreen else DownRed)
                if (t.copilot.isNotEmpty()) Text("Copilot ${t.copilot} · confidence ${t.confidence}" + if (t.lots > 0) " · ${String.format(Locale.US, "%.2f", t.lots)} lots" else "", color = Muted, style = MaterialTheme.typography.bodySmall)
                if (t.note.isNotBlank()) Text("“${t.note}”", color = NovaLight, style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GhostButton("Note", { noteFor = t })
                    if (t.outcome == Outcome.OPEN) {
                        val px = PriceBook.get(t.symbol)
                        if (px != null) GhostButton("Close now", {
                            TradeJournal.update(ctx, t.copy(outcome = Outcome.EXPIRED, closeTime = System.currentTimeMillis(), closePrice = px, manual = true))
                        }, color = Amber)
                    }
                    GhostButton("Delete", { TradeJournal.delete(ctx, t.id) }, color = DownRed)
                }
            }
        }
    }
    noteFor?.let { t ->
        var text by remember(t.id) { mutableStateOf(t.note) }
        AlertDialog(
            onDismissRequest = { noteFor = null }, containerColor = Surface1,
            title = { Text("Trade note") },
            text = { OutlinedTextField(text, { text = it }, placeholder = { Text("What did you see? What would you change?") }, minLines = 3) },
            confirmButton = { TextButton({ TradeJournal.update(ctx, t.copy(note = text.trim())); noteFor = null }) { Text("Save", color = NovaLight) } },
            dismissButton = { TextButton({ noteFor = null }) { Text("Cancel", color = Muted) } }
        )
    }
}

// ─────────────── backtest ───────────────

@Composable
private fun BacktestTab(p: Prefs) {
    val scope = rememberCoroutineScope()
    var symbol by remember { mutableStateOf(p.symbol) }
    var running by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    var result by remember { mutableStateOf<BtResult?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 120.dp)) {
        item {
            SectionCard("Backtest your settings") {
                Hint("Replays the strategy on recent ${p.tf} candles with your current engine settings and shows how it would have done. Past results don't guarantee future ones.")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Instruments.all.forEach { Chip(it.pair, it.id == symbol) { symbol = it.id } }
                }
                GradientButton(if (running) "Running… ${(progress * 100).toInt()}%" else "Run backtest", {
                    if (!running) {
                        running = true; error = null; progress = 0f
                        scope.launch {
                            try { result = BacktestRunner.run(p, symbol) { i, n -> progress = i.toFloat() / n } }
                            catch (e: Exception) { error = e.message ?: "Backtest failed"; result = null }
                            running = false
                        }
                    }
                }, Modifier.fillMaxWidth(), ico = Ico.Chart)
                error?.let { Text(it, color = DownRed, style = MaterialTheme.typography.bodySmall) }
            }
        }
        result?.let { r ->
            item {
                val o = r.overall
                SectionCard("Result · ${Instruments.label(symbol)} · ${String.format(Locale.US, "%.0f", r.spanDays)} days") {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        StatTile("Net R", r1(o.netR), if (o.netR >= 0) UpGreen else DownRed, Modifier.weight(1f))
                        StatTile("Win rate", o.winRate?.let { "${(it * 100).toInt()}%" } ?: "—", modifier = Modifier.weight(1f))
                        StatTile("Trades", "${o.closed}", modifier = Modifier.weight(1f))
                    }
                    KV("Profit factor", o.profitFactor?.let { String.format(Locale.US, "%.2f", it) } ?: "—")
                    KV("Max drawdown", String.format(Locale.US, "%.1fR", o.maxDrawdown))
                    if (o.equity.size > 2) Sparkline(listOf(0.0) + o.equity, if (o.netR >= 0) UpGreen else DownRed, Modifier.fillMaxWidth().height(90.dp))
                }
            }
            item { BreakdownCard("By entry method", r.byMethod.map { (k, v) -> (Method.values().firstOrNull { it.name == k }?.short ?: k) to v }) }
            item { BreakdownCard("By grade", r.byGrade.map { (k, v) -> "Grade $k" to v }) }
        }
    }
}
