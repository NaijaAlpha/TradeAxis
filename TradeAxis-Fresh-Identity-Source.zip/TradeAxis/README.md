# TradeAxis

A mature, modern Android trading analysis workspace built around one idea:

**Plan → Analyze → Execute**

## What changed

- Completely refreshed visual identity: graphite-black surfaces, restrained emerald/mint accent, tighter typography, and a cleaner brand mark.
- Renamed the app from TradeNova to TradeAxis.
- Added a dedicated **Trade** workspace with explicit:
  - BUY / SELL direction
  - Market / Limit / Breakout / Retest entry mode
  - Instrument and timeframe
  - Entry, SL, TP1 and TP2
  - Automatic R:R calculation
  - Risk % and position sizing
  - Strategy and grade
  - Trade thesis / notes
  - Risk Guard pre-flight validation
- Manual trades are written into the existing journal and use the existing monitoring/statistics engine.
- Existing charts, Copilot, market feed, alerts, Risk Guard and journal logic are retained.
- GitHub Actions workflow is prepared to build debug or release APKs.

## Build

The GitHub workflow is in `.github/workflows/build-tradeaxis.yml`.
It supports push, pull request and manual builds and publishes the generated APK as an artifact.

Release APKs are unsigned unless a signing configuration is added.

## Data safety

TradeAxis is an analysis/journal tool. It does not place broker orders. Configure OANDA/Twelve Data in Settings when you want live market data.
